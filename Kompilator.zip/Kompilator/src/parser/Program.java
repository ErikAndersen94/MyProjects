package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;
/*
 * Til innlevering av del 3 har vi dessverre ikke f�tt til alle funksjonene programmet skal ha, men det aller meste
 * skal v�re i orden.
 * Av funksjonene som mangler er h�ndtering av(hovedsakelig hvordan vi skal deklarere) array og utskrift ved kall p� write.
 * Vi pr�vde lenge og mye � f� til array, men det ble rett og slett ikke nok tid. Vi skal fikse dette til neste innlevering.
 * Utover dette er det som sist ganske mye repetisjon av kode underveis, s� steder hvor tankegangen er innlysende
 * vil vi ikke kommentere spesifikt. 
 * 
 */

public class Program {
	public String name;
	Block bl;
	int lnum;

	Program(int lnum) {
		lnum = lnum;
	}

	public String identify() {
		return "<program> on line " + lnum;
	}
	
	public static Program parse(Scanner s) {
		PascalSyntax.enterParser("program");

		Program p = new Program(s.curLineNum());
		s.skip(programToken);
		s.test(nameToken);
		p.name = s.curToken.id;
		s.skip(nameToken);
		s.skip(semicolonToken);
		p.bl = Block.parse(s);
		if (s.curToken.kind.equals(dotToken)) {
			s.skip(dotToken);
		} else {
			// Feilmelding som gir beskjed og avslutter programmet om det plutselig dukker opp en e-o-f-token,
			// n�r det skulle v�rt ett punktum.
			Main.error("Error in last line : Expected a . but found a e-o-f! ");
			System.exit(0);
		}
		PascalSyntax.leaveParser("program");
		return p;

	}

	// Printingen. Denne f�lger oppskriften fra jernbanediagrammet. 
	public void prettyPrint() {
		Main.log.prettyPrint("program ");
		Main.log.prettyPrint(name);
		Main.log.prettyPrint(";");
		bl.prettyPrint();
		Main.log.prettyPrint(".");

	}
	
	public void check(Block curScope, Library lib){
		bl.check(curScope, lib);
	}
	
	public void genCode(CodeFile f) {
		String testLabel = f.getLocalLabel();
		//String endLabel = f.getLocalLabel();
		bl.programName = name;
		bl.name = "prog";
		bl.varName = name;
		//Gir blokkniv� verdien 1, ettersom n�r vi kommer inn i program s� vet vi at der er den f�rste blokken.
		bl.blokkNiv� = 1;
		bl.procfuncteller = 1;
		bl.genCode(f);
		//Frigj�r plass med leave, og returnerer med ret.
		//f.genInstr("", "leave", "", " End of mini");
		//f.genInstr("", "ret", "", "");
	}
}
