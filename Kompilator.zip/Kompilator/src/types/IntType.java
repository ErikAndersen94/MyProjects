package types;

public class IntType extends Type {
    @Override public String identify() {
    //E: Jeg endret stringen som returneres fra "type Integer" til "type Int"
    //E: for � f� riktig utskrift(write_int vs write_integer) i gcd.s
	return "type Int";
    }

    @Override public int size() {
	return 4;
    }
}
