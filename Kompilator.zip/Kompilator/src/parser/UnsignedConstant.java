package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class UnsignedConstant extends Factor {
	CharLiteral cl;
	NumericLiteral nl;
	String name;
	ConstDecl cdRef;
	types.Type type;
	int constVal;
	int blokkNiv�;

	UnsignedConstant(int lnum) {
		super(lnum);
	}

	public String identify() {
		return "<unsigned constant> on line " + lineNum;
	}

	static UnsignedConstant parse(Scanner s) {
		enterParser("unsigned constant");
		UnsignedConstant unco = new UnsignedConstant(s.curLineNum());

		if (s.curToken.kind.equals(charValToken)) {
			unco.cl = CharLiteral.parse(s);
		} else if (s.curToken.kind.equals(intValToken)) {
			unco.nl = NumericLiteral.parse(s);
		} else {
			s.test(nameToken);
			unco.name = s.curToken.id;
			s.skip(nameToken);
		}

		leaveParser("unsigned constant");
		return unco;
	}

	@Override
	void prettyPrint() {
		if (cl != null) {
			cl.prettyPrint();
		} else if (nl != null) {
			nl.prettyPrint();
		} else if (unco != null && unco.name != null) {
			Main.log.prettyPrint(name);
		}
	}

	/*
	 * Sjekker om vi skal h�ndtere en char literal, en numeric literal eller et navn.
	 * Typen tilordnes deretter. Hvis vi skal h�ndtere et navn bindes dette til deklarasjonen hvor navnet er n�kkel.
	 */
	@Override
	void check(Block curScope, Library lib) {
		if (cl != null) {
			cl.check(curScope, lib);
			type = lib.charType;
			constVal = cl.constVal;
		} else if (nl != null) {
			nl.check(curScope, lib);
			type = lib.intType;
			constVal = nl.constVal;
		}
		else{
			PascalDecl d = curScope.findDecl(name, this);
			cdRef = (ConstDecl)d;
			type = lib.charType;
		}
	}
	
	@Override
	void genCode(CodeFile f){
		if (cl != null) {
			cl.blokkNiv� = blokkNiv�;
			cl.genCode(f);
		} else if (nl != null) {
			nl.blokkNiv� = blokkNiv�;
			nl.genCode(f);
		} else if (unco != null && unco.name != null) {
		}
	}
}
