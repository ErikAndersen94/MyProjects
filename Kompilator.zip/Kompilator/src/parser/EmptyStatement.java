package parser;

import main.*;
import scanner.*;

public class EmptyStatement extends Statement {
	EmptyStatement(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<empty statement> on line " + lineNum;
	}

	static EmptyStatement parse(Scanner s) {
		enterParser("empty statement");
		EmptyStatement es = new EmptyStatement(s.curLineNum());

		leaveParser("empty statement");
		return es;
	}

	// Skriver bare ut en tom linje.
	@Override
	void prettyPrint() {
		Main.log.prettyPrintLn("");
	}

	@Override
	void check(Block curScope, Library lib) {
	}
}
