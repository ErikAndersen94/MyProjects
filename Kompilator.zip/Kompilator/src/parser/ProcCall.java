package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ProcCall extends Statement {
	Expression expr;
	int antParam;
	String name;
	Expression[] exprArray = new Expression[10];
	int index = 0;
	ProcDecl procRef;
	int blokkNiv�;

	ProcCall(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<proc call> on line " + lineNum;
	}

	static ProcCall parse(Scanner s) {
		boolean loop = true;
		enterParser("proc call");
		ProcCall pc = new ProcCall(s.curLineNum());
		s.test(nameToken);
		pc.name = s.curToken.id;
		s.skip(nameToken);
		if (s.curToken.id.equals("(")) {
			s.skip(leftParToken);
			while (loop) {
				pc.antParam++;
				pc.expr = Expression.parse(s);
				pc.exprArray[pc.index++] = pc.expr;
				if (!s.curToken.id.equals(",")) {
					loop = false;
				} else {
					s.skip(commaToken);
				}
				if (pc.index == pc.exprArray.length) {
					// Array er fullt, dobler str.
					// Kopierer f�rst arrayet til et tempArray. Dobler s� str p�
					// det opprinnelige arrayet
					// flytter til slutt verdiene tilbake til det opprinnelige
					// arrayet.
					Expression[] tempExpr = pc.exprArray;
					pc.exprArray = new Expression[pc.index * 2];
					for (int i = 0; i < tempExpr.length; i++) {
						pc.exprArray[i] = tempExpr[i];
					}
				}

			}
			s.skip(rightParToken);

		}
		leaveParser("proc call");
		return pc;
	}

	@Override
	void prettyPrint() {
		int index = 0;
		Main.log.prettyPrint(name);
		if (exprArray[index] != null) {
			Main.log.prettyPrint("(");
			exprArray[index++].prettyPrint();
			while (exprArray[index] != null) {
				Main.log.prettyPrint(", ");
				exprArray[index].prettyPrint();
				index++;
			}
			Main.log.prettyPrint(")");
		}
	}

	@Override
	void check(Block curScope, Library lib) {
		PascalDecl d = curScope.findDecl(name, this);
		d.checkWhetherProcedure(this);
		procRef = (ProcDecl) d;
		int pos = 0;
		while (exprArray[pos] != null) {
			exprArray[pos].check(curScope, lib);
			pos++;
		}
		if (procRef.libId == "write") {
		} else {
			if (procRef.pdl != null && procRef.pdl.index == index) {
				// itererer gjennom prosedyrens parametere og typesjekker de mot
				// prosedyrekallets parametere.
				int counter = 0;
				while (counter < index) {
					procRef.pdl.pdArray[counter].type.checkType(exprArray[counter].type, "param #" + (counter + 1),
							this, "The parameters are of different type");
					counter++;
				}
			} else if (procRef.pdl == null && index == 0) {
				// tilfelle hvor prosedyren ikke forventer noen parametere og
				// heller ikke f�r det.
			} else {
				procRef.error("Different number of parameters");
			}
		}
	}

	@Override
	void genCode(CodeFile f) {
		int pos = 0;
		if (antParam == 0) { // ProcCall uten parametere. FInner navnet i deklarasjonen.
			f.genInstr("", "call", "proc$" + procRef.name + "_" + procRef.niv�, "");
		} else {
			while (pos < antParam) {
				if (name.equals("write")) {
					exprArray[pos].blokkNiv� = blokkNiv�;
					exprArray[pos].genCode(f);
					String x = exprArray[pos].type.identify(); // henter ut stringen, splitter s� opp, og sjekker om det er write.
					x = x.toLowerCase();
					String[] x2 = x.split(" ");
					x = x2[1];
					f.genInstr("", "pushl", "%eax", "");
					f.genInstr("", "call", "write_" + x, "");
					f.genInstr("", "addl", "$4,%esp", " Pop param");
				} else {
					exprArray[antParam - pos - 1].blokkNiv� = blokkNiv�; // jobber bakfra og frem.
					exprArray[antParam - pos - 1].genCode(f);
					f.genInstr("", "pushl", "%eax", "push param #" + (antParam - pos));
				}
				pos++;
			}
			if (!name.equals("write")) {
				f.genInstr("", "call", "proc$" + procRef.name + "_" + procRef.procfuncteller, "");
				f.genInstr("", "addl", "$" + antParam * 4 + ",%esp", "");
			}
		}
	}
}
