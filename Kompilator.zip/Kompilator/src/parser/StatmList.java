package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class StatmList extends Block {
	Statement sm;
	Statement[] stmArray = new Statement[10];
	int index = 0;
	int blokkNiv�;

	StatmList(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<statm list> on line " + lineNum;
	}

	static StatmList parse(Scanner s) {
		boolean loop = true;
		enterParser("statm list");

		StatmList sl = new StatmList(s.curLineNum());
		sl.sm = Statement.parse(s);
		sl.stmArray[sl.index++] = sl.sm;
		// Hvis neste tegn er semikolon, s� m� vi kalle objektet p� nytt. Vi
		// gj�r dette i en loop, som bryter f�rst n�r tegnet ikke er semikolon
		while (loop) {
			if (!s.curToken.id.equals(";")) {
				loop = false;
			} else {
				s.skip(semicolonToken);
				sl.sm = Statement.parse(s);
				sl.stmArray[sl.index++] = sl.sm;
			}
			if (sl.index == sl.stmArray.length) {
				// Array er fullt, dobler str.
				Statement[] tempstm = sl.stmArray;
				sl.stmArray = new Statement[sl.index * 2];
				for (int i = 0; i < tempstm.length; i++) {
					sl.stmArray[i] = tempstm[i];
				}
			}
		}

		leaveParser("statm list");
		return sl;
	}

	@Override
	void prettyPrint() {
		int index = 0;
		stmArray[index++].prettyPrint();
		while (stmArray[index] != null) {
			Main.log.prettyPrintLn(";");
			stmArray[index].prettyPrint();
			index++;
		}
	}

	void check(Block curScope, Library lib) {
		int pos = 0;
		while (stmArray[pos] != null) {
			stmArray[pos].check(curScope, lib);
			pos++;
		}
	}
	
	@Override void genCode(CodeFile f) {
		int pos = 0;
		while (stmArray[pos] != null) {
			stmArray[pos].blokkNiv� = blokkNiv�;
			stmArray[pos].genCode(f);
			pos++;
		}
	}
}
