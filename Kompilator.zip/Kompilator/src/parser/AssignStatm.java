package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

// Oppretter objekt av seg selv. Kaller s� p� klassen Variable sin parse-metode.
// Jernbanediagrammet sier s� at en assignToken skal skippes, og etter det kalles Expression sin parse-metode, 
// f�r vi forlater assignStatement og returnerer tilbake. 
public class AssignStatm extends Statement{
	Variable var;
	Expression expr;
	int blokkNiv�;
	
	AssignStatm(int lnum) {
		super(lnum);
	}
	
	public String identify() {
		return "<assign statm> on line " + lineNum;
	}
	
	static AssignStatm parse(Scanner s){
		enterParser("assign statm");
		AssignStatm as = new AssignStatm(s.curLineNum());
		as.var = Variable.parse(s);
		s.skip(assignToken);
		as.expr = Expression.parse(s);
		
		leaveParser("assign statm");
		return as;
	}
	
	@Override
	void prettyPrint() {
		var.prettyPrint();
		Main.log.prettyPrint(" := ");
		expr.prettyPrint();
	}
	
	//Kaller p� check-metodene utifra jernbanediagrammet.
	//Tester s� om decl objektet i var kan assignes til, gj�r s� en test p� om var sin type er den samme typen
	// som expr sin type.
	@Override
	void check(Block curScope, Library lib){
		var.check(curScope, lib);
		var.d.checkWhetherAssignable(this);
		expr.check(curScope, lib);
		var.type.checkType(expr.type, ":=", this, "Operands to := are of different type");
	}
	@Override
	void genCode(CodeFile f){
		// Oppdaterer blokkniv�, og skriver ut korrekte assembelprinter for funksjon eller variabel.
		var.blokkNiv� = blokkNiv�;
		expr.blokkNiv� = blokkNiv�;
		expr.genCode(f);
		if(var.fdRef != null){
			//er en funksjonstilordning
			f.genInstr("", "movl", -4*(var.fdRef.blokkNiv�) + "(%ebp),%edx", "");
			f.genInstr("", "movl", "%eax,-32(%edx)", " "+ var.fdRef.name + " :=");
		}
		else{
			// er en variabeltilordning
			f.genInstr("", "movl", -4*var.blokkNiv�	 + "(%ebp),%edx","");
			f.genInstr("", "movl", "%eax," + var.offset + "(%edx)", " " + var.name + " :=");
		}
	}
}
