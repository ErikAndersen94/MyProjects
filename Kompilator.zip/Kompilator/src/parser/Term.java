package parser;

import scanner.*;
import static scanner.TokenKind.*;

import main.CodeFile;

public class Term extends SimpleExpression {
	Factor fact;
	FactorOpr fopr;
	Factor[] factArray = new Factor[10];
	FactorOpr[] foprArray = new FactorOpr[10];
	int factIndex = 0;
	int foprIndex = 0;
	types.Type type;
	int blokkNiv�;

	Term(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<term> on line " + lineNum;
	}

	static Term parse(Scanner s) {
		boolean loop = true;
		enterParser("term");
		Term term = new Term(s.curLineNum());

		while (loop) {
			term.fact = Factor.parse(s);
			term.factArray[term.factIndex++] = term.fact;
			if (s.curToken.kind.equals(multiplyToken) || s.curToken.kind.equals(divToken)
					|| s.curToken.kind.equals(modToken) || s.curToken.kind.equals(andToken)) {
				term.fopr = FactorOpr.parse(s);
				term.foprArray[term.foprIndex++] = term.fopr;
			} else {
				loop = false;
			}
			if (term.factIndex == term.factArray.length) {
				// Array er fullt, dobler str.
				Factor[] tempFact = term.factArray;
				term.factArray = new Factor[term.termIndex * 2];

				FactorOpr[] tempFopr = term.foprArray;
				term.foprArray = new FactorOpr[term.foprIndex * 2];
				for (int i = 0; i < tempFact.length; i++) {
					term.factArray[i] = tempFact[i];
					term.foprArray[i] = tempFopr[i];
				}
			}
		}
		leaveParser("term");
		return term;
	}

	@Override
	void prettyPrint() {
		factArray[0].prettyPrint();
		int f = 0;
		while (foprArray[f] != null) {
			foprArray[f].prettyPrint();
			factArray[f + 1].prettyPrint();
			f++;
		}
	}

	/*
	 * Henviser til simpleExpression. Samme tankegang.
	 */
	@Override
	void check(Block curScope, Library lib) {
		int f = 0;
		factArray[f].check(curScope, lib);
		type = factArray[f].type;
		while (foprArray[f] != null) {
			foprArray[f].check(curScope, lib);
			type.checkType(foprArray[f].type, "left " + foprArray[f].name + " operand", this, "");
			factArray[f + 1].check(curScope, lib);
			type = factArray[f + 1].type;
			type.checkType(foprArray[f].type, "right " + foprArray[f].name + " operand", this, "");
			f++;
		}
		if (foprArray[0] != null) {
			type = foprArray[0].type;
		}
	}

	@Override
	void genCode(CodeFile f) {
		factArray[0].blokkNiv� = blokkNiv�;
		factArray[0].genCode(f);
		int pos = 0;
		if (foprArray[0] != null) {
			f.genInstr("", "pushl", "%eax", ""); // Pusher siden vi vet at vi senere trenger plassen til en annen verdi
			factArray[1].blokkNiv� = blokkNiv�;
			factArray[1].genCode(f);
			f.genInstr("", "movl", "%eax,%ecx", " " + foprArray[pos].name); // Pusher siden vi vet at vi senere trenger plassen til en annen verdi
			f.genInstr("", "popl", "%eax", ""); // Pusher siden vi vet at vi senere trenger plassen til en annen verdi
			if (foprArray[pos].name == " * ") {
				f.genInstr("", "imull", "%ecx,%eax", " * (factor opr)");
			} else if (foprArray[pos].name == " div ") {
				f.genInstr("", "cdq", "", " omformer 32 bits til 64 bits");
				f.genInstr("", "idivl", "%ecx", " div (factor opr)");
			} else if (foprArray[pos].name == " mod ") {
				f.genInstr("", "cdq", "", " omformer 32 bits til 64 bits"); 
				f.genInstr("", "idivl", "%ecx", "");
				f.genInstr("", "movl", "%edx,%eax", " mod (factor opr)");
				    
			} else if (foprArray[pos].name == " and ") {
				f.genInstr("", "andl", "%ecx,%eax", " and (factor opr)");
			} else {
				System.out.println("Factor opr inneholder ikke korrekt verdi");
				System.exit(0);
			}
		}
	}
}