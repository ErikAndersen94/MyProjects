package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class Variable extends Factor {
	Expression expr;
	String name;
	PascalDecl d;
	ParamDecl pdRef;
	VarDecl vdRef;
	FuncDecl fdRef;
	ConstDecl constRef;
	types.Type type;
	int blokkNiv�;
	int offset;

	Variable(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<variable> on line " + lineNum;
	}

	static Variable parse(Scanner s) {
		enterParser("variable");
		Variable var = new Variable(s.curLineNum());
		s.test(nameToken);
		var.name = s.curToken.id;
		s.skip(nameToken);
		if (s.curToken.kind.equals(leftBracketToken)) {
			s.skip(leftBracketToken);
			var.expr = Expression.parse(s);
			s.skip(rightBracketToken);
		}

		leaveParser("variable");
		return var;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
		if (expr != null) {
			Main.log.prettyPrint("[");
			expr.prettyPrint();
			Main.log.prettyPrint("]");
		}
	}

	/*
	 * Bruker findDecl til � binde verdien vi finner i variable med
	 * deklarasjonen. Siden verdien kan v�re deklarert p� forskjellig vis, m� vi
	 * caste til riktig type. Sjekker ogs� om decl-objektet kan v�re en verdi.
	 */
	@Override
	void check(Block curScope, Library lib) {
		d = curScope.findDecl(name, this);
		d.checkWhetherValue(this);
		if (d instanceof VarDecl) {
			vdRef = (VarDecl) d;
			offset = vdRef.offset;
			type = vdRef.t.tn.type;
		} else if (d instanceof ParamDecl) {
			pdRef = (ParamDecl) d;
			offset = pdRef.offset;
			type = pdRef.tn.type;
		} else if (d instanceof FuncDecl) {
			fdRef = (FuncDecl) d;
			type = fdRef.tn.type;
		} else if (d instanceof ConstDecl) {
			constRef = (ConstDecl) d;
			if (name.equals("eol")) {
				type = lib.charType;
			} else {
				type = constRef.type;
			}
		}
		if (expr != null) {
			expr.check(curScope, lib);
		}
	}

	
	/*
	 * I variabel kan verdien enten v�re en eol, da skal vi skrive ut linjefeed sin ascii-verdi.
	 * Den kan ogs� v�re en true/false verdi, med tilsvarende 1 og 0 som verdier.
	 * I tillegg til dette kan den v�re en constant, eller ogs� en vanlig variabel med navn.
	 * Offsettet til variabel finnes i varDecl-deklarasjonen. 
	 */
	@Override
	void genCode(CodeFile f) {
		if (constRef != null) {
			if (name.equals("eol")) {
				f.genInstr("", "movl", "$" + 10 + ",%eax", " " + 10);
			} else {
				if(constRef.libId.equals("true")){
					f.genInstr("", "movl", "$1,%eax", " 1");
				}
				else if(constRef.libId.equals("false")){
					f.genInstr("", "movl", "$0,%eax", " 0");
				}
				//Gjelder konstanter
				else{
					f.genInstr("", "movl", "$" + constRef.constVal + ",%eax", " " + constRef.constVal);
				}
			}
		} else {
			f.genInstr("", "movl", -4 * blokkNiv� + "(%ebp),%edx", " " + name);
			f.genInstr("", "movl", offset + "(%edx),%eax", "");
		}
		if (expr != null) {
			expr.blokkNiv� = blokkNiv�;
			expr.genCode(f);
		}
	}
}
