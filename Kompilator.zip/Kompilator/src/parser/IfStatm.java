package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class IfStatm extends Statement {
	Expression expr;
	Statement stm;
	Statement stm2;
	int blokkNiv�;

	IfStatm(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<if-statm> on line " + lineNum;
	}

	// Dette var ogs� en klasse hvor vi m�tte lage funksjonalitet for � h�ndtere
	// to forskjellige objekt av samme klasse.
	// Derfor opprettet vi stm og stm2, slik at ikke objektet ble skrevet over.
	static IfStatm parse(Scanner s) {
		enterParser("if-statm");
		IfStatm is = new IfStatm(s.curLineNum());
		s.skip(ifToken);
		is.expr = Expression.parse(s);
		s.skip(thenToken);
		is.stm = Statement.parse(s);
		if (s.curToken.kind.equals(elseToken)) {
			s.skip(elseToken);
			is.stm2 = Statement.parse(s);
		}
		leaveParser("if-statm");
		return is;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint("if ");
		expr.prettyPrint();
		Main.log.prettyPrintLn(" then");
		Main.log.prettyIndent();
		stm.prettyPrint();
		Main.log.prettyOutdent();
		if (stm2 != null) {
			Main.log.prettyPrintLn();
			Main.log.prettyPrintLn("else");
			Main.log.prettyIndent();
			stm2.prettyPrint();
			Main.log.prettyOutdent();
		}
	}

	/*
	 * Sjekker om expr sin type er en boolean. En if-stm er true eller false, s�
	 * det m� utrykket(expr) ogs� v�re.
	 */
	@Override
	void check(Block curScope, Library lib) {
		expr.check(curScope, lib);
		expr.type.checkType(lib.boolType, "if-test", this, "if-test is not boolean.");
		stm.check(curScope, lib);
		if (stm2 != null) {
			stm2.check(curScope, lib);
		}
	}

	@Override
	void genCode(CodeFile f) {
		f.genInstr("", "", "", "Start if-statement");
		expr.blokkNiv� = blokkNiv�;
		expr.genCode(f);
		f.genInstr("", "cmpl", "$0,%eax", ""); // Sammenlikner at verdiene er riktig.
		String startLabel = f.getLocalLabel();
		f.genInstr("", "je", startLabel, "");
		stm.blokkNiv� = blokkNiv�;
		stm.genCode(f);
		if (stm2 == null) {
			// kun if-statement
			f.genInstr(startLabel, "", "", "");
		} else {
			// if/else statement
			String endLabel = f.getLocalLabel();
			f.genInstr("", "jmp", endLabel, "");
			f.genInstr(startLabel, "", "", "");
			stm2.blokkNiv� = blokkNiv�;
			stm2.genCode(f);
			f.genInstr(endLabel, "", "", "");
		}
		f.genInstr("", "", "", "End if-statement");
	}
}
