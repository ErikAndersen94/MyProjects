package com.example.app.FUTmodes;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;

public class LoginPage extends AppCompatActivity {
    UserDatabase userDB = new UserDatabase(this);
    private AutoCompleteTextView mUserNameView;
    private EditText mPasswordView;
    private View mProgressView;
    private View mLoginFormView;
    String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        /*
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.zlatan_header);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
*/
        Toolbar my_toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(my_toolbar);
        getSupportActionBar().setTitle("FUTMODES");
        getSupportActionBar().setIcon(getDrawable(R.drawable.zlatan_header));

        mUserNameView = (AutoCompleteTextView) findViewById(R.id.username);
        mPasswordView = (EditText) findViewById(R.id.password);
        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
    }
    public void onLoginButton(View view){
        username = mUserNameView.getText().toString();
        String password = mPasswordView.getText().toString();
        // Must get username and pw from xml
        if(!TextUtils.isEmpty(password) && !TextUtils.isEmpty(username)) {
            if (userDB.userHasAccount(username)) {
                if (userDB.userLogin(username, password)) {
                    // User exist and password is correct.
                    Intent myIntentMainPage = new Intent(LoginPage.this, MainActivity.class);
                    myIntentMainPage.putExtra("username", username);
                    LoginPage.this.startActivity(myIntentMainPage);
                } else {
                    // username exist but password is wrong
                }
            } else {
                // username doenst exist. Perhaps send to registerpage?
                onRegisterButton(view);
            }
        }
        else{
            // Must fill in stuff
        }
    }
    public void onRegisterButton(View view){
        Intent myIntentRegisterAcc = new Intent(LoginPage.this, RegisterAccount.class);
        LoginPage.this.startActivity(myIntentRegisterAcc);
    }



    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

}
