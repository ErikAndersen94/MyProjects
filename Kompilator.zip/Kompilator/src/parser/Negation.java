package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class Negation extends Factor{
	Factor fact;
	int blokkNiv�;
	
	Negation(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<negation> on line " + lineNum;
	}
	
	static Negation parse(Scanner s) {
		enterParser("negation");
		
		Negation ng = new Negation(s.curLineNum());
		s.skip(notToken);
		ng.fact = Factor.parse(s);
		
		leaveParser("negation");
		return ng;
	}
	
	@Override
	void prettyPrint() {
		Main.log.prettyPrint("not ");
		fact.prettyPrint();
	}
	
	@Override
	void check(Block curScope, Library lib){
		fact.check(curScope, lib);
	}
	@Override
	void genCode(CodeFile f){
		fact.blokkNiv� = blokkNiv�;
		fact.genCode(f);
		f.genInstr("", "xorl", "$1,%eax", " not (negation)");
	}

}
