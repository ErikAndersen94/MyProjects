package com.example.app.FUTmodes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatatypeMismatchException;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Ola on 30.08.2017.
 */

public class UserDatabase extends SQLiteOpenHelper{
    public static final String DATABASE_NAME = "futplayers.db";
    public static final String USERS_TABLE_NAME = "users";
    public static final String USERS_COLUMN_USERNAME = "username";
    public static final String USERS_COLUMN_PASSWORD = "password";
    public static final String USERS_COLUMN_MAIL = "mail";
    Context context;

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE users (username TEXT PRIMARY KEY, password TEXT, mail TEXT)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean addUser(String username, String password, String mail){
        SQLiteDatabase db = this.getWritableDatabase();
        tableExists("users");
        ContentValues newUser = new ContentValues();
        newUser.put("username", username);
        newUser.put("password", password);
        newUser.put("mail", mail);

        try{
            db.insert("users", null, newUser);
            System.out.println("User successfully added to db.");
            return true;
        }
        catch (SQLiteDatatypeMismatchException e){
            System.out.println("Failed to add user");
            return false;
        }
    }

    public String[] getUserInfo(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM users WHERE username = ?",new String[]{username}, null);
        String [] info = new String[3];
        if(res.getCount()>0){
            res.moveToFirst();
                info[0] = res.getString(res.getColumnIndex(USERS_COLUMN_USERNAME));
                info[1] = res.getString(res.getColumnIndex(USERS_COLUMN_PASSWORD));
                info[2] = res.getString(res.getColumnIndex(USERS_COLUMN_MAIL));
                }
            return info;
        }

    private void tableExists(String tablename){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name= ?",new String[] {tablename}, null);
        if(res.getCount()==0){
            onCreate(db);
        }
    }
    public boolean userHasAccount(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT username FROM users WHERE username = ?", new String[]{username}, null);
        if(res.getCount()>0){
            return true;
        }
        return false;
    }

    public boolean userLogin(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT username FROM users WHERE username = ? AND password = ?", new String[]{username, password}, null);
        if(res.getCount()>0){
            return true;
        }
        return false;
    }

}

