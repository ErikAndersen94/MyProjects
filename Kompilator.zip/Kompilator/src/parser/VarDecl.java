package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class VarDecl extends PascalDecl{
	Type t;
	String name;
	types.Type type;
	int blokkNiv�;
	int offset;
	
	VarDecl(String id,int lnum) {
		super(id, lnum);
	}

	@Override
	public String identify() {
		return "<VarDecl> on line " + lineNum;
	}
	
	static VarDecl parse(Scanner s){
		enterParser("VarDecl");
		VarDecl vd = new VarDecl(s.curToken.id, s.curLineNum());

		s.test(nameToken);
		vd.name = s.curToken.id;
		s.skip(nameToken);
		s.skip(colonToken);
		vd.t = Type.parse(s);
		s.skip(semicolonToken);
		leaveParser("VarDecl");
		return vd;
	}
	
	@Override
	void prettyPrint() {
		Main.log.prettyIndent();
		Main.log.prettyPrint(name);
		Main.log.prettyPrint(": ");
		t.prettyPrint();
		Main.log.prettyPrintLn(";");
		Main.log.prettyOutdent();
	}
	@Override
	void check(Block curScope, Library lib){
		//pd = (PascalDecl) this;
		curScope.addHashDecl(name, this);
		t.check(curScope, lib);
		type = t.type;
	}

	
	@Override
	void checkWhetherAssignable(PascalSyntax where) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void checkWhetherFunction(PascalSyntax where) {
		where.error("Variable cannot be a function.");		
	}

	@Override
	void checkWhetherProcedure(PascalSyntax where) {
		where.error("Variable cannot be a procedure.");
		
	}

	@Override
	void checkWhetherValue(PascalSyntax where) {
		// TODO Auto-generated method stub
		
	}
	
	void genCode(CodeFile f){
		t.blokkNiv� = blokkNiv�;
		t.genCode(f);
	}
}
