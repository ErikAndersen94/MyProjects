package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class VarDeclPart extends Block {
	VarDecl vDecl;
	VarDecl [] vDeclArray = new VarDecl[10];
	int index = 0;
	int pos = 0;
	int blokkNiv�;
	
	VarDeclPart(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<VarDeclPart> on line " + lineNum;
	}
	
	static VarDeclPart parse(Scanner s){
		boolean loop = true;
		enterParser("VarDeclPart");
		s.skip(varToken);
		VarDeclPart vdp = new VarDeclPart(s.curLineNum());
		while(loop){
			vdp.vDecl = VarDecl.parse(s);
			vdp.vDeclArray[vdp.index++] = vdp.vDecl;
			if(!s.curToken.kind.equals(nameToken)){
				loop = false;
			}
			if(vdp.index == vdp.vDeclArray.length){
				VarDecl [] vtemp = vdp.vDeclArray;
				vdp.vDeclArray = new VarDecl[vdp.index*2];
				for(int i = 0; i<vtemp.length; i++){
					vdp.vDeclArray[i] = vtemp[i];
				}
			}
		}
		leaveParser("VarDeclPart");
		
		return vdp;
	}
	
	@Override
	void prettyPrint() {
		int index = 0;
		Main.log.prettyPrintLn("var");
		while(vDeclArray[index] != null){
			vDeclArray[index++].prettyPrint();
		}
	}
	// Kaller check metoden for alle deklarasjonene av parametere.
	@Override
	void check(Block curScope, Library lib){
		int x = -36;
		while(vDeclArray[pos]!= null){
			vDeclArray[pos].offset = x;
			vDeclArray[pos].check(curScope, lib);
			pos++;
			x = x-4;
		}
	}
	
	/*
	 * Regner ut offset i check-metoden. Denne hentes s� ut senere av variable der den er bundet til varDecl-objektet.
	 */
	@Override
	void genCode(CodeFile f){
		while(vDeclArray[pos]!= null){
			vDeclArray[pos].blokkNiv� = blokkNiv�;
			vDeclArray[pos].genCode(f);
			pos++;
		}
	}
}