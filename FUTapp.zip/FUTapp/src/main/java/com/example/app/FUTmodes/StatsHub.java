package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class StatsHub extends AppCompatActivity {
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats_hub);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
    }

    public void onUpdateStats(View view) {
        Intent myIntentUpdateStats = new Intent(StatsHub.this, UpdateStatsActivity.class);
        myIntentUpdateStats.putExtra("username", username);
        StatsHub.this.startActivity(myIntentUpdateStats);
    }

    public void onShowStats(View view){
        Intent myIntentShowStats = new Intent(StatsHub.this, ShowStatsActivity.class);
        myIntentShowStats.putExtra("username", username);
        StatsHub.this.startActivity(myIntentShowStats);
    }

    public void onCreateSquad(View view){
        Intent myIntentCreateSquad = new Intent(StatsHub.this, CreateSquad.class);
        myIntentCreateSquad.putExtra("username", username);
        StatsHub.this.startActivity(myIntentCreateSquad);
    }

    public void onViewSquads(View view){
        Intent myIntentViewSquad = new Intent(StatsHub.this, ViewSquads.class);
        myIntentViewSquad.putExtra("username", username);
        StatsHub.this.startActivity(myIntentViewSquad);
    }
    public void onAddMatchStats(View view){
        Intent myIntentAddMatchStatsForSquad = new Intent(StatsHub.this, AddMatchStatsForSquad.class);
        myIntentAddMatchStatsForSquad.putExtra("username", username);
        StatsHub.this.startActivity(myIntentAddMatchStatsForSquad);
    }
}
