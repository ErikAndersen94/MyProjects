package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class CompoundStatement extends Statement {
	StatmList sl;
	int blokkNiv�;

	CompoundStatement(int lnum) {
		super(lnum);
	}

	public String identify() {
		return "<compound statement> on line " + lineNum;
	}

	static CompoundStatement parse(Scanner s) {
		enterParser("compund statement");
		CompoundStatement cs = new CompoundStatement(s.curLineNum());
		s.skip(beginToken);
		cs.sl = StatmList.parse(s);
		s.skip(endToken);

		leaveParser("compound statement");
		return cs;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrintLn("begin ");
		sl.prettyPrint();
		Main.log.prettyPrintLn("end");
	}
	
	@Override
	void check(Block curScope, Library lib){
		sl.check(curScope, lib);
	}
	@Override
	void genCode(CodeFile f){
		sl.blokkNiv� = blokkNiv�;
		sl.genCode(f);
	}
}
