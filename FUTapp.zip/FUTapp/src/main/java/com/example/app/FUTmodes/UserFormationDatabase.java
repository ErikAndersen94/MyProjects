package com.example.app.FUTmodes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Ola on 05.09.2017.
 */

public class UserFormationDatabase extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "futplayers.db";
    public static final String USERFORMATIONSTATS_TABLE_NAME = "userFormationStats";
    public static final String USERFORMATIONSTATS_COLUMN_USERNAME = "username";
    public static final String USERFORMATIONSTATS_COLUMN_FORMATIONNAME = "formationname";
    public static final String USERFORMATIONSTATS_COLUMN_MATCHES = "matches";
    public static final String USERFORMATIONSTATS_COLUMN_WINS = "wins";
    public static final String USERFORMATIONSTATS_COLUMN_DRAWS = "draws";
    public static final String USERFORMATIONSTATS_COLUMN_LOSSES = "losses";
    public static final String USERFORMATIONSTATS_COLUMN_GOALSSCORED = "goalsScored";
    public static final String USERFORMATIONSTATS_COLUMN_GOALSCONCEDED = "goalsConceded";
    public static final String USERFORMATIONSTATS_COLUMN_POSSESSION = "possession";
    public static final String USERFORMATIONSTATS_COLUMN_SHOTSFOR = "shotsFor";
    public static final String USERFORMATIONSTATS_COLUMN_SHOTSAGAINST = "shotsAgainst";

    Context context;


    public UserFormationDatabase(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context=context;
    }

    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE userFormationStats (username TEXT, formationname TEXT, matches NUM, wins NUM, draws NUM, losses NUM, goalsScored NUM, goalsConceded NUM, " +
                "possession NUM, shotsFor NUM, shotsAgainst NUM, PRIMARY KEY(username, formationname))"
        );
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
    }

    public boolean add(String username, String formationname, String points, String goalsScored, String goalsConceded, String possession, String shotsFor, String shotsAgainst){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='userFormationStats'", null);
        if(res.getCount()==0){
            onCreate(db);
        }
        if(formationUsed(username, formationname)){
            // Update formation
            update(username, formationname, points, goalsScored, goalsConceded, possession, shotsFor, shotsAgainst);
        }
        else{
            // Create new instance
            create(username, formationname, points, goalsScored, goalsConceded, possession, shotsFor, shotsAgainst);
        }

        return false;
    }

    private void update(String username, String formationname, String points, String goalsScored, String goalsConceded, String possession, String shotsFor, String shotsAgainst){
        String win;
        String draw;
        String loss;
        if(points.equals("3")){
            win = "1";
            draw = "0";
            loss = "0";
        }
        else if(points.equals("1")){
            win = "0";
            draw = "1";
            loss = "0";
        }
        else{
            win = "0";
            draw = "0";
            loss = "1";
        }
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE " + USERFORMATIONSTATS_TABLE_NAME + " SET " + USERFORMATIONSTATS_COLUMN_MATCHES + "=" + USERFORMATIONSTATS_COLUMN_MATCHES + "+? ,"
                + USERFORMATIONSTATS_COLUMN_WINS + "=" + USERFORMATIONSTATS_COLUMN_WINS + "+?, " + USERFORMATIONSTATS_COLUMN_DRAWS + "=" + USERFORMATIONSTATS_COLUMN_DRAWS + "+? ," +
                USERFORMATIONSTATS_COLUMN_LOSSES + "=" + USERFORMATIONSTATS_COLUMN_LOSSES + "+? ," + USERFORMATIONSTATS_COLUMN_GOALSSCORED + "=" + USERFORMATIONSTATS_COLUMN_GOALSSCORED + "+?, "
                + USERFORMATIONSTATS_COLUMN_GOALSCONCEDED + "=" + USERFORMATIONSTATS_COLUMN_GOALSCONCEDED + "+?, " + USERFORMATIONSTATS_COLUMN_POSSESSION + "=" +
                USERFORMATIONSTATS_COLUMN_POSSESSION + "+?, " + USERFORMATIONSTATS_COLUMN_SHOTSFOR + "=" + USERFORMATIONSTATS_COLUMN_SHOTSFOR + "+?, " +
                USERFORMATIONSTATS_COLUMN_SHOTSAGAINST + "=" + USERFORMATIONSTATS_COLUMN_SHOTSAGAINST + "+? " + "WHERE username = ? AND formationname = ?"
                , new String[]{"1", win, draw, loss, goalsScored, goalsConceded, possession, shotsFor, shotsAgainst, username, formationname});

    }

    private void create(String username, String formationname, String points, String goalsScored, String goalsConceded, String possession, String shotsFor, String shotsAgainst){
        SQLiteDatabase db = this.getWritableDatabase();
        String win;
        String draw;
        String loss;
        if(points.equals("3")){
            win = "1";
            draw = "0";
            loss = "0";
        }
        else if(points.equals("1")){
            win = "0";
            draw = "1";
            loss = "0";
        }
        else{
            win = "0";
            draw = "0";
            loss = "1";
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("formationname", formationname);
        contentValues.put("matches", "1");
        contentValues.put("wins", win);
        contentValues.put("draws", draw);
        contentValues.put("losses", loss);
        contentValues.put("goalsScored", goalsScored);
        contentValues.put("goalsConceded", goalsConceded);
        contentValues.put("possession", possession);
        contentValues.put("shotsFor", shotsFor);
        contentValues.put("shotsAgainst", shotsAgainst);
        db.insert("userFormationStats", null, contentValues);

    }

    private boolean formationUsed(String username, String formationname){
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from userFormationStats where username = ? and formationname = ?", new String[]{username, formationname}, null);
        if (res.getCount() <= 0) {
            res.close();
            return false;
        }
        res.close();
        return true;
    }

    public void refreshTable(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS userFormationStats");
        onCreate(db);
    }

    public String [] getFormationInfo(String username, String formation){
        createTableIfNotExists();
        String [] formationInfo = new String [10];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "SELECT * FROM userFormationStats WHERE username = ? AND formationname = ?",new String []{username, formation}, null);
        res.moveToFirst();

        while(res.isAfterLast() == false){
            formationInfo[0] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_FORMATIONNAME));
            formationInfo[1] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_MATCHES));
            formationInfo[2] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_WINS));
            formationInfo[3] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_DRAWS));
            formationInfo[4] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_LOSSES));
            formationInfo[5] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_GOALSSCORED));
            formationInfo[6] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_GOALSCONCEDED));
            formationInfo[7] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_POSSESSION));
            formationInfo[8] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_SHOTSFOR));
            formationInfo[9] = res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_SHOTSAGAINST));
            res.moveToNext();
        }
        res.close();
        return formationInfo;
    }

    public void printInfo(String username){
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "SELECT * FROM userFormationStats WHERE username = ?",new String []{username}, null);
        res.moveToFirst();
        int matches;
        int totalpossession;
        while(res.isAfterLast() == false){
            System.out.println("Formation: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_FORMATIONNAME)));
            matches = Integer.parseInt(res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_MATCHES)));
            System.out.println("Matches: " + matches);
            System.out.println("Wins: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_WINS)));
            System.out.println("Draws: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_DRAWS)));
            System.out.println("Losses: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_LOSSES)));
            System.out.println("Goals scored: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_GOALSSCORED)));
            System.out.println("Goals conceded: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_GOALSCONCEDED)));
            totalpossession = Integer.parseInt(res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_POSSESSION)));
            System.out.println("Possession: " + totalpossession/matches);
            System.out.println("Shots for: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_SHOTSFOR)));
            System.out.println("Shots against: " + res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_SHOTSAGAINST)));
            res.moveToNext();
        }
        res.close();
    }

    public ArrayList<String> getBestFormation(String username){
        createTableIfNotExists();
        ArrayList<String> form = new ArrayList<String>();
         SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("SELECT formationname, (wins/matches) as winrate FROM userFormationStats WHERE username = ? AND winrate = " +
                "(SELECT MAX(wins/matches) FROM userFormationStats WHERE username =?)",new String []{username, username}, null);
        res.moveToFirst();
        while(res.isAfterLast() == false){
            form.add(res.getString(res.getColumnIndex(USERFORMATIONSTATS_COLUMN_FORMATIONNAME)));
            res.moveToNext();
        }
        return form;
    }

    public void createTableIfNotExists(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='userFormationStats'", null);
        if(res.getCount()==0){
            onCreate(db);
        }
    }
}
