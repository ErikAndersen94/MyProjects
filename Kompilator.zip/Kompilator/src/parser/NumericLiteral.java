package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class NumericLiteral extends UnsignedConstant{
	int constVal;
	int blokkNiv�;
	NumericLiteral(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<NumericLiteral> on line " + lineNum;
	}
	// Oppretter objekt av seg selv. Sjekker s� om curToken er en intvaltoken. Hvis den er det lagres vi int-verdien
	// i en variabel s� vi kan skrive den ut ved prettyprint.
	static NumericLiteral parse(Scanner s){
		enterParser("NumericLiteral");
		NumericLiteral nl = new NumericLiteral(s.curLineNum());
		s.test(intValToken);
		nl.constVal = s.curToken.intVal;
		s.skip(intValToken);
		
		leaveParser("NumericLiteral");
		
		return nl;
	}
	@Override
	void prettyPrint() {
		String s = Integer.toString(constVal);
		Main.log.prettyPrint(s);
	}
	@Override
	void check(Block curScope, Library lib){
	}
	
	@Override
	void genCode(CodeFile f){
		f.genInstr("", "movl", "$" + constVal + ",%eax", " '" + constVal + "'");
	}
}

