package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class TypeName extends Type {
	String name;
	TypeDecl tdRef;
	types.Type type;

	TypeName(int lnum) {
		super(lnum);
	}

	public String identify() {
		return "<TypeName> on line " + lineNum;
	}

	static TypeName parse(Scanner s) {
		enterParser("TypeName");
		TypeName tn = new TypeName(s.curLineNum());
		s.test(nameToken);
		tn.name = s.curToken.id;
		s.skip(nameToken);

		leaveParser("TypeName");
		return tn;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
	}
	
	/*
	 * Basert p� hva s�ken�kkelen som hentet fra hashmappet er, settes typen til enten 
	 * boolean, char eller integer.
	 */
	@Override
	void check(Block curScope, Library lib) {
		PascalDecl d = curScope.findDecl(name, this);
		tdRef = (TypeDecl) d;
		if (tdRef.libId == "integer") {
			type = lib.intType;
		} else if (tdRef.libId == "char") {
			type = lib.charType;
		} else if (tdRef.libId == "boolean") {
			type = lib.boolType;
		}
	}
	
	@Override
	void genCode(CodeFile f){
	}
}