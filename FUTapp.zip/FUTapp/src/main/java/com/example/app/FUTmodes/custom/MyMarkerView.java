package com.example.app.FUTmodes.custom;

/**
 * Created by ErikStorholm on 21/01/2017.
 */




import android.content.Context;
import android.widget.TextView;

import com.example.app.FUTmodes.R;
import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;
//import com.xxmassdeveloper.mpchartexample.R;
import java.util.ArrayList;

import java.text.DecimalFormat;

/**
 * Custom implementation of the MarkerView.
 *
 * @author Philipp Jahoda
 */

/*
    DENNE KLASSEN HAR ERIK ENDRET!!!!!
    HER LIGGER ALL KODEN FOR Å ENDRE TEKSTEN SOM KOMMER NÅR MAN TRYKKER PÅ SØYLENE

 */
public class MyMarkerView extends MarkerView {
    ArrayList<String> players;
    private TextView tvContent;
//    private IAxisValueFormatter xAxisValueFormatter;

    private DecimalFormat format;
    String[] names = new String[10];

    public MyMarkerView(Context context,  ArrayList<String> tempplayers) {
        //public XYMarkerView(Context context, IAxisValueFormatter xAxisValueFormatter) {
        super(context, R.layout.custom_marker_view);
        // E: Dette arrayet kan tilpasses til å gi den teksten man vil over søylene.
        players = tempplayers;
        //      this.xAxisValueFormatter = xAxisValueFormatter;

        tvContent = (TextView) findViewById(R.id.tvContent);
        //tvContent.setText(Arrays.toString(names));
        format = new DecimalFormat("###.0");
    }

    // callbacks everytime the MarkerView is redrawn, can be used to update the
    // content (user-interface)
    @Override
    public void refreshContent(Entry e, Highlight highlight) {
        //System.out.println("HERERJEG!!");
        //tvContent.setText(names[Integer.parseInt(xAxisValueFormatter.getFormattedValue(e.getX(), null))-1]);
        //E: Her settes teksten som står over søylene, bruker nummeret på X-aksen -> e.getX i tillegg til arrayet names.
        String søyleTopp = "Nr " + String.format(Math.round(e.getX()) + ": "  + names[Math.round(e.getX())-1]);
        //System.out.println(søyleTopp);
        tvContent.setText(søyleTopp);
        super.refreshContent(e, highlight);
    }

    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2), -getHeight());
    }
}
