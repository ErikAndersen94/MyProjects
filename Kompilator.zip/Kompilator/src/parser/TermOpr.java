package parser;

import main.*;
import static scanner.TokenKind.*;

import scanner.Scanner;

public class TermOpr extends SimpleExpression {
	String name;
	types.Type type;

	TermOpr(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<term opr> on line " + lineNum;
	}

	static TermOpr parse(Scanner s) {
		enterParser("term opr");
		TermOpr topr = new TermOpr(s.curLineNum());
		if (s.curToken.kind.equals(addToken)) {
			topr.name = " + ";
			s.skip(addToken);
		} else if (s.curToken.kind.equals(subtractToken)) {
			topr.name = " - ";
			s.skip(subtractToken);
		} else if (s.curToken.kind.equals(orToken)) {
			topr.name = " or ";
			s.skip(orToken);
		} else {
			System.out.println("Feil! Ugyldig tegn");
		}
		leaveParser("term opr");
		return topr;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
	}
	//Henviser til factorOpr. Samme tankegang
	@Override
	void check(Block curScope, Library lib){
		if (name.equals(" or ")) {
			type = lib.boolType;
		} else {
			type = lib.intType;
		}
	}
}
