package com.example.app.FUTmodes;

import java.io.Serializable;

/**
 * Created by Ola on 12.01.2017.
 */

public class Player implements Serializable{
    String name;
    int goals;
    int assists;
    int totalPoints;
    int matchesPlayed;
    int skillMoves;
    int weakFoot;
    String position;
    int rating;
    String nationality;
    double avgPointsMath;
    int [] goalsLast5;
    int [] assistsLast5;

    Player(String name, int sm, int wf, String pos, String nationality, int goals, int assists, int matches){
        this.name = name;
        this.skillMoves = sm;
        this.weakFoot = wf;
        this.position = pos;
        this.nationality = nationality;
        this.goals = goals;
        this.assists = assists;
        this.totalPoints = this.assists + this.goals;
        this.matchesPlayed = matches;
        avgPointsMath =  (double) totalPoints / (double) matchesPlayed;
        goalsLast5 = new int[5];
        assistsLast5 = new int[5];
}
    Player(String name, int sm, int wf, String pos, String nationality){
        this.name = name;
        this.skillMoves = sm;
        this.weakFoot = wf;
        this.position = pos;
        this.nationality = nationality;
        this.goals = 0;
        this.assists = 0;
        this.totalPoints = this.assists + this.goals;
        this.matchesPlayed = 0;
        avgPointsMath =  (double) totalPoints / (double) matchesPlayed;
        goalsLast5 = new int[5];
        assistsLast5 = new int[5];
        for(int i = 0; i<5; i++){
            goalsLast5[i] = -1;
            assistsLast5[i] = -1;
        }
    }


    public void addGoals(int matchGoals){
        goals += matchGoals;
        totalPoints = goals + assists;
        boolean foundPlace = false;
        for(int i = 0; i<goalsLast5.length; i++){
            if(goalsLast5[i] == -1 && foundPlace == false){
                goalsLast5[i] = matchGoals;
                foundPlace = true;
            }
        }
        if(foundPlace == false){
            // need to get rid of the first value in the array and move all the other ones
            // to one index less.
            for(int i = 0; i < goalsLast5.length-1; i++){
                goalsLast5[i] = goalsLast5[i+1];
            }
            goalsLast5[goalsLast5.length-1] = matchGoals;
        }
    }

    public void addAssists(int matchAssists){
        assists += matchAssists;
        totalPoints = goals + assists;
        matchesPlayed = matchesPlayed +1;
        avgPointsMath =  (double) totalPoints / (double) matchesPlayed;

        boolean foundPlace = false;
        for(int i = 0; i<assistsLast5.length; i++){
            if(assistsLast5[i] == -1 && foundPlace == false){
                assistsLast5[i] = matchAssists;
                foundPlace = true;
            }
        }
        if(foundPlace == false){
            // need to get rid of the first value in the array and move all the other ones
            // to one index less.
            for(int i = 0; i < assistsLast5.length-1; i++){
                assistsLast5[i] = assistsLast5[i+1];
            }
            assistsLast5[assistsLast5.length-1] = matchAssists;
        }
    }

    public String getName(){
        return name;
    }
}
