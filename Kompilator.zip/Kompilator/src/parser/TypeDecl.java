package parser;

/*
 * Denne klassen er en subklasse av PascalDecl og brukes som en kobling mellom int, char og boolean og types-pakken
 * sine klasse BoolType, CharType og IntType.
 */
public class TypeDecl extends PascalDecl {
	
	types.Type type;
	String libId;
	TypeDecl(String id, int lNum) {
		super(id, lNum);
		libId = id;
	}
	
	@Override
	public String identify() {
		return "<type decl> " + libId + " in the library";
	}
	
	void setType(types.Type type){
		this.type = type;
	}

	@Override
	void checkWhetherAssignable(PascalSyntax where) {
		where.error("You can not assign to a type decl.");
		
	}

	@Override
	void checkWhetherFunction(PascalSyntax where) {
		where.error("type decl cannot be a function.");		
	}

	@Override
	void checkWhetherProcedure(PascalSyntax where) {
		where.error("type decl cannot be a procedure.");		
	}

	@Override
	void checkWhetherValue(PascalSyntax where) {
		where.error("type decl cannot have a value.");
		
	}

	@Override
	void check(Block curScope, Library lib) {
		// TODO Auto-generated method stub
		
	}


	@Override
	void prettyPrint() {
		// TODO Auto-generated method stub
		
	}

}
