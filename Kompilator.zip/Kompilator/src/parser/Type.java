package parser;

import scanner.*;
import static scanner.TokenKind.*;

import main.CodeFile;

public class Type extends VarDecl {
	ArrayType at;
	TypeName tn;
	types.Type type;
	int blokkNiv�;
	
	Type(int lnum) {
		super("", lnum);
	}

	public String identify() {
		return "<Type> on line " + lineNum;
	}

	static Type parse(Scanner s) {
		enterParser("Type");
		Type t = new Type(s.curLineNum());

		// Sjekker om curToken er en nameToken eller ArrayToken. Utfallet velger
		// hvilket objekt som skal kalles
		if (s.curToken.kind.equals(nameToken)) {
			t.tn = TypeName.parse(s);
		} else if (s.curToken.kind.equals(arrayToken)) {
			t.at = ArrayType.parse(s);
		} else {
			System.out.println("Feil! Ugyldig tegn");
		}
		leaveParser("Type");
		return t;
	}

	@Override
	void prettyPrint() {
		if (at != null) {
			at.prettyPrint();
		} else if (tn != null) {
			tn.prettyPrint();
		}
	}

	// Type sin type peker enten til typename sin type eller til arraytype sin type.
	@Override
	void check(Block curScope, Library lib) {
		if (tn != null) {
			tn.check(curScope, lib);
			type = tn.type;
		} else if (at != null) {
			at.check(curScope, lib);
			type = at.type;
		}
	}
	
	@Override
	//Tester p� om vi har typename eller arraytype.
	//Setter blokkniv� og kaller videre inn p� genCode utifra hvilken if-test som sl�r til.
	void genCode(CodeFile f){
		if(tn != null){
			tn.blokkNiv� = blokkNiv�;
			tn.genCode(f);
		}
		else if(at != null){
			at.blokkNiv� = blokkNiv�;
			at.genCode(f);
		}
	}
}
