package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class Statement extends StatmList {
	ProcCall pc;
	EmptyStatement es;
	IfStatm is;
	AssignStatm as;
	WhileStatement ws;
	CompoundStatement cs;
	int blokkNiv�;

	Statement(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<statement> on line " + lineNum;
	}

	static Statement parse(Scanner s) {
		enterParser("statement");
		Statement sm = new Statement(s.curLineNum());

		if (s.curToken.kind.equals(nameToken)) {
			if (s.nextToken.kind.equals(assignToken) || s.nextToken.kind.equals(leftBracketToken)) {
				sm.as = AssignStatm.parse(s);
			} else {
				sm.pc = ProcCall.parse(s);
			}
		} else if (s.curToken.kind.equals(ifToken)) {
			sm.is = IfStatm.parse(s);
		} else if (s.curToken.kind.equals(whileToken)) {
			sm.ws = WhileStatement.parse(s);
		} else if (s.curToken.kind.equals(beginToken)) {
			sm.cs = CompoundStatement.parse(s);
		} else {
			sm.es = EmptyStatement.parse(s);
		}

		leaveParser("statement");
		return sm;
	}

	@Override
	void prettyPrint() {
		if (as != null) {
			as.prettyPrint();
		} else if (pc != null) {
			pc.prettyPrint();
		} else if (is != null) {
			is.prettyPrint();
		} else if (ws != null) {
			ws.prettyPrint();
		} else if (cs != null) {
			cs.prettyPrint();
		} else if (es != null) {
			es.prettyPrint();
		}
	}

	@Override
	void check(Block curScope, Library lib) {
		if (as != null) {
			as.check(curScope, lib);
		}
		else if (pc != null) {
			pc.check(curScope, lib);
		}
		else if(is != null){
			is.check(curScope, lib);
		}
		else if(ws != null){
			ws.check(curScope, lib);
		}
		else if(cs != null){
			cs.check(curScope, lib);
		}
		else if(es != null){
			es.check(curScope, lib);
		}
		
	}
	
	@Override void genCode(CodeFile f) {
		if (as != null) {
			as.blokkNiv� = blokkNiv�;
			as.genCode(f);
		}
		else if (pc != null) {
			pc.blokkNiv� = blokkNiv�;
			pc.genCode(f);
		}
		else if(is != null){
			is.blokkNiv� = blokkNiv�;
			is.genCode(f);
		}
		else if(ws != null){
			ws.blokkNiv� = blokkNiv�;
			ws.genCode(f);
		}
		else if(cs != null){
			cs.blokkNiv� = blokkNiv�;
			cs.genCode(f);
		}
		else if(es != null){
			es.blokkNiv� = blokkNiv�;
			es.genCode(f);
		}
	}
}
