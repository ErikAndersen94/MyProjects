package parser;

import scanner.*;
import static scanner.TokenKind.*;

import main.CodeFile;

public class Factor extends Term {
	UnsignedConstant unco;
	Variable var;
	FuncCall fc;
	InnerExpr ie;
	Negation ng;
	types.Type type;
	int blokkNiv�;
	
	Factor(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<factor> on line " + lineNum;
	}

	static Factor parse(Scanner s) {
		enterParser("factor");
		Factor fact = new Factor(s.curLineNum());

		// Her bruker vi nextToken for � finne ut hvilken klasse symbolet v�rt
		// h�rer til.
		// Enkelte av disse klassene har veldig like jernbanediagram, s� vi er
		// n�dt til � ta nextToken i bruk i tillegg til
		// curToken.

		if (s.curToken.kind.equals(nameToken)) {
			if (s.nextToken.kind.equals(leftParToken)) {
				fact.fc = FuncCall.parse(s);
			} else {
				fact.var = Variable.parse(s);
			}
		} else if (s.curToken.kind.equals(leftParToken)) {
			fact.ie = InnerExpr.parse(s);
		}

		else if (s.curToken.kind.equals(notToken)) {
			fact.ng = Negation.parse(s);
			// negation
		} else if (s.curToken.kind.equals(charValToken) || s.curToken.kind.equals(intValToken)) {
			// F�rer oss til unsigned constant
			fact.unco = UnsignedConstant.parse(s);
		}

		leaveParser("factor");
		return fact;
	}

	@Override
	void prettyPrint() {
		if (unco != null) {
			unco.prettyPrint();
		} else if (var != null) {
			var.prettyPrint();
		} else if (fc != null) {
			fc.prettyPrint();
		} else if (ie != null) {
			ie.prettyPrint();
		} else if (ng != null) {
			ng.prettyPrint();
		}
	}

	/*
	 * Setter factor sin type til � peke p� et av objektenes type(det som er
	 * ulikt null), med mindre det er ng(negation), da er typen en boolean.
	 */
	@Override
	void check(Block curScope, Library lib) {
		if (fc != null) {
			fc.check(curScope, lib);
			type = fc.type;
		} else if (unco != null) {
			unco.check(curScope, lib);
			type = unco.type;
		} else if (var != null) {
			var.check(curScope, lib);
			type = var.type;
		} else if (ie != null) {
			ie.check(curScope, lib);
			type = ie.type;
		} else if (ng != null) {
			ng.check(curScope, lib);
			type = lib.boolType;
		}
	}

	void genCode(CodeFile f) {
		if (fc != null) {
			fc.blokkNiv� = blokkNiv�;
			fc.genCode(f);
		} else if (unco != null) {
			unco.blokkNiv� = blokkNiv�;
			unco.genCode(f);
		} else if (var != null) {
			var.blokkNiv� = blokkNiv�;
			var.genCode(f);
		} else if (ie != null) {
			ie.blokkNiv� = blokkNiv�;
			ie.genCode(f);
		} else if (ng != null) {
			ng.blokkNiv� = blokkNiv�;
			ng.genCode(f);
		}
	}
}
