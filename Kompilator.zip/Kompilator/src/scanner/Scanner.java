package scanner;

import main.Main;
import main.LogFile;
import static scanner.TokenKind.*;

import java.io.*;

public class Scanner {
	public Token curToken = null, nextToken = null;
	private LineNumberReader sourceFile = null;
	private String sourceFileName, sourceLine = "";
	private int sourcePos = 0;
	char c = 0;

	Boolean runIt = true;
	Boolean firstDefault = true;
	int index = 0;
	String symbol = null;
	StringBuilder sB = new StringBuilder();
	int lineNumb = 0;

	public Scanner(String fileName) throws IOException {
		sourceFileName = fileName;
		System.out.println(fileName);
		try {
			sourceFile = new LineNumberReader(new FileReader(fileName));
			
		} catch (FileNotFoundException e) {
			Main.error("Cannot read " + fileName + "!");
		}
		/*
		 * Leser f�rste linje og kaller p� readNextToken for f�rste gang for �
		 * starte prosessen, med � finne symbolene.
		 */
		readNextLine();
		lineNumb++;
		readNextToken();
		readNextToken();
	}

	public String identify() {
		return "Scanner reading " + sourceFileName;
	}

	public int curLineNum() {
		return curToken.lineNum;
	}

	private void error(String message) {
		Main.error("Scanner error on " + (curLineNum() < 0 ? "last line" : "line " + curLineNum()) + ": " + message);
	}

	/*
	 * Metoden som er hjertet av klassen. Det er denne metoden som s�rger for at
	 * vi finner symbolene vi er p� utkikk etter. Metoden l�per char for char
	 * frem til den finner ett symbol, s� avslutter den f�r den blir kalt p�
	 * igjen for � finne neste symbol. Slik holder det p� frem til filen ikke
	 * har flere linjer og den siste linja er tom. Vi har en while som l�per
	 * helt frem til ett symbol er funnet, da endres runIt fra true til false,
	 * og vi avslutter metoden. Underveis n�r vi finner ett symbol, s� logger vi
	 * dette ved hjelp av Main.log.noteToken.
	 */

	public void readNextToken() {
		if (sourceFile != null) {
			runIt = true;
			curToken = nextToken;
			nextToken = null;
			while (runIt) {
				if (sourceLine.length() == index) {
					readNextLine();
					if (sourceLine.isEmpty()) {
						runIt = false;
						nextToken = new Token("e-o-f", 0);
						Main.log.noteToken(nextToken);
						break;
					}
					lineNumb++;
					index = 0;
				}
				char s = sourceLine.charAt(index++);
				switch (s) {
				case '\n':
					updateSymbol();
					break;
				case '/':
					int tempNumb = lineNumb;
					updateSymbol();
					s = sourceLine.charAt(index);
					if (s == '*') {
						index++;
						/*
						 * Symbol for start av kommentar: /* Kommentar starter,
						 * holder p� frem til vi m�ter p� avslutningssymbolene
						 * for kommentarer.
						 * 
						 * Har en while-loop som l�per, s� lenge linja ikke er
						 * tom og linjas f�rstkommende tegn ikke er * eller
						 * linjas neste tegn ikke er /. Hvis noen av disse
						 * tilfellene treffer, s� betyr det at enten er linja
						 * tom og vi kan ha en evig kommentar, evt kan det hende
						 * vi treffer p� kriteret for at kommentaren avsluttes.
						 */

						while ((!sourceLine.isEmpty())
								&& ((sourceLine.charAt(index) != '*') || (sourceLine.charAt(index + 1) != '/'))) {

							/*
							 * I if-testen under �ker vi testing av index med 1
							 * fordi vi i while-testen over jobber med en verdi
							 * som er 1 st�rre enn index egt. er(index + 1). Vi
							 * m� ogs� sette -1 etter sourceLine.length() fordi
							 * linja er char array som starter p� 0 og l�per til
							 * sourceLine.length() - 1. Testen er til for �
							 * hindre at programmet l�per out of bounds. Hvis
							 * if-testen sl�r til starter vi � lese p� ny linje.
							 */

							if (index + 1 >= sourceLine.length() - 1) {
								readNextLine();
								lineNumb++;
								index = 0;
							} else {
								index++;
							}
						}

						/*
						 * Hvis linja er tom(alts� en blank linje vil ha v�re
						 * "tom", men en end-of-file "linje" vil v�re helt tom,
						 * og derfor kan man alts� finne ut om filen er
						 * ferdiglest hvis linja er tom. Hvis linja er tom og
						 * kommentaren ikke er avsluttet, s� har man en evig
						 * kommentar.
						 */
						if (sourceLine.isEmpty()) {
							Main.log.noteError("Scanner error on line " + tempNumb
									+ ": No end for comment starting on line " + tempNumb + "!");
							Main.log.noteError("Terminating program");
							System.exit(0);
						}
						/*
						 * Kommentar slutt, m� �ke index med 2 slik at den
						 * sjekker riktig char neste gang.
						 */
						index = index + 2;
					}
					break;

				case '{':
					tempNumb = lineNumb;
					updateSymbol();
					index++;
					/*
					 * En annen m�te � skrive kommentarer p�. Har en while-loop
					 * som itererer gjennom linja frem til den m�ter p�
					 * avslutningsblokken "}".
					 */
					while ((!sourceLine.isEmpty()) && (sourceLine.charAt(index) != '}')) {
						if (index >= sourceLine.length() - 1) {
							readNextLine();
							lineNumb++;
							index = 0;
						} else {
							index++;
						}
					}
					if (sourceLine.isEmpty()) {
						Main.log.noteError("Scanner error on line " + tempNumb
								+ ": No end for comment starting on line " + tempNumb + "!");
						Main.log.noteError("Terminating program");
						System.exit(0);
					}
					index++;
					break;
				case '(':
					updateSymbol();
					symbol = Character.toString(s);
					break;
				case '=':
					updateSymbol();
					symbol = Character.toString(s);
					break;
				case ')':
					updateSymbol();
					symbol = Character.toString(s);
					break;
				case ' ':
					updateSymbol();
					break;
				case '.':
					updateSymbol();
					sB.append(s);
					s = sourceLine.charAt(index);
					if (s == '.') {
						sB.append(s);
						index++;
					}
					symbol = sB.toString();
					break;
				case ',':
					updateSymbol();
					symbol = Character.toString(s);
					break;
				case 39:
					/*
					 * Ascii-verdi 39 tilsvarer apostrof Dette caset tar for seg
					 * tilfeller hvor symbolet er apostrof. Da vet vi at det
					 * kommer en enkelt char som neste tegn som blir symbolet.
					 * Sender inn char'en til en konstrukt�r egnet for dette i
					 * Token-filen.
					 * 
					 * Hvis det viser seg at det tredje tegnet ikke er en fnutt
					 * alts� at vi f.eks har: 'Cx, s� er det et ulovlig tegn. Vi
					 * vet derfor at alle char skal v�re p� formen 'X'. Alts�
					 * fnutt i 1 og 3 pos.
					 */
					updateSymbol();
					c = sourceLine.charAt(index++);
					if (sourceLine.charAt(index++) != 39) {
						Main.log.noteError("Scanner error on line " + lineNumb + ": Illegal char literal!");
						Main.log.noteError("Terminating program");
						System.exit(0);
					}
					/*
					 * If-testen under er spesialtilfelle hvor vi har ''''.
					 * Dette blir logget som tegnet '.
					 */
					if (sourceLine.charAt(index) == 39) {
						c = 39;
						index++;
					}
					//nextToken = new Token(c, lineNumb);
					//symbol = null;
					//sB.setLength(0);
					//Main.log.noteToken(nextToken);
					break;

				case ';':
					updateSymbol();
					symbol = Character.toString(s);
					break;

				case ':':
					updateSymbol();
					sB.append(s);
					s = sourceLine.charAt(index);
					if (s == '=') {
						sB.append(s);
						index++;
					}
					symbol = sB.toString();
					break;

				case '\t':
					updateSymbol();
					break;

				case '+':
					updateSymbol();
					symbol = Character.toString(s);
					break;

				case '>':
					updateSymbol();
					sB.append(s);
					s = sourceLine.charAt(index);
					if (s == '=') {
						sB.append(s);
						index++;
					}
					symbol = sB.toString();
					break;

				case '<':
					updateSymbol();
					sB.append(s);
					s = sourceLine.charAt(index);
					if (s == '=') {
						sB.append(s);
						index++;
					} else if (s == '>') {
						sB.append(s);
						index++;
					}
					symbol = sB.toString();
					break;

				case '[':
					updateSymbol();
					symbol = Character.toString(s);
					break;

				case ']':
					updateSymbol();
					symbol = Character.toString(s);
					break;

				case '*':
					updateSymbol();
					symbol = Character.toString(s);
					break;

				case '-':
					updateSymbol();
					symbol = Character.toString(s);
					break;

				case '_':
					updateSymbol();
					Main.log.noteError("Scanner error on line " + lineNumb + ": Illegal character: '_'!");
					Main.log.noteError("Terminating program");
					System.exit(0);
				default:
					/*
					 * Hvis det er f�rste tegn i symbolet, s� kaller vi
					 * updateSymbol. Grunnen til dette er fordi vi vil s�rge for
					 * at det forrige symbolet som ble lagret i stringen symbol
					 * blir sendt til logging. S� nullstilles stringen og nye
					 * char's kan bli lagret i stringen.
					 */
					if (!isLetterAZ(s) && !isDigit(s)) {
						updateSymbol();
						Main.log.noteError("Scanner error on line " + lineNumb + ": Illegal character: '" + s + "'!");
						Main.log.noteError("Terminating program");
						System.exit(0);
					} else {
						if (firstDefault) {
							updateSymbol();
							sB.append(s);
							symbol = sB.toString();
							firstDefault = false;
						} else {
							sB.append(s);
							symbol = sB.toString();
						}
					}
				}
			}
		}
	}

	/*
	 * Hjelpemetode for � oppdatere alle symbol funnet fortl�pende. Hver gang vi
	 * treffer p� et nytt case av et symbol, logger vi det forrige symbolet vi
	 * har samlet opp, som regel i stringen symbol. Etter symbolet har blitt
	 * logget, nullstilles stringen slik at den har plass til nye verdier. Vi
	 * setter ogs� runIt til false, som gj�r at while-loopen ikke itererer
	 * gjennom readNextToken f�r den blir kalt p� nytt utenifra. 
	 * Har ogs� en egen test som sjekker om verdien som skal logges er en int eller en string.
	 * Dette er vesentlig for � finne ut hva slags konstrukt�r man skal kalle p�.
	 */
	public void updateSymbol() {
		int posCounter = 0;
		boolean isNumb = false;
		if (symbol != null) {
			runIt = false;
			while (symbol.length() > posCounter) {
				char f = symbol.charAt(posCounter);
				isNumb = isDigit(f);
				if (isNumb == false) {
					break;
				}
				posCounter++;
			}
			if (!isNumb) {
				nextToken = new Token(symbol, lineNumb);
			} else {
				int symbolNumber = Integer.parseInt(symbol);
				nextToken = new Token(symbolNumber, lineNumb);
			}
			symbol = null;
			sB.setLength(0);
			Main.log.noteToken(nextToken);
		}
		else if(c!= 0){
			runIt = false;
			nextToken = new Token(c, lineNumb);
			c = 0;
			Main.log.noteToken(nextToken);
		
		}
		firstDefault = true;
	}

	private void readNextLine() {
		if (sourceFile != null) {
			try {
				sourceLine = sourceFile.readLine();
				if (sourceLine == null) {
					sourceFile.close();
					sourceFile = null;
					sourceLine = "";
				} else {
					sourceLine += " ";
				}
				sourcePos = 0;
			} catch (IOException e) {
				Main.error("Scanner error: unspecified I/O error!");
			}
		}
		if (sourceFile != null)
			Main.log.noteSourceLine(getFileLineNum(), sourceLine);
	}

	private int getFileLineNum() {
		return (sourceFile != null ? sourceFile.getLineNumber() : 0);
	}

	// Character test utilities:

	private boolean isLetterAZ(char c) {
		return 'A' <= c && c <= 'Z' || 'a' <= c && c <= 'z';
	}

	private boolean isDigit(char c) {
		return '0' <= c && c <= '9';
	}

	// Parser tests:

	public void test(TokenKind t) {
		if (curToken.kind != t)
			testError(t.toString());
	}

	public void testError(String message) {
		Main.error(curLineNum(), "Expected a " + message + " but found a " + curToken.kind + "!");
	}

	public void skip(TokenKind t) {
		test(t);
		readNextToken();
	}
}