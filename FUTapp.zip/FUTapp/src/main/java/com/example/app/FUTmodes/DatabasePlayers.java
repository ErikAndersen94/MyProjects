package com.example.app.FUTmodes;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Ola on 14.01.2017.
 */

public class DatabasePlayers extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "futplayers.db";
    public static final String ALLPLAYERS_TABLE_NAME = "allPlayers";
    public static final String ALLPLAYERS_COLUMN_PLAYERID = "playerID";
    public static final String ALLPLAYERS_COLUMN_PLAYERNAME = "playerName";
    public static final String ALLPLAYERS_COLUMN_IMGURL = "imgURL";
    public static final String ALLPLAYERS_COLUMN_NATIONALITY = "nationality";
    public static final String ALLPLAYERS_COLUMN_CLUB = "club";
    public static final String ALLPLAYERS_COLUMN_POSITION = "pos";
    public static final String ALLPLAYERS_COLUMN_DATEBORN = "dateBorn";
    public static final String ALLPLAYERS_COLUMN_SKILLMOVES = "skillmoves";
    public static final String ALLPLAYERS_COLUMN_WEAKFOOT = "weakfoot";
    ArrayList<String> players = new ArrayList<String>();
    Context context;

    public DatabasePlayers(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table allPlayers " +
                        "(playerID text primary key, playerName text, imgURL text, nationality text, club text, pos text, dateBorn text," +
                        " skillmoves text, weakfoot text)"
        );
        //addPlayersFromFile();

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addPlayersFromFile() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='allPlayers'", null);
        if(res.getCount()==0){
            onCreate(db);
        }
        File file;
        DataInputStream fileDB;
        Scanner readSc;
        try {
            fileDB = new DataInputStream(context.getAssets().open(String.format("fileDB.txt")));

            readSc = new Scanner(fileDB);
            int lineNumber;
            while (readSc.hasNextLine()) {
                lineNumber = 1;
                String inline = readSc.nextLine();
                String playerID = inline.substring(inline.indexOf(' ') + 1);
                inline = readSc.nextLine();
                String playername = inline.substring(inline.indexOf(' ') + 1);
                String imgURL = "";
                String club = "";
                String dateBorn = "";
                String sm = "1";
                String wf = "2";
                String pos = "";
                String nation = "";

                boolean add = true;

                // The player exist, no reason to add him.
                // Skips to next possible player

                if (playerExists(playername) == true) {
                    readSc.nextLine();
                    readSc.nextLine();
                    readSc.nextLine();
                    readSc.nextLine();
                    readSc.nextLine();
                    readSc.nextLine();
                    readSc.nextLine();
                    lineNumber = 8;
                    add = false;
                }

                while (lineNumber < 8) {
                    inline = readSc.nextLine();
                    inline = inline.substring(inline.indexOf(' ') + 1);
                    if (lineNumber == 1) {
                        sm = inline;
                    } else if (lineNumber == 2) {
                        wf = inline;
                    } else if (lineNumber == 3) {
                        club = inline;
                    } else if (lineNumber == 4) {
                        imgURL = inline;
                    } else if (lineNumber == 5) {
                        pos = inline;
                    } else if (lineNumber == 6) {
                        nation = inline;
                    } else if (lineNumber == 7) {
                        dateBorn = inline;
                    } else {
                        System.out.println("Incorrect arrangement of data");
                    }
                    lineNumber++;
                }

                // The player is added to the list
                if (add) {
                    boolean added = addPlayerToDB(playerID, playername, imgURL, nation, club, pos, dateBorn, sm, wf);
                    if (added) {
                        System.out.println("Player " + playername + " added successfully to db");
                    } else {
                        System.out.println("Failed adding player");
                    }
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Long term: Should match on playerID not playername.
    public boolean playerExists(String pname) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from allPlayers where playerName= ? ", new String[]{pname}, null);
        if (res.getCount() <= 0) {
            res.close();
            return false;
        }
        res.close();
        return true;
    }

    private boolean addPlayerToDB(String playerID, String pname, String imgURL, String nationality, String club, String pos, String dateBorn, String sm, String wf) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("playerID", playerID);
        contentValues.put("playerName", pname);
        contentValues.put("imgURL", imgURL);
        contentValues.put("nationality", nationality);
        contentValues.put("club", club);
        contentValues.put("dateBorn", dateBorn);
        contentValues.put("pos", pos);
        contentValues.put("skillmoves", sm);
        contentValues.put("weakfoot", wf);
        db.insert("allPlayers", null, contentValues);
        return true;
    }

    public String [] getPlayerInfo(String name){
        SQLiteDatabase db = this.getReadableDatabase();
        // db.execSQL("DROP TABLE IF EXISTS allplayers");
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='allPlayers'", null);
        if(res.getCount()==0){
            onCreate(db);
        }
        String [] playerInfo = new String[9];
        res =  db.rawQuery( "select * from allPlayers where playerName = ?",new String []{name}, null);
        res.moveToFirst();

        while(res.isAfterLast() == false){
            playerInfo[0] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_PLAYERID));
            playerInfo[1] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_PLAYERNAME));
            playerInfo[2] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_IMGURL));
            playerInfo[3] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_NATIONALITY));
            playerInfo[4] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_CLUB));
            playerInfo[5] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_POSITION));
            playerInfo[6] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_DATEBORN));
            playerInfo[7] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_SKILLMOVES));
            playerInfo[8] = res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_WEAKFOOT));
            res.moveToNext();
        }
        return playerInfo;
    }
    public ArrayList<String> getPlayerNames(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from allPlayers", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            players.add(res.getString(res.getColumnIndex(ALLPLAYERS_COLUMN_PLAYERNAME)));
            res.moveToNext();
        }
        return players;
    }
}
