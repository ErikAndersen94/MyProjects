package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class FuncDecl extends PascalDecl {
	ParamDeclList pdl;
	TypeName tn;
	Block bl;
	String name;
	types.Type type;
	int blokkNiv�;
	int procfuncteller;
	
	FuncDecl(String id, int lnum) {
		super(id, lnum);
	}

	@Override
	public String identify() {
		return "<FuncDecl> on line " + lineNum;
	}

	static FuncDecl parse(Scanner s) {
		enterParser("FuncDecl");
		FuncDecl fd = new FuncDecl(s.curToken.id, s.curLineNum());

		s.skip(functionToken);
		s.test(nameToken);
		fd.name = s.curToken.id;
		s.skip(nameToken);

		if (s.curToken.kind.equals(leftParToken)) {
			fd.pdl = ParamDeclList.parse(s);
		}

		s.skip(colonToken);
		fd.tn = TypeName.parse(s);

		s.skip(semicolonToken);
		fd.bl = Block.parse(s);

		s.skip(semicolonToken);

		leaveParser("FuncDecl");

		return fd;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrintLn();
		Main.log.prettyPrint("function ");
		Main.log.prettyPrint(name + " ");
		if (pdl != null) {
			pdl.prettyPrint();
		}
		Main.log.prettyPrint(": ");
		tn.prettyPrint();
		Main.log.prettyPrint(";");
		bl.prettyPrint();
		Main.log.prettyPrint(";");
	}
	
	/*
	 * Tilordner nytt Scope slik at paramterne vi finnes i pdl tilh�rer riktig blokk-objekt.
	 * Legger til en funksjon deklarasjon i hashmappet.
	 */
	@Override
	void check(Block curScope, Library lib){
		bl.outerScope = curScope;
		curScope.addHashDecl(name, this);
		if(pdl != null){
			pdl.check(bl, lib);
		}
		tn.check(bl, lib);
		bl.check(bl, lib);
		type = tn.type;
	}

	@Override
	void checkWhetherAssignable(PascalSyntax where) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void checkWhetherFunction(PascalSyntax where) {
		// TODO Auto-generated method stub
		
	}

	@Override
	void checkWhetherProcedure(PascalSyntax where) {
		where.error("Function cannot be a Procedure.");		
	}

	@Override
	void checkWhetherValue(PascalSyntax where) {
		// TODO Auto-generated method stub
		
	}
	//F�lger jernbanediagrammet for func decl og kaller p� param decl list sin genCode dersom pdl er ulik null.
	//Kaller s� p� type name- og blokk sin genCode. Setter ogs� blokkniv�.
	void genCode(CodeFile f) {
		if (pdl != null) {
			pdl.blokkNiv� = blokkNiv�;
			pdl.genCode(f);
		}
		tn.blokkNiv� = blokkNiv�;
		tn.genCode(f);
		bl.blokkNiv� = blokkNiv�;
		bl.name = "func";
		bl.varName = name;
		bl.procfuncteller = procfuncteller;
		bl.genCode(f);
		
	}
}
