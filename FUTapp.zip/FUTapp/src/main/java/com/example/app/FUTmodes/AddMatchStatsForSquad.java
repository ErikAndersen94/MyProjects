package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.NumberPicker;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class AddMatchStatsForSquad extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    String username;
    UserFormationDatabase userFormDB = new UserFormationDatabase(this);
    DatabaseSquads squadDB = new DatabaseSquads(this);
    PlayerstatsDB myPlayers = new PlayerstatsDB(this);
    private SeekBar seekBar;
    String possession = "50";
    String squadName;
    NumberPicker npResultHome;
    NumberPicker npResultOpponent;
    NumberPicker npShotsHome;
    NumberPicker npShotsOpponent;
    String usersGoals;
    String opponentsGoals;
    private View mViewGroupSquadStats;
    private View mViewGroupPlayerStats;
    private boolean showSquadStatsIsVisible = true;
    int [] goals = new int[11];
    int [] assists = new int[11];
    String [][] playersInSquad;
    int totalGoals = 0;
    int totalAssists = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_match_stats_for_squad);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");


        Spinner dropdown = (Spinner) findViewById(R.id.spinner1);
        dropdown.setOnItemSelectedListener(this);

        ArrayList<String> squadNames = squadDB.getAllSquadNames(username, "any");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, squadNames);
        if(squadNames == null){
            Intent myIntentCreateSquad = new Intent(AddMatchStatsForSquad.this, CreateSquad.class);
            myIntentCreateSquad.putExtra("username", username);
            AddMatchStatsForSquad.this.startActivity(myIntentCreateSquad);
        }
        else {
            dropdown.setAdapter(adapter);
            TextView usersteam = (TextView) findViewById(R.id.usersteam);
            usersteam.setText(username);

            npResultHome = (NumberPicker) findViewById(R.id.numberPickerResultHome);
            npResultOpponent = (NumberPicker) findViewById(R.id.numberPickerResultOpponent);

            npShotsHome = (NumberPicker) findViewById(R.id.numberPickerShotsHome);
            npShotsOpponent = (NumberPicker) findViewById(R.id.numberPickerShotsOpponent);

            npResultHome.setMinValue(0);
            npResultOpponent.setMinValue(0);
            npResultHome.setMaxValue(20);
            npResultOpponent.setMaxValue(20);

            npShotsHome.setMinValue(0);
            npShotsHome.setMaxValue(40);
            npShotsOpponent.setMinValue(0);
            npShotsOpponent.setMaxValue(40);

            mViewGroupSquadStats = findViewById(R.id.squadStatsView);
            mViewGroupPlayerStats = findViewById(R.id.playerStatsContainer);

            // must be created in the same thread that created the SeekBar
            seekBar = (SeekBar) findViewById(R.id.seekBar);
            // you should define max in xml, but if you need to do this by code, you must set max as 0 and then your desired value. this is because a bug in SeekBar (issue 12945) (don't really checked if it was corrected)
            seekBar.setMax(0);
            seekBar.setMax(100);
            seekBar.setProgress(50);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                final TextView seekBarHomePossession = (TextView) findViewById(R.id.homePossession);
                final TextView seekBarOpponentPossession = (TextView) findViewById(R.id.opponentPossession);

                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    seekBarHomePossession.setText(String.valueOf(progress));
                    seekBarOpponentPossession.setText(String.valueOf(100 - progress));
                    possession = String.valueOf(progress);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                    possession = "50";
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    possession = "50";
                }
            });
        }
    }

    public void newStatPlayer(View view){
        findViewId(view);
    }

    public void findViewId(View view){
        switch(view.getId()) {
            case R.id.minusGoalsPlayer1:
                updateXMLStats(R.id.goalsPlayer1, "minus", "goals", 10);
                break;
            case R.id.plusGoalsPlayer1:
                updateXMLStats(R.id.goalsPlayer1, "plus", "goals", 10);
                break;
            case R.id.minusAssistsPlayer1:
                updateXMLStats(R.id.assistsPlayer1, "minus", "assists", 10);
                break;
            case R.id.plusAssistsPlayer1:
                updateXMLStats(R.id.assistsPlayer1, "plus", "assists", 10);
                break;
            case R.id.minusGoalsPlayer2:
                updateXMLStats(R.id.goalsPlayer2, "minus", "goals", 9);
                break;
            case R.id.plusGoalsPlayer2:
                updateXMLStats(R.id.goalsPlayer2, "plus", "goals", 9);
                break;
            case R.id.minusAssistsPlayer2:
                updateXMLStats(R.id.assistsPlayer2, "minus", "assists", 9);
                break;
            case R.id.plusAssistsPlayer2:
                updateXMLStats(R.id.assistsPlayer2, "plus", "assists", 9);
                break;
            case R.id.minusGoalsPlayer3:
                updateXMLStats(R.id.goalsPlayer3, "minus", "goals", 8);
                break;
            case R.id.plusGoalsPlayer3:
                updateXMLStats(R.id.goalsPlayer3, "plus", "goals", 8);
                break;
            case R.id.minusAssistsPlayer3:
                updateXMLStats(R.id.assistsPlayer3, "minus", "assists", 8);
                break;
            case R.id.plusAssistsPlayer3:
                updateXMLStats(R.id.assistsPlayer3, "plus", "assists", 8);
                break;
            case R.id.minusGoalsPlayer4:
                updateXMLStats(R.id.goalsPlayer4, "minus", "goals", 7);
                break;
            case R.id.plusGoalsPlayer4:
                updateXMLStats(R.id.goalsPlayer4, "plus", "goals", 7);
                break;
            case R.id.minusAssistsPlayer4:
                updateXMLStats(R.id.assistsPlayer4, "minus", "assists", 7);
                break;
            case R.id.plusAssistsPlayer4:
                updateXMLStats(R.id.assistsPlayer4, "plus", "assists", 7);
                break;
            case R.id.minusGoalsPlayer5:
                updateXMLStats(R.id.goalsPlayer5, "minus", "goals", 6);
                break;
            case R.id.plusGoalsPlayer5:
                updateXMLStats(R.id.goalsPlayer5, "plus", "goals", 6);
                break;
            case R.id.minusAssistsPlayer5:
                updateXMLStats(R.id.assistsPlayer5, "minus", "assists", 6);
                break;
            case R.id.plusAssistsPlayer5:
                updateXMLStats(R.id.assistsPlayer5, "plus", "assists", 6);
                break;
            case R.id.minusGoalsPlayer6:
                updateXMLStats(R.id.goalsPlayer6, "minus", "goals", 5);
                break;
            case R.id.plusGoalsPlayer6:
                updateXMLStats(R.id.goalsPlayer6, "plus", "goals", 5);
                break;
            case R.id.minusAssistsPlayer6:
                updateXMLStats(R.id.assistsPlayer6, "minus", "assists", 5);
                break;
            case R.id.plusAssistsPlayer6:
                updateXMLStats(R.id.assistsPlayer6, "plus", "assists", 5);
                break;
            case R.id.minusGoalsPlayer7:
                updateXMLStats(R.id.goalsPlayer7, "minus", "goals", 4);
                break;
            case R.id.plusGoalsPlayer7:
                updateXMLStats(R.id.goalsPlayer7, "plus", "goals", 4);
                break;
            case R.id.minusAssistsPlayer7:
                updateXMLStats(R.id.assistsPlayer7, "minus", "assists", 4);
                break;
            case R.id.plusAssistsPlayer7:
                updateXMLStats(R.id.assistsPlayer7, "plus", "assists", 4);
                break;
            case R.id.minusGoalsPlayer8:
                updateXMLStats(R.id.goalsPlayer8, "minus", "goals", 3);
                break;
            case R.id.plusGoalsPlayer8:
                updateXMLStats(R.id.goalsPlayer8, "plus", "goals", 3);
                break;
            case R.id.minusAssistsPlayer8:
                updateXMLStats(R.id.assistsPlayer8, "minus", "assists", 3);
                break;
            case R.id.plusAssistsPlayer8:
                updateXMLStats(R.id.assistsPlayer8, "plus", "assists", 3);
                break;
            case R.id.minusGoalsPlayer9:
                updateXMLStats(R.id.goalsPlayer9, "minus", "goals", 2);
                break;
            case R.id.plusGoalsPlayer9:
                updateXMLStats(R.id.goalsPlayer9, "plus", "goals", 2);
                break;
            case R.id.minusAssistsPlayer9:
                updateXMLStats(R.id.assistsPlayer9, "minus", "assists", 2);
                break;
            case R.id.plusAssistsPlayer9:
                updateXMLStats(R.id.assistsPlayer9, "plus", "assists", 2);
                break;
            case R.id.minusGoalsPlayer10:
                updateXMLStats(R.id.goalsPlayer10, "minus", "goals", 1);
                break;
            case R.id.plusGoalsPlayer10:
                updateXMLStats(R.id.goalsPlayer10, "plus", "goals", 1);
                break;
            case R.id.minusAssistsPlayer10:
                updateXMLStats(R.id.assistsPlayer10, "minus", "assists", 1);
                break;
            case R.id.plusAssistsPlayer10:
                updateXMLStats(R.id.assistsPlayer10, "plus", "assists", 1);
                break;
            case R.id.minusGoalsPlayer11:
                updateXMLStats(R.id.goalsPlayer11, "minus", "goals", 0);
                break;
            case R.id.plusGoalsPlayer11:
                updateXMLStats(R.id.goalsPlayer11, "plus", "goals", 0);
                break;
            case R.id.minusAssistsPlayer11:
                updateXMLStats(R.id.assistsPlayer11, "minus", "assists", 0);
                break;
            case R.id.plusAssistsPlayer11:
                updateXMLStats(R.id.assistsPlayer11, "plus", "assists", 0);
                break;
        }
    }

    public void updateXMLStats(int id, String change, String stat, int pos){
        TextView changeTextValue = (TextView) mViewGroupPlayerStats.findViewById(id);
        int value = Integer.parseInt(changeTextValue.getText().toString());
        System.out.println(value);
        if(stat.equals("goals")){
            if(change.equals("plus") && totalGoals < Integer.parseInt(usersGoals)){
                totalGoals++;
                changeTextValue.setText(Integer.toString(++value));
                goals[pos] = value;
            }
            else if(change.equals("minus")){
                if(value<1){
                }
                else {
                    totalGoals--;
                    changeTextValue.setText(Integer.toString(--value));
                }
                goals[pos] = value;
            }
        }
        else{
            if(change.equals("plus") && totalAssists < Integer.parseInt(usersGoals)){
                totalAssists++;
                changeTextValue.setText(Integer.toString(++value));
                assists[pos] = value;
            }
            else if(change.equals("minus")){
                if(value<1){
                }
                else {
                    totalAssists--;
                    changeTextValue.setText(Integer.toString(--value));
                }
                assists[pos] = value;
            }
        }
    }


    public void onSubmitButton(View view){

        if (showSquadStatsIsVisible) {
            TextView showSquadName = (TextView) mViewGroupPlayerStats.findViewById(R.id.squadName);
            showSquadName.setText(squadName);

            usersGoals = Integer.toString(npResultHome.getValue());
            opponentsGoals = Integer.toString(npResultOpponent.getValue());

            String result = usersGoals + " - " + opponentsGoals;
            TextView showResult = (TextView) mViewGroupPlayerStats.findViewById(R.id.showResult);
            showResult.setText(result);

            int id = squadDB.getSquadId(username, squadName);
            playersInSquad = squadDB.getPlayersInSquad(id);

            for(int i = 0; i < 11; i++){
                String temp = "playerName" + (11-i);
                int resID = getResources().getIdentifier(temp, "id", getPackageName());

                TextView playerName = (TextView) mViewGroupPlayerStats.findViewById(resID);
                playerName.setText(playersInSquad[i][0]);

            }

            mViewGroupSquadStats.setVisibility(View.GONE);
            mViewGroupPlayerStats.setVisibility(View.VISIBLE);

        } else {
            mViewGroupSquadStats.setVisibility(View.VISIBLE);
            mViewGroupPlayerStats.setVisibility(View.GONE);
        }
        showSquadStatsIsVisible = !showSquadStatsIsVisible;
    }

    public void onSendSquadInfo(View view){
        String points;
        if(npResultHome.getValue()>npResultOpponent.getValue()){
            points = "3";
        }
        else if(npResultHome.getValue() == npResultOpponent.getValue()){
            points = "1";
        }
        else{
            points = "0";
        }
        squadDB.updateSquad(username, squadName, points, usersGoals, opponentsGoals, possession,
                Integer.toString(npShotsHome.getValue()), Integer.toString(npShotsOpponent.getValue()));
        userFormDB.printInfo(username);

        for(int i = 0; i<11; i++) {
            myPlayers.registerMatch(username, playersInSquad[i][0], goals[i], assists[i]);
        }
        Intent myIntentMainPage = new Intent(AddMatchStatsForSquad.this, MainActivity.class);
        myIntentMainPage.putExtra("username", username);
        AddMatchStatsForSquad.this.startActivity(myIntentMainPage);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        squadName = parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
       // squadName = parent.getItemAtPosition(position).toString();

    }
}
