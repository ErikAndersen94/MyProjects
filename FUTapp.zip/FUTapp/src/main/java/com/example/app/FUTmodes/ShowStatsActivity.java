package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.view.View.OnClickListener;

import java.util.ArrayList;

public class ShowStatsActivity extends AppCompatActivity {
    ArrayList<String> players = null;
    ArrayAdapter<String> adapter;
    PlayerstatsDB personalPlayerStats = null;
    private boolean namedesc = true;
    private boolean goalsdesc = true;
    private boolean assistsdesc = true;
    private boolean totalpointsdesc = true;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_stats);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
        personalPlayerStats = new PlayerstatsDB(this);
        players = personalPlayerStats.getPlayersStats(username, "DESC", "playerName");

        if(players!= null && players.size() > 0){
            populateListView();
        }
    }

    public void onShowGoalCharts(View view){
        Intent myIntentShowGoalCharts = new Intent(ShowStatsActivity.this, ShowGoalChartsActivity.class);
        myIntentShowGoalCharts.putExtra("username", username);
        ShowStatsActivity.this.startActivity(myIntentShowGoalCharts);
    }

    public void onPlayerNameButton(View view){
        if(players!= null && players.size() > 0) {
            if (namedesc) {
                players = personalPlayerStats.getPlayersStats(username, "DESC", "playerName");
                namedesc = false;
            }
            else{
                players = personalPlayerStats.getPlayersStats(username, "ASC", "playerName");
                namedesc = true;
            }
            goalsdesc = true;
            assistsdesc = true;
            totalpointsdesc = true;
            populateListView();
        }

    }
    public void onGoalsButton(View view){

        if(players!= null && players.size() > 0){
            if (goalsdesc) {
                players = personalPlayerStats.getPlayersStats(username, "DESC", "goals");
                goalsdesc = false;
            }
            else{
                players = personalPlayerStats.getPlayersStats(username, "ASC", "goals");
                goalsdesc = true;
            }
            namedesc = true;
            assistsdesc = true;
            totalpointsdesc = true;
            populateListView();
        }

    }
    public void onAssistsButton(View view){
        if(players!= null && players.size() > 0){
            if (assistsdesc) {
                players = personalPlayerStats.getPlayersStats(username, "DESC", "assists");
                assistsdesc = false;
            }
            else{
                players = personalPlayerStats.getPlayersStats(username, "ASC", "assists");
                assistsdesc = true;
            }
            goalsdesc = true;
            namedesc = true;
            totalpointsdesc = true;
            populateListView();
        }

    }
    public void onTotalPointsButton(View view){
        if(players!= null && players.size() > 0){
            if (totalpointsdesc) {
                players = personalPlayerStats.getPlayersStats(username, "DESC", "totalpoints");
                totalpointsdesc = false;
            }
            else{
                players = personalPlayerStats.getPlayersStats(username, "ASC", "totalpoints");
                totalpointsdesc = true;
            }
            goalsdesc = true;
            assistsdesc = true;
            namedesc = true;
            populateListView();
        }
    }

    private void populateListView(){
        adapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.playersListView);
        list.setAdapter(adapter);
    }

    public class MyListAdapter extends ArrayAdapter<String>{
        CustomButtonListener customButtonListener;


        public MyListAdapter(){
            super(ShowStatsActivity.this, R.layout.item_view, players);
        }

        public void setCustomButtonListener(CustomButtonListener customButtonListenerIn)
        {
            this.customButtonListener = customButtonListenerIn;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent){
            // Make sure we have a view to work with(may have been given null)
            View itemView = convertView;
            ViewHolder viewHolder;
            if(itemView == null){
                itemView = getLayoutInflater().inflate(R.layout.item_view, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.chosenPlayer = (TextView) itemView.findViewById(R.id.item_name);
                viewHolder.pressButton = (ImageButton) itemView.findViewById(R.id.item_infobutton);
                itemView.setTag(viewHolder);
            }
            else{
                viewHolder = (ViewHolder) itemView.getTag();
            }

            // Find the player to work with
            final String currentPlayer = players.get(position);
            //final String temp = currentPlayer.name;

            // Fill the view
            // Name
            TextView playerName = (TextView) itemView.findViewById(R.id.item_name);
            playerName.setText(currentPlayer);

            // goals. må konverteres til string, gjøres ved ""
            TextView goals = (TextView) itemView.findViewById(R.id.item_goals);
            goals.setText(personalPlayerStats.getSpecificPlayerStat(username, currentPlayer, "goals"));

            // assists
            TextView assists = (TextView) itemView.findViewById(R.id.item_assists);
            assists.setText(personalPlayerStats.getSpecificPlayerStat(username, currentPlayer, "assists"));

            TextView totalPoints = (TextView) itemView.findViewById(R.id.item_totalPoints);
            totalPoints.setText(personalPlayerStats.getSpecificPlayerStat(username, currentPlayer, "totalpoints"));

            // Kan brukes om vi legger til bilder av spillerne
            //ImageView imageView = (ImageView) itemView.findViewById(R.id.xxx);
            //imageView.setImageDrawable(currentPlayer.pic);
            viewHolder.chosenPlayer.setText(currentPlayer);
            viewHolder.pressButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (customButtonListener != null) {
                        customButtonListener.onButtonClickListener(position,currentPlayer);
                    }
                    Intent myIntentPlayerProfile = new Intent(ShowStatsActivity.this, PlayerProfile.class);
                    myIntentPlayerProfile.putExtra("playerName" ,currentPlayer);
                    myIntentPlayerProfile.putExtra("username", username);
                    ShowStatsActivity.this.startActivity(myIntentPlayerProfile);
                }
            });
                return itemView;
        }
    }
    public class ViewHolder{
        TextView chosenPlayer;
        ImageButton pressButton;
    }
}