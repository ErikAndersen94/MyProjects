package com.example.app.FUTmodes;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;


/**
 * Created by Ola on 23.01.2017.
 */

public class DatabaseSquads extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "futplayers.db";
    public static final String USERSQUADS_TABLE_NAME = "usersquads";
    public static final String USERSQUADS_COLUMN_ROWID = "ROWID";
    public static final String USERSQUADS_COLUMN_USERID = "userID";
    public static final String USERSQUADS_COLUMN_SQUADNAME = "squadName";
    public static final String USERSQUADS_COLUMN_FORMATION = "formation";
    public static final String USERSQUADS_COLUMN_MATCHES = "matches";
    public static final String USERSQUADS_COLUMN_WINS = "wins";
    public static final String USERSQUADS_COLUMN_DRAWS = "draws";
    public static final String USERSQUADS_COLUMN_LOSSES = "losses";
    public static final String USERSQUADS_COLUMN_GOALSSCORED = "goalsScored";
    public static final String USERSQUADS_COLUMN_GOALSCONCEDED = "goalsConceded";
    public static final String USERSQUADS_COLUMN_POSSESSION = "possession";
    public static final String USERSQUADS_COLUMN_SHOTSFOR = "shotsFor";
    public static final String USERSQUADS_COLUMN_SHOTSAGAINST= "shotsAgainst";

    public static final String SQUADDETAILS_TABLE_NAME = "squaddetails";
    public static final String SQUADDETAILS_COLUMN_ROWID = "ROWID";
    public static final String SQUADDETAILS_COLUMN_SQUADNAME = "squadName";
    public static final String SQUADDETAILS_COLUMN_PLAYERNAME = "playerName";
    public static final String SQUADDETAILS_COLUMN_PLAYERPOSINSQUAD = "playerPosInSquad";
    public static final String SQUADDETAILS_COLUMN_USERSQUADS_ROWID = "usersquads_ROWID";

    Context context;
    UserFormationDatabase userDB;


    public DatabaseSquads(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context=context;
    }

    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE usersquads (ROWID INTEGER PRIMARY KEY AUTOINCREMENT, userID TEXT, squadName TEXT, formation TEXT, matches NUM, wins NUM, draws NUM, losses NUM," +
                " goalsScored NUM, goalsConceded NUM, possession NUM, shotsFor NUM, shotsAgainst NUM)"
        );
        db.execSQL("CREATE TABLE squaddetails (ROWID INTEGER PRIMARY KEY AUTOINCREMENT,squadName TEXT, playerName TEXT, playerPosInSquad TEXT, usersquads_ROWID INTEGER, FOREIGN KEY(usersquads_ROWID) REFERENCES usersquads(ROWID))"
        );
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }

    public void createSquad(String userID, String squadName, String formation, String [][] players){
        SQLiteDatabase db = this.getWritableDatabase();
        //cleanDatabase(db);
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='usersquads'", null);
        if(res.getCount()==0){
            onCreate(db);
        }
        res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='squaddetails'", null);
        if(res.getCount()==0){
            onCreate(db);
        }
        //db.execSQL("DROP TABLE IF EXISTS usersquads");
        // db.execSQL("DROP TABLE IF EXISTS squaddetails");

        ContentValues contentValues = new ContentValues();
        contentValues.put("userID", userID);
        contentValues.put("squadName", squadName);
        contentValues.put("formation", formation);
        contentValues.put("matches", 0);
        contentValues.put("wins", 0);
        contentValues.put("draws", 0);
        contentValues.put("losses", 0);
        contentValues.put("goalsScored", 0);
        contentValues.put("goalsConceded", 0);
        contentValues.put("possession", 0);
        contentValues.put("shotsFor", 0);
        contentValues.put("shotsAgainst", 0);
        long id = db.insert("usersquads", null, contentValues);

        for(int i = 0; i< 11; i++){
            contentValues = new ContentValues();
            contentValues.put("squadName", squadName);
            contentValues.put("playerName", players[i][0]);
            contentValues.put("playerPosInSquad", players[i][1]);
            contentValues.put("usersquads_ROWID", id);
            db.insert("squaddetails", null, contentValues);
        }
        res.close();
    }

    // NEED A LOT OF INFORMATION
    public void updateSquad(String username, String squadname, String points, String goalsScored, String goalsConceded, String possession, String shotsFor, String shotsAgainst){
        String win;
        String draw;
        String loss;
        if(points.equals("3")){
            win = "1";
            draw = "0";
            loss = "0";
        }
        else if(points.equals("1")){
            win = "0";
            draw = "1";
            loss = "0";
        }
        else{
            win = "0";
            draw = "0";
            loss = "1";
        }
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE " + USERSQUADS_TABLE_NAME + " SET " + USERSQUADS_COLUMN_MATCHES + "=" + USERSQUADS_COLUMN_MATCHES + "+? ,"
                        + USERSQUADS_COLUMN_WINS + "=" + USERSQUADS_COLUMN_WINS + "+?, " + USERSQUADS_COLUMN_DRAWS + "=" + USERSQUADS_COLUMN_DRAWS + "+? ," +
                        USERSQUADS_COLUMN_LOSSES + "=" + USERSQUADS_COLUMN_LOSSES + "+? ," + USERSQUADS_COLUMN_GOALSSCORED + "=" + USERSQUADS_COLUMN_GOALSSCORED + "+?, "
                        + USERSQUADS_COLUMN_GOALSCONCEDED + "=" + USERSQUADS_COLUMN_GOALSCONCEDED + "+?, " + USERSQUADS_COLUMN_POSSESSION + "=" +
                        USERSQUADS_COLUMN_POSSESSION + "+?, " + USERSQUADS_COLUMN_SHOTSFOR + "=" + USERSQUADS_COLUMN_SHOTSFOR + "+?, " +
                        USERSQUADS_COLUMN_SHOTSAGAINST + "=" + USERSQUADS_COLUMN_SHOTSAGAINST + "+? " + "WHERE userID = ? AND squadName = ?"
                , new String[]{"1", win, draw, loss, goalsScored, goalsConceded, possession, shotsFor, shotsAgainst, username, squadname});
        userDB = new UserFormationDatabase(context);

        userDB.add(username, getFormation(username, squadname), points, goalsScored, goalsConceded, possession, shotsFor, shotsAgainst);

    }

    public void cleanDatabase(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS usersquads");
        db.execSQL("DROP TABLE IF EXISTS squaddetails");
       // onCreate(db);
    }

    public String [] getSquadInfo(String userID, String sqName){
        createTableIfNotExists();
        String [] squadInfo = new String [13];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from usersquads where userID = ? and squadName = ?",new String []{userID, sqName}, null);
        res.moveToFirst();

        while(res.isAfterLast() == false){
            squadInfo[0] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_ROWID));
            squadInfo[1] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_USERID));
            squadInfo[2] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_SQUADNAME));
            squadInfo[3] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_FORMATION));
            squadInfo[4] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_MATCHES));
            squadInfo[5] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_WINS));
            squadInfo[6] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_DRAWS));
            squadInfo[7] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_LOSSES));
            squadInfo[8] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_GOALSSCORED));
            squadInfo[9] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_GOALSCONCEDED));
            squadInfo[10] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_POSSESSION));
            squadInfo[11] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_SHOTSFOR));
            squadInfo[12] = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_SHOTSAGAINST));
            res.moveToNext();
        }
        res.close();
        return squadInfo;
    }
    public int getSquadId(String username, String squadName){
        createTableIfNotExists();
        int userID = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("SELECT ROWID FROM usersquads WHERE userID = ? and squadName = ?",new String []{username, squadName}, null);
        res.moveToFirst();

        while(res.isAfterLast() == false){
            userID = res.getInt(res.getColumnIndex(USERSQUADS_COLUMN_ROWID));
            res.moveToNext();
        }
        res.close();
        return userID;
    }

    public String [][] getPlayersInSquad(int squadID){
        createTableIfNotExists();
        String [][] playersInSquad = new String[11][2];
        SQLiteDatabase db = this.getReadableDatabase();
        String sq = Integer.toString(squadID);
        Cursor res = db.rawQuery("SELECT playerName, playerPosInSquad FROM squaddetails WHERE usersquads_ROWID = ?", new String [] {sq},null);
        if(res.getCount() <=0){
            res.close();
            return null;
        }
        int i = 0;
        res.moveToFirst();
        while(res.isAfterLast() == false){
            playersInSquad[i][0] = res.getString(res.getColumnIndex(SQUADDETAILS_COLUMN_PLAYERNAME));
            playersInSquad[i][1] = res.getString(res.getColumnIndex(SQUADDETAILS_COLUMN_PLAYERPOSINSQUAD));
            res.moveToNext();
            i++;
        }
        res.close();
        return playersInSquad;
    }

    public ArrayList<String> getAllSquadNames(String username, String formation){
        createTableIfNotExists();
        ArrayList<String> foundFormations = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res;
        if(formation.equals("any")){
            res = db.rawQuery("SELECT squadName FROM usersquads WHERE userID = ?", new String[]{username}, null);
        }
        else{
            res = db.rawQuery("SELECT squadName FROM usersquads WHERE userID = ? AND formation = ?", new String[]{username, formation}, null);
        }
        if(res.getCount()>0){
            res.moveToFirst();
            while(res.isAfterLast() == false){
                foundFormations.add(res.getString(res.getColumnIndex(USERSQUADS_COLUMN_SQUADNAME)));
                res.moveToNext();
            }
            res.close();
            return foundFormations;
        }
        else{
            res.close();
            return null;
        }
    }
    public void deleteSquad(){

    }

    public String getFormation(String username, String squadName) {
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT formation FROM usersquads WHERE userID = ? and squadName = ?", new String[]{username, squadName}, null);
        if (res.getCount() == 1) {
            res.moveToFirst();
            String formation = res.getString(res.getColumnIndex(USERSQUADS_COLUMN_FORMATION));
            res.close();
            return formation;
        } else {
            System.out.println("Multiple results when it should only be one!");
            res.close();
            return null;
        }
    }

    public int getStatForUser(String username, String stat){
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        int nrOfResults;
            Cursor res = db.rawQuery("SELECT SUM("+(stat)+") as TOTAL FROM usersquads WHERE userID = ?", new String[]{username}, null);
            if (res.moveToFirst()) {
                nrOfResults = res.getInt(0);
                res.close();
                return nrOfResults;
            } else {
                res.close();
                return 0;
            }
        }


    public double getWinPct(int squadID){
        return 0;
    }

    public String [] getTopSquad(String username){
        createTableIfNotExists();
        String [] topSquad = new String[3];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("SELECT squadName, formation, matches, wins, (wins/matches) as winrate FROM usersquads WHERE userID = ? AND " +
                "winrate = (SELECT MAX(wins/matches) FROM playerstats WHERE userID = ?)",new String []{username, username}, null);
        res.moveToFirst();
        int mostMatches = 0;
        double winrate = 0;
        while(!res.isAfterLast()) {
            int temp = Integer.parseInt(res.getString(res.getColumnIndex(USERSQUADS_COLUMN_MATCHES)));
            double tempWinrate = res.getDouble(res.getColumnIndex("winrate"));
            if (tempWinrate > winrate) {
                winrate = tempWinrate;
                mostMatches = temp;
                winrate = winrate*100;
                topSquad[0] = (res.getString(res.getColumnIndex(USERSQUADS_COLUMN_SQUADNAME)));
                topSquad[1] = (res.getString(res.getColumnIndex(USERSQUADS_COLUMN_FORMATION)));
                topSquad[2] = Double.toString(winrate);
                System.out.println(res.getString(res.getColumnIndex(USERSQUADS_COLUMN_WINS)));
            }
            else if(tempWinrate == winrate){
                if(temp>mostMatches){
                    winrate = tempWinrate;
                    mostMatches = temp;
                    winrate = winrate*100;
                    topSquad[0] = (res.getString(res.getColumnIndex(USERSQUADS_COLUMN_SQUADNAME)));
                    topSquad[1] = (res.getString(res.getColumnIndex(USERSQUADS_COLUMN_FORMATION)));
                    topSquad[2] = Double.toString(winrate);
                    System.out.println(res.getString(res.getColumnIndex(USERSQUADS_COLUMN_WINS)));
                }
            }
            res.moveToNext();
        }
        res.close();
        return topSquad;
    }

    public void createTableIfNotExists(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='usersquads'", null);
        if(res.getCount()==0){
            res.close();
            onCreate(db);
        }
    }

}