package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.Random;

public class GameModeActivity extends AppCompatActivity {
    String username;
    SquadBuildingChallenge sbc = new SquadBuildingChallenge();
    int leagues = 0;
    int nations = 0;
    int budget = 0;
    int playersFromNation = 0;
    String specificNation;
    int cardsWorse = 0;
    int specialCards = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_mode);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
    }

    public void onSquadBuildingChallenge(View view){
        int nrOfRequirements = new Random().nextInt(7 - 2) + 2;
        int [] generatedReqs = new int[nrOfRequirements];
        for(int i = 0; i<nrOfRequirements; i++){
            int method = new Random().nextInt(7 - 1) + 1;
            int j = 0;
            while(j<=i && generatedReqs[j] != method) {
                j++;
            }
            j--;
            if(j!=i){
                i--;
            }
            else{
                generatedReqs[i] = method;
            }
        }

        for(int i = 0; i < nrOfRequirements; i++){
            if(generatedReqs[i] != 0){
                switch(generatedReqs[i]){
                    case 1:
                        leagues = sbc.getNumberOfLeagues();
                        System.out.println("Number of leagues: " + leagues);
                        break;
                    case 2:
                        nations = sbc.getNumberOfNations();
                        System.out.println("Number of nations: " + nations);
                        break;
                    case 3:
                        budget = sbc.getBudget();
                        System.out.println("Budget: " + budget);
                        break;
                    case 4:
                        specificNation = sbc.getNation();
                        playersFromNation = sbc.getNumberFromSpecificNation();
                        System.out.println(playersFromNation + " players from " + specificNation);
                        break;
                    case 5:
                        cardsWorse = sbc.getNumberOfWorseThanGold();
                        System.out.println("Cards worse than gold: " + cardsWorse);
                        break;
                    case 6:
                        specialCards = sbc.getNumberOfSpecialCards();
                        System.out.println("Number of special cards: " + specialCards);
                        break;
                    default:
                        System.out.println("something wrong in switch-case");
                        break;
                }
            }
        }
    }
}
