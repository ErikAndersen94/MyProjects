package parser;

import scanner.*;
import static scanner.TokenKind.*;

import main.CodeFile;
import types.*;

public class Expression extends ProcCall {
	SimpleExpression leftOp;
	SimpleExpression rightOp;
	RelOpr ropr;
	types.Type type;
	int blokkNiv�;

	Expression(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<expression> on line " + lineNum;
	}

	static Expression parse(Scanner s) {
		enterParser("expression");
		Expression expr = new Expression(s.curLineNum());

		expr.leftOp = SimpleExpression.parse(s);
		// Det f�rste tegnet er uansett en simpleExpr, hvis vi ikke har
		// rel opr som neste token returnerer vi fra expression.
		if (s.curToken.kind.equals(equalToken) || s.curToken.kind.equals(notEqualToken)
				|| s.curToken.kind.equals(lessToken) || s.curToken.kind.equals(lessEqualToken)
				|| s.curToken.kind.equals(greaterToken) || s.curToken.kind.equals(greaterEqualToken)) {
			// g�r inn i rel opr
			expr.ropr = RelOpr.parse(s);
			expr.rightOp = SimpleExpression.parse(s);
		}

		leaveParser("expression");
		return expr;
	}

	@Override
	void prettyPrint() {
		leftOp.prettyPrint();
		if (ropr != null) {
			ropr.prettyPrint();
			rightOp.prettyPrint();
		}
	}

	@Override
	void check(Block curScope, Library lib) {
		leftOp.check(curScope, lib);
		// antar at vi kun har en simpleExpr, og ikke noen rel opr. Da kan vi si at Expr sin type er den samme som 
		// SimpleExpr sin type.
		type = leftOp.type;
		if (rightOp != null) {
			// hvis vi har en relOpr og dermed en SimpleExpr til, kan vi ikke si at Expr sin type er den samme som den f�rste 
			// SimpleExpr sin type. Da f�r vi en booleansk type siden det er en sammenlikning mellom to verdier.
			//ropr.check(curScope, lib);
			rightOp.check(curScope, lib);
			String oprName = ropr.name;
			type.checkType(rightOp.type, oprName + " operands", this, "Operands to " + oprName + " are of different type!");
			type = lib.boolType;
		}
	}
	
	/*
	 * Oppdaterer blokkniv�, kaller s� p� f�rste simpleexpr sin genCode.
	 * Etter dette sjekker vi om relopr har en verdi, hvis den har det, finner vi korrekt verdi
	 * etter vi har kalt p� den andre simpleExpr sin genCode.
	 * Skriver s� ut informasjonen.
	 */

	@Override void genCode(CodeFile f) {
		leftOp.blokkNiv� = blokkNiv�;
		leftOp.genCode(f);
		if(ropr != null){
			f.genInstr("", "pushl", "%eax", "");
			rightOp.blokkNiv� = blokkNiv�;
			rightOp.genCode(f);
			f.genInstr("", "popl", "%ecx", "");
			f.genInstr("", "cmpl", "%eax,%ecx", "");
			f.genInstr("", "movl", "$0,%eax", "");
			if(ropr.name == " = "){
				f.genInstr("", "sete", "%al", "Test =");
			}
			if(ropr.name == " <> "){
				f.genInstr("", "setne", "%al", "Test <>");
			}
			if(ropr.name == " < "){
				f.genInstr("", "setl", "%al", "Test <");
			}
			if(ropr.name == " <= "){
				f.genInstr("", "setle", "%al", "Test <=");
			}
			if(ropr.name == " > "){
				f.genInstr("", "setg", "%al", "Test >");
			}
			if(ropr.name == " >= "){
				f.genInstr("", "setge", "%al", "Test >=");
			}
		}
	}
}