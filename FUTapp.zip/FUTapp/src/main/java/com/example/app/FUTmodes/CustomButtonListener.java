package com.example.app.FUTmodes;

/**
 * Created by Ola on 17.01.2017.
 */
public interface CustomButtonListener {
    public void onButtonClickListener(int position, String value);
}
