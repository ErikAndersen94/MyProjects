package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;

import java.util.ArrayList;

public class UpdateStatsActivity extends AppCompatActivity {
    ArrayList<String> players;
    EditText pGoal;
    EditText pAssist;
    String playerName;
    String g;
    DatabasePlayers allPlayers = new DatabasePlayers(this);
    PlayerstatsDB personalPlayerStats = new PlayerstatsDB(this);
    String username;
    String a;
    int goals;
    int assists;
    ArrayList<String> playerNames;
    ArrayAdapter<String> adapter;
    AutoCompleteTextView etpName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_stats);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
        DatabasePlayers dbPlayers = new DatabasePlayers(this);
        //System.out.println("!!!!!!! " + players.get(0).getName());

        //E: Array som henter inn spillernavn som brukes i adapteren nedenfor.
        // Koden nedenfor gjøres for å skaffe autocomplete text.
        /*
        for (int i = 0; i < players.size(); i++) {
            playerNames.add(players.get(i).getName());
        }
        */

        adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item, dbPlayers.getPlayerNames());

        etpName = (AutoCompleteTextView) findViewById(R.id.playerName);
        etpName.setThreshold(3);
        etpName.setAdapter(adapter);

    }

    public void onSubmitButton(View view){

        playerName = etpName.getText().toString();
        pGoal = (EditText) findViewById(R.id.nrOfGoals);
        g = pGoal.getText().toString();
        goals = Integer.parseInt(g);
        pAssist = (EditText) findViewById(R.id.nrOfAssists);
        a = pAssist.getText().toString();
        assists = Integer.parseInt(a);

        if(allPlayers.playerExists(playerName)){
            personalPlayerStats.registerMatch(username, playerName, goals, assists);
        }
        else{
            System.out.println("The player " + playerName + " must be added to the allPlayers database");
        }
    }
}
