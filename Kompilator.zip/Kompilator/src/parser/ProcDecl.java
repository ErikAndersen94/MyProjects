package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ProcDecl extends PascalDecl {
	ParamDeclList pdl;
	Block bl;
	String name;
	int libNum;
	String libId;
	int blokkNiv�;
	int antParam;
	int procfuncteller;
	int niv�;

	ProcDecl(String id, int lnum) {
		super(id, lnum);
		libNum = lnum;
		libId = id;
	}

	@Override
	public String identify() {
		if (libNum == -1) {
			return "<ProcDecl> " + libId + " in the library ";
		} else {
			return "<ProcDecl> on line " + lineNum;
		}
	}

	static ProcDecl parse(Scanner s) {
		enterParser("ProcDecl");
		ProcDecl pd = new ProcDecl(s.curToken.id, s.curLineNum());

		s.skip(procedureToken);
		s.test(nameToken);
		pd.name = s.curToken.id;
		s.skip(nameToken);

		if (s.curToken.kind.equals(leftParToken)) {
			pd.pdl = ParamDeclList.parse(s);
		}

		s.skip(semicolonToken);
		pd.bl = Block.parse(s);

		s.skip(semicolonToken);

		leaveParser("ProcDecl");

		return pd;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrintLn();
		Main.log.prettyPrint("procedure ");
		Main.log.prettyPrint(name);
		if (pdl != null) {
			pdl.prettyPrint();
		}
		Main.log.prettyPrintLn(";");
		bl.prettyPrint();
		Main.log.prettyPrintLn(";");
	}

	/*
	 * Henviser til funcDecl. Tilsvarende tankegang.
	 */
	@Override
	void check(Block curScope, Library lib) {
		bl.outerScope = curScope;
		curScope.addHashDecl(name, this);
		if (pdl != null) {
			pdl.check(bl, lib);
			antParam = pdl.antParam;
		}
		bl.check(bl, lib);
	}

	@Override
	void checkWhetherAssignable(PascalSyntax where) {
		where.error("You cannot assign to a procedure.");
	}

	@Override
	void checkWhetherFunction(PascalSyntax where) {
		where.error("Procedure cannot be a function.");

	}

	@Override
	void checkWhetherProcedure(PascalSyntax where) {
		// TODO Auto-generated method stub

	}

	@Override
	void checkWhetherValue(PascalSyntax where) {
		where.error("proc decl cannot have a value.");
	}
	public void genCode(CodeFile f) {
		//Dersom vi har parametre i prosedyren s� kaller vi p� pdl sin genCode, hvis ikke s� hopper vi rett til blokk sin genCode.
		if (pdl != null) {
			pdl.blokkNiv� = blokkNiv�;
			pdl.genCode(f);
		}
		bl.blokkNiv� = blokkNiv�;
		bl.name = "proc";
		bl.varName = name;
		bl.procfuncteller = procfuncteller;
		niv� = procfuncteller;
		bl.genCode(f);
		procfuncteller = bl.procfuncteller;
		
	}

}
