package parser;
import scanner.*;
import static scanner.TokenKind.*;

import main.CodeFile;
import main.Main;


public class CharLiteral extends UnsignedConstant{
	String str;
	char ch;
	int constVal;
	int blokkNiv�;
	CharLiteral(int lnum) {
		super(lnum);
	}
	
	static CharLiteral parse(Scanner s){
		enterParser("char literal");
		CharLiteral cl = new CharLiteral(s.curLineNum());
		// Tester om charValToken er n�v�rende token. Hvis den er det gj�r vi om Char'en til en String og lagrer denne,
		// slik at verdien kan brukes til utskrift senere.
		s.test(charValToken);
		cl.ch = s.curToken.charVal;
		cl.str = Character.toString(s.curToken.charVal);
		cl.constVal = cl.ch;
		s.skip(charValToken);
		leaveParser("char literal");
		return cl;
	}
	
	@Override
	void prettyPrint() {
		Main.log.prettyPrint("'");
		Main.log.prettyPrint(str);
		Main.log.prettyPrint("'");
	}
	@Override
	void check(Block curScope, Library lib){
	}
	
	@Override
	void genCode(CodeFile f){
		// konverterer fra char til int(ascii), og skriver til fil
		int x = ch;
		f.genInstr("", "movl", "$" + x + ",%eax", " '" + ch + "'");
	}
	
}
