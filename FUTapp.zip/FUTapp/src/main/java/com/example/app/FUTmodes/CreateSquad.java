package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class CreateSquad extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    DatabasePlayers allPlayers = new DatabasePlayers(this);
    DatabaseSquads newSquad = new DatabaseSquads(this);
    String username;

    AutoCompleteTextView [] autoName = new AutoCompleteTextView[11];

    String [][] players = new String[11][2];
    ArrayList<String> playerNames;
    ArrayAdapter<String> adapter;
    String squadName;
    String formationName;
    EditText sqN;
    Formation f = new Formation(this);
    String [] positions = new String[11];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_squad);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");

        Spinner dropdown = (Spinner) findViewById(R.id.spinner1);
        dropdown.setOnItemSelectedListener(this);
        ArrayList<String> formationNames = f.getFormationNames();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, formationNames);
        dropdown.setAdapter(adapter);
        playerNames = allPlayers.getPlayerNames();
        adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item, playerNames);

        // making auto text views
        // Player 1
        for(int i = 0; i<11; i++) {
            int id = 0;
            try {
                String temp = Integer.toString(i+1);
                temp = "name" + temp;
                id =R.id.class.getField(temp).getInt(0);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }

            autoName[i] = (AutoCompleteTextView) findViewById(id);
            autoName[i].setThreshold(2);
            autoName[i].setAdapter(adapter);
        }
    }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            // An item was selected. You can retrieve the selected item using
            formationName = parent.getItemAtPosition(pos).toString();
            positions = f.getPositions(formationName);
                TextView pos1 = (TextView) findViewById(R.id.pos1);
                pos1.setText(positions[0]);
                TextView pos2 = (TextView) findViewById(R.id.pos2);
                pos2.setText(positions[1]);
                TextView pos3 = (TextView) findViewById(R.id.pos3);
                pos3.setText(positions[2]);
                TextView pos4 = (TextView) findViewById(R.id.pos4);
                pos4.setText(positions[3]);
                TextView pos5 = (TextView) findViewById(R.id.pos5);
                pos5.setText(positions[4]);
                TextView pos6 = (TextView) findViewById(R.id.pos6);
                pos6.setText(positions[5]);
                TextView pos7 = (TextView) findViewById(R.id.pos7);
                pos7.setText(positions[6]);
                TextView pos8 = (TextView) findViewById(R.id.pos8);
                pos8.setText(positions[7]);
                TextView pos9 = (TextView) findViewById(R.id.pos9);
                pos9.setText(positions[8]);
                TextView pos10 = (TextView) findViewById(R.id.pos10);
                pos10.setText(positions[9]);
                TextView pos11 = (TextView) findViewById(R.id.pos11);
                pos11.setText(positions[10]);
        }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        formationName = "41212(2)";
        positions = f.getPositions(formationName);
        TextView pos1 = (TextView) findViewById(R.id.pos1);
        pos1.setText(positions[0]);
        TextView pos2 = (TextView) findViewById(R.id.pos2);
        pos2.setText(positions[1]);
        TextView pos3 = (TextView) findViewById(R.id.pos3);
        pos3.setText(positions[2]);
        TextView pos4 = (TextView) findViewById(R.id.pos4);
        pos4.setText(positions[3]);
        TextView pos5 = (TextView) findViewById(R.id.pos5);
        pos5.setText(positions[4]);
        TextView pos6 = (TextView) findViewById(R.id.pos6);
        pos6.setText(positions[5]);
        TextView pos7 = (TextView) findViewById(R.id.pos7);
        pos7.setText(positions[6]);
        TextView pos8 = (TextView) findViewById(R.id.pos8);
        pos8.setText(positions[7]);
        TextView pos9 = (TextView) findViewById(R.id.pos9);
        pos9.setText(positions[8]);
        TextView pos10 = (TextView) findViewById(R.id.pos10);
        pos10.setText(positions[9]);
        TextView pos11 = (TextView) findViewById(R.id.pos11);
        pos11.setText(positions[10]);
    }

    public void onSubmitButton(View view){
        // Adding players to squad.
        // Squad name
        sqN = (EditText) findViewById(R.id.squadName);
        squadName = sqN.getText().toString();
        String [] positions = f.getPositions(formationName);

        //String [] players = new String[11];
        for (int i = 0; i<11; i++){
            players[i][0] = autoName[i].getText().toString();
            players[i][1] = positions[i];
        }
        newSquad.createSquad(username, squadName, formationName, players);
    }
}

