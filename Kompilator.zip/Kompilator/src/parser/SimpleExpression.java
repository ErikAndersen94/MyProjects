package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class SimpleExpression extends Expression {
	Term term;
	TermOpr topr;
	PrefixOpr popr;
	Term[] termArray = new Term[10];
	TermOpr[] termOprArray = new TermOpr[10];
	int termIndex = 0;
	int termOprIndex = 0;
	types.Type type;
	int blokkNiv�;

	SimpleExpression(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<simple expression> on line " + lineNum;
	}

	static SimpleExpression parse(Scanner s) {
		boolean loop = true;
		enterParser("simple expr");
		SimpleExpression simpleExpr = new SimpleExpression(s.curLineNum());

		if (s.curToken.kind.equals(addToken) || s.curToken.kind.equals(subtractToken)) {
			if (s.nextToken.kind.equals(addToken) || s.nextToken.kind.equals(subtractToken)) {
				Main.error("Error in line " + s.curLineNum() + " : Expected a value but found a -! ");
				System.exit(0);
			}
			simpleExpr.popr = PrefixOpr.parse(s);
		}
		while (loop) {

			simpleExpr.term = Term.parse(s);
			simpleExpr.termArray[simpleExpr.termIndex++] = simpleExpr.term;
			if (s.curToken.kind.equals(orToken) || s.curToken.kind.equals(addToken)
					|| s.curToken.kind.equals(subtractToken)) {
				simpleExpr.topr = TermOpr.parse(s);
				simpleExpr.termOprArray[simpleExpr.termOprIndex++] = simpleExpr.topr;
			} else {
				loop = false;
			}
			if (simpleExpr.termIndex == simpleExpr.termArray.length) {
				// Array er fullt, dobler str.
				Term[] tempterm = simpleExpr.termArray;
				simpleExpr.termArray = new Term[simpleExpr.termIndex * 2];

				TermOpr[] temptermOpr = simpleExpr.termOprArray;
				simpleExpr.termOprArray = new TermOpr[simpleExpr.termIndex * 2];

				for (int i = 0; i < tempterm.length; i++) {
					simpleExpr.termArray[i] = tempterm[i];
					simpleExpr.termOprArray[i] = temptermOpr[i];
				}

			}
		}
		leaveParser("simple expr");

		return simpleExpr;
	}

	@Override
	void prettyPrint() {
		if (popr != null) {
			popr.prettyPrint();
		}
		termArray[0].prettyPrint();
		int f = 0;
		while (termOprArray[f] != null) {
			termOprArray[f].prettyPrint();
			termArray[f + 1].prettyPrint();
			f++;
		}
	}

	/*
	 * Hvis vi har en preix opr, vet vi at typen m� v�re en integer iflg kompendiumet.
	 * Setter i s�fall simpleExpr sin type til � peke p� prefix opr sin type.
	 * Vi har lagt opp typesjekkingen slik at hvis vi har en operator, s� �nsker vi � sjekke
	 * at verdier p� h�yre og venstre side av operatoren er av samme type som operatoren.
	 */
	@Override
	void check(Block curScope, Library lib) {
		if (popr != null) {
			popr.check(curScope, lib);
			type = popr.type;
		}
		int f = 0;
		termArray[f].check(curScope, lib);
		if (popr == null) {
			type = termArray[0].type;
		} else {
			// type-checker prefix opr sin type med term sin type
			type.checkType(termArray[f].type, "right " + popr.name + " operand", this,
					"prefix opr and term are of different types");
		}
		while (termOprArray[f] != null) {
			termOprArray[f].check(curScope, lib);
			type.checkType(termOprArray[f].type, "left " + termOprArray[f].name + " operand", this,
					"the type of term do not correspond to the type required by the operand");
			termArray[f + 1].check(curScope, lib);
			type = termArray[f + 1].type;
			type.checkType(termOprArray[f].type, "right " + termOprArray[f].name + " operand", this,
					"the type of term do not correspond to the type required by the operand");
			f++;
		}
	}
	
	@Override void genCode(CodeFile f) {
		termArray[0].blokkNiv� = blokkNiv�;
		termArray[0].genCode(f);
		
		if(popr!= null && popr.name == " - "){
			f.genInstr("", "negl", "%eax", " - (prefix)"); // Har prefix, men kan f�rst endre fortegn etter at verdien er hentet ut.
		}
		int pos = 0;
		while (termOprArray[pos] != null) {
			f.genInstr("", "pushl", "%eax", "");
			termArray[pos + 1].blokkNiv� = blokkNiv�;
			termArray[pos + 1].genCode(f);
			f.genInstr("", "movl", "%eax,%ecx", ""); // Flytter det som ligger i %eax til %ecx.
			f.genInstr("", "popl", "%eax", "");     // Fjerner toppen av stakken og legger til i %eax
			if(termOprArray[pos].name == " + "){
				f.genInstr("", "addl", "%ecx,%eax", " + (term opr"); // Legger sammen %ecx og %eax til %eax
			}
			else if(termOprArray[pos].name == " - "){
				f.genInstr("", "subl", "%ecx,%eax", " - (term opr)"); // Fjerner %ecx fra %eax
			}
			else if(termOprArray[pos].name == " or "){
				f.genInstr("", "orl", "%ecx,%eax", " or (term opr)");
			}
			else{
				System.out.println("Term opr inneholder ikke korrekt verdi");
				System.exit(0);
			}
			pos++;
		}
	}

}
