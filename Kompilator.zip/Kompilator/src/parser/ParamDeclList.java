package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ParamDeclList extends FuncDecl {
	ParamDecl pd;
	ParamDecl [] pdArray = new ParamDecl[10];
	int index = 0;
	int blokkNiv�;
	int antParam;
	
	ParamDeclList(int lnum) {
		super("", lnum);
	}

	@Override
	public String identify() {
		return "<ParamDeclList> on line " + lineNum;
	}

	// Oppretter et ParamDecl array for � lagre objekter av ParamDecl.
 	static ParamDeclList parse(Scanner s) {
		boolean loop = true;
		enterParser("ParamDeclList");
		ParamDeclList pdl = new ParamDeclList(s.curLineNum());

		s.skip(leftParToken);

		while (loop) {
			pdl.antParam++;
			pdl.pd = ParamDecl.parse(s);
			pdl.pdArray[pdl.index++] = pdl.pd;
			if (!s.curToken.kind.equals(semicolonToken)) {
				loop = false;
			} else {
				s.skip(semicolonToken);
			}
			if(pdl.index == pdl.pdArray.length){
				ParamDecl [] pTemp = pdl.pdArray;
				pdl.pdArray = new ParamDecl[pdl.index*2];
				for(int i = 0; i<pTemp.length; i++){
					pdl.pdArray[i] = pTemp[i];
				}
			}
		}
		s.skip(rightParToken);
		leaveParser("ParamDeclList");

		return pdl;
	}
	
	@Override
	void prettyPrint() {
		int index = 0;
		Main.log.prettyPrint("(");
		pdArray[index++].prettyPrint();
		while(pdArray[index] != null){
			Main.log.prettyPrint("; ");
			pdArray[index++].prettyPrint();
		}
		Main.log.prettyPrint(")");
	}
	
	@Override
	void check(Block curScope, Library lib){
		int pos = 0;
		int x = 8;
		while(pdArray[pos] != null){
			pdArray[pos].offset = x;
			pdArray[pos].check(curScope, lib);
			pos++;
			x = x+4;
		}
	}
	@Override
	void genCode(CodeFile f){
		int pos = 0;
		while(pdArray[pos] != null){
			pdArray[pos].blokkNiv� = blokkNiv�;
			pdArray[pos].genCode(f);
			pos++;
		}
	}
}
