package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ParamDecl extends PascalDecl{
	TypeName tn;
	String name;
	types.Type type;
	int blokkNiv�;
	int offset;
	ParamDecl(int lnum) {
		super("", lnum);
	}

	@Override
	public String identify() {
		return "<ParamDecl> on line " + lineNum;
	}
	
	static ParamDecl parse(Scanner s){
		enterParser("ParamDecl");
		ParamDecl pd = new ParamDecl(s.curLineNum());
		s.test(nameToken);
		pd.name = s.curToken.id;
		s.skip(nameToken);
		s.skip(colonToken);
		
		pd.tn = TypeName.parse(s);
			
		leaveParser("ParamDecl");	
		return pd;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
		Main.log.prettyPrint(": ");
		tn.prettyPrint();
	}
	
	/*
	 * ParamDecl er en parameter med en type og et navn. Legger objektet til i hashmappet 
	 * som en deklarasjon med navnet som s�ken�kkel.
	 */
	@Override
	void check(Block curScope, Library lib){
		curScope.addHashDecl(name, this);
		tn.check(curScope, lib);
		type = tn.type;
	}

	@Override
	void checkWhetherAssignable(PascalSyntax where) {
		
	}

	@Override
	void checkWhetherFunction(PascalSyntax where) {
		where.error("Parameter declaration cannot be a function.");		
	}

	@Override
	void checkWhetherProcedure(PascalSyntax where) {
		where.error("Parameter declaration cannot be a Procedure.");		
	}

	@Override
	void checkWhetherValue(PascalSyntax where) {
		
	}
	
	void genCode(CodeFile f){
		tn.blokkNiv� = blokkNiv�;
	}
}
