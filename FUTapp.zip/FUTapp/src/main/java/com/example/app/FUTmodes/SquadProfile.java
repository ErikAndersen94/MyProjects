package com.example.app.FUTmodes;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

public class SquadProfile extends AppCompatActivity {
    String squadName;
    DatabaseSquads dbSquads = new DatabaseSquads(this);
    String username;
    String [] viewingSquad = new String[13];
    ImageButton [] imgplayer = new ImageButton[11];
    String [][] elevenPlayers = new String[11][2];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_squad_profile);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
        squadName = intent.getExtras().getString("squadName");

        // The current squad user wants to look at
        viewingSquad = dbSquads.getSquadInfo(username, squadName);
        int squadID = Integer.parseInt(viewingSquad[0]);
        String formation = viewingSquad[3];
        elevenPlayers = dbSquads.getPlayersInSquad(squadID);
        for(int i = 0; i< elevenPlayers.length; i++){
            elevenPlayers[i][0] = elevenPlayers[i][0].replaceAll("\\s","");
            elevenPlayers[i][0] = elevenPlayers[i][0].toLowerCase();
        }
        String formationDir = "formation_" + formation;
        int formationPath = getResources().getIdentifier(formationDir, "layout", getPackageName());

        //Need the view object of the formation file
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View formationView = inflater.inflate(formationPath ,null);

        for(int i = 0; i<11; i++){
            String temp = "player"+(i+1)+"_" + formation;
            int playerID = getResources().getIdentifier(temp, "id", getPackageName());
            imgplayer[i] = (ImageButton) formationView.findViewById(playerID);
            imgplayer[i].setImageResource(getResources().getIdentifier(elevenPlayers[i][0], "drawable", getPackageName()));
        }
        ViewGroup insertView = (ViewGroup) findViewById(R.id.activity_squad_profile);
        insertView.addView(formationView,0, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }
}
