
package com.example.app.FUTmodes;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.Legend.LegendForm;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.example.app.FUTmodes.custom.MyMarkerView;
/*import com.xxmassdeveloper.mpchartexample.custom.DayAxisValueFormatter;
import com.xxmassdeveloper.mpchartexample.custom.MyAxisValueFormatter;
import com.xxmassdeveloper.mpchartexample.notimportant.DemoBase;
*/
import java.util.ArrayList;

/*
    DENNE KLASSEN HAR ERIK ENDRET MASSE I!!!!!

 */

/*public class BarChartActivity extends DemoBase implements OnSeekBarChangeListener,
        OnChartValueSelectedListener {
*/
//public class BarChartActivity extends DemoBase implements OnChartValueSelectedListener {
public class ShowGoalChartsActivity extends AppCompatActivity {
    ArrayList<String> players;
    protected BarChart mChart;
    String username;
    PlayerstatsDB myPlayers = new PlayerstatsDB(this);
    /*
    private SeekBar mSeekBarX, mSeekBarY;
    */
    //private TextView tvX, tvY;
    int forsteTopscorer = 100;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_show_goal_charts);

        players = myPlayers.getPlayersStats(username, "DESC", "playerName");

        sortOnGoals();
        //Du kan også kalle sortOnAssists og sortOnTotalPoints der du trenger de verdiene

        /*
        tvX = (TextView) findViewById(R.id.tvXMax);
        tvY = (TextView) findViewById(R.id.tvYMax);

        mSeekBarX = (SeekBar) findViewById(R.id.seekBar1);
        mSeekBarY = (SeekBar) findViewById(R.id.seekBar2);
        */
        mChart = (BarChart) findViewById(R.id.chart1);
        //mChart.setOnChartValueSelectedListener(this);

        mChart.setDrawBarShadow(false);
        mChart.setDrawValueAboveBar(true);

        mChart.getDescription().setEnabled(false);

        // if more than 60 entries are displayed in the chart, no values will be
        // drawn
        mChart.setMaxVisibleValueCount(60);

        // scaling can now only be done on x- and y-axis separately
        mChart.setPinchZoom(false);

        mChart.setDrawGridBackground(false);
        // mChart.setDrawYLabels(false);

        //Setter tekst under x-aksen
        /*IAxisValueFormatter xAxisFormatter = new DayAxisValueFormatter(mChart);

        XAxis xAxis = mChart.getXAxis();
        xAxis.setPosition(XAxisPosition.BOTTOM);
        xAxis.setTypeface(mTfLight);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f); // only intervals of 1 day
        xAxis.setLabelCount(7);
        xAxis.setValueFormatter(xAxisFormatter);
*/
        mChart.getXAxis().setEnabled(false);

        //E: Gir tekst til venstre y-aksen.
        /*
        IAxisValueFormatter custom = new MyAxisValueFormatter();

        YAxis leftAxis = mChart.getAxisLeft();
        leftAxis.setTypeface(mTfLight);
        leftAxis.setLabelCount(8, false);
        leftAxis.setValueFormatter(custom);
        leftAxis.setPosition(YAxisLabelPosition.OUTSIDE_CHART);
        leftAxis.setSpaceTop(15f);
        leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)

*/
        //E: Gir tekst til høyre y-aksen.
        /*YAxis rightAxis = mChart.getAxisRight();
        rightAxis.setDrawGridLines(false);
        rightAxis.setTypeface(mTfLight);
        rightAxis.setLabelCount(8, false);
        rightAxis.setValueFormatter(custom);
        rightAxis.setSpaceTop(15f);
        rightAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)
    */
        //E: Setter venstresiden av Y-aksen til å starte og telle på 0
        YAxis leftAxis = mChart.getAxisLeft();
        //E: MÅ FIKSES: Må lage formel for å sette minimumsaksen til y. Kan bruke det tallet
        // på den laveste målscoreren og ta en diff til antall mål han har scoret.
        leftAxis.setAxisMinimum(0f);

        //E: Setter høyresiden av Y-aksen til å starte og telle på 0
        //YAxis rightAxis = mChart.getAxisRight();
        //rightAxis.setAxisMinimum(0f);

        mChart.getAxisRight().setEnabled(false);

        Legend l = mChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
        l.setForm(LegendForm.NONE);
        l.setFormSize(9f);
        l.setTextSize(17f);
        l.setXEntrySpace(4f);
        // l.setExtra(ColorTemplate.VORDIPLOM_COLORS, new String[] { "abc",
        // "def", "ghj", "ikl", "mno" });
        // l.setCustom(ColorTemplate.VORDIPLOM_COLORS, new String[] { "abc",
        // "def", "ghj", "ikl", "mno" });

        //XYMarkerView mv = new XYMarkerView(this, xAxisFormatter);


        MyMarkerView mv = new MyMarkerView(this, players);
        //mv.setChartView(mChart); // For bounds control
        mChart.setMarker(mv); // Set the marker to the chart
        //mChart.setMarker

        //Denne bestemmer antall søyler som skal vises, og størrelse på y-aksen.
        setData();

        // setting data
        /*
        mSeekBarY.setProgress(50);
        mSeekBarX.setProgress(12);

        mSeekBarY.setOnSeekBarChangeListener(this);
        mSeekBarX.setOnSeekBarChangeListener(this);
        */
        // mChart.setDrawLegend(false);
    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bar, menu);
        return true;
    }
*/

/*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.actionToggleValues: {
                for (IDataSet set : mChart.getData().getDataSets())
                    set.setDrawValues(!set.isDrawValuesEnabled());

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleHighlight: {
                if (mChart.getData() != null) {
                    mChart.getData().setHighlightEnabled(!mChart.getData().isHighlightEnabled());
                    mChart.invalidate();
                }
                break;
            }
            case R.id.actionTogglePinch: {
                if (mChart.isPinchZoomEnabled())
                    mChart.setPinchZoom(false);
                else
                    mChart.setPinchZoom(true);

                mChart.invalidate();
                break;
            }
            case R.id.actionToggleAutoScaleMinMax: {
                mChart.setAutoScaleMinMaxEnabled(!mChart.isAutoScaleMinMaxEnabled());
                mChart.notifyDataSetChanged();
                break;
            }
            case R.id.actionToggleBarBorders: {
                for (IBarDataSet set : mChart.getData().getDataSets())
                    ((BarDataSet) set).setBarBorderWidth(set.getBarBorderWidth() == 1.f ? 0.f : 1.f);

                mChart.invalidate();
                break;
            }
            case R.id.animateX: {
                mChart.animateX(3000);
                break;
            }
            case R.id.animateY: {
                mChart.animateY(3000);
                break;
            }
            case R.id.animateXY: {

                mChart.animateXY(3000, 3000);
                break;
            }
            case R.id.actionSave: {
                if (mChart.saveToGallery("title" + System.currentTimeMillis(), 50)) {
                    Toast.makeText(getApplicationContext(), "Saving SUCCESSFUL!",
                            Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(getApplicationContext(), "Saving FAILED!", Toast.LENGTH_SHORT)
                            .show();
                break;
            }
        }
        return true;
    }
*/
    /*
    @Override

    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        tvX.setText("" + (mSeekBarX.getProgress() + 2));
        tvY.setText("" + (mSeekBarY.getProgress()));

        setData(mSeekBarX.getProgress() + 1 , mSeekBarY.getProgress());
        mChart.invalidate();
    }
    */

    /*
    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        // TODO Auto-generated method stub
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        // TODO Auto-generated method stub
    }
    */

    private void sortOnGoals(){
        if(players.size()>0){
            players = myPlayers.getPlayersStats(username, "DESC", "goals");
        }
    }

    private void sortOnAssists(){
        if(players.size()>0){
            players = myPlayers.getPlayersStats(username, "DESC", "assists");
        }
    }
    private void sortOnTotalPoints(){
        if(players.size()>0){
            players = myPlayers.getPlayersStats(username, "DESC", "totalpoints");
        }
    }

    private void setData() {



        //sortere 10 som har scoret mest:



        //E: Oppretter et array med antall mål for hver målscorer.

        float start = 1f;
        //yVals1 bør være et array med de 20 mestscorende og antallet mål de har scoret.
        //Eks: yVals1.add(new BarEntry(1, 90)) -> Dette tilsvarer den første grafen på x aksen,
        // og gir denne en høyde på 90 mål.
        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();

        /*
        for (int i = (int) start; i < start + count + 1; i++) {
            float mult = (range + 1);
            float val = (float) (Math.random() * mult);
            yVals1.add(new BarEntry(i, val));
            System.out.println("i: " + i + "  val: " + val);
        }
        */
        //E: yVals sier hvilken søyle vi snakker om og hvor høy den skal være. f.eks.(1, 95) betyr
        //at vi snakker om den første søylen, og den skal være 95 (mål) høy. Looper gjennom til vi
        // har nådd størrelsen som blir satt av count, som sendes inn til setData.
        int max = players.size();
        if(max>10){
            max = 10;
        }
        for(int j = 0; j < max; j++){
            String currPlayer = players.get(j);

            yVals1.add(new BarEntry(j+1, Integer.parseInt(myPlayers.getSpecificPlayerStat(username, currPlayer, "goals"))));
            //System.out.println("i: " + j + "  val: " + p.goals);
        }
        BarDataSet set1;

        if (mChart.getData() != null &&
                mChart.getData().getDataSetCount() > 0) {
            set1 = (BarDataSet) mChart.getData().getDataSetByIndex(0);
            set1.setValues(yVals1);
            mChart.getData().notifyDataChanged();
            mChart.notifyDataSetChanged();
        } else {
            set1 = new BarDataSet(yVals1, "Top 10 goalscorers");
            set1.setColors(ColorTemplate.JOYFUL_COLORS);


            ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
            dataSets.add(set1);

           for(int i = 0; i< max; i++) {
               String temp = "chart_name" + (i);
               int resID = getResources().getIdentifier(temp, "id", getPackageName());
               String currPlayer = players.get(i);
               TextView playerName = (TextView) findViewById(resID);
               playerName.setText(myPlayers.getSpecificPlayerStat(username, currPlayer, "playerName"));
           }



            BarData data = new BarData(dataSets);
            data.setValueTextSize(15f);
            //E: Typeface = skrifttype
            //data.setValueTypeface(mTfLight);
            data.setBarWidth(0.9f);

            mChart.setData(data);
        }
    }

    /*protected RectF mOnValueSelectedRectF = new RectF();

    @SuppressLint("NewApi")
    @Override
    public void onValueSelected(Entry e, Highlight h) {

        if (e == null)
            return;

        RectF bounds = mOnValueSelectedRectF;
        mChart.getBarBounds((BarEntry) e, bounds);
        MPPointF position = mChart.getPosition(e, AxisDependency.LEFT);

        Log.i("bounds", bounds.toString());
        Log.i("position", position.toString());

        Log.i("x-index",
                "low: " + mChart.getLowestVisibleX() + ", high: "
                        + mChart.getHighestVisibleX());

        MPPointF.recycleInstance(position);
    }

    @Override
    public void onNothingSelected() { }
*/
}
