package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class WhileStatement extends Statement {
	Statement sm;
	Expression expr;
	int blokkNiv�;

	WhileStatement(int lnum) {
		super(lnum);
	}

	public String identify() {
		return "<while statement> on line " + lineNum;
	}

	static WhileStatement parse(Scanner s) {
		enterParser("while statement");
		WhileStatement ws = new WhileStatement(s.curLineNum());
		s.skip(whileToken);
		ws.expr = Expression.parse(s);
		s.skip(doToken);
		ws.sm = Statement.parse(s);

		leaveParser("while statement");
		return ws;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint("while ");
		expr.prettyPrint();
		Main.log.prettyPrintLn(" do");
		Main.log.prettyIndent();
		sm.prettyPrint();
		Main.log.prettyOutdent();
	}

	@Override
	void check(Block curScope, Library lib) {
		expr.check(curScope, lib);
		expr.type.checkType(lib.boolType, "while-test", this, "While-test is not Boolean.");
		sm.check(curScope, lib);
	}
	
	@Override void genCode(CodeFile f) {
		String testLabel = f.getLocalLabel();
		String endLabel = f.getLocalLabel();
		f.genInstr(testLabel, "", "", "Start while-statement");
		expr.blokkNiv� = blokkNiv�;
		expr.genCode(f);
		f.genInstr("", "cmpl", "$0,%eax", "");
		f.genInstr("", "je", endLabel, "");
		sm.blokkNiv� = blokkNiv�;
		sm.genCode(f);
		f.genInstr("", "jmp", testLabel, "");
		f.genInstr(endLabel, "", "", "End while-statement");
		}
}
