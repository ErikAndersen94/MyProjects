package parser;

import main.*;
import static scanner.TokenKind.*;

import scanner.Scanner;

public class FactorOpr extends Term {
	String name;
	types.Type type;

	FactorOpr(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<factor opr> on line " + lineNum;
	}

	static FactorOpr parse(Scanner s) {
		enterParser("factor opr");
		FactorOpr fopr = new FactorOpr(s.curLineNum());
		if (s.curToken.kind.equals(multiplyToken)) {
			fopr.name = " * ";
			s.skip(multiplyToken);
		} else if (s.curToken.kind.equals(divToken)) {
			fopr.name = " div ";
			s.skip(divToken);
		} else if (s.curToken.kind.equals(modToken)) {
			fopr.name = " mod ";
			s.skip(modToken);
		} else if (s.curToken.kind.equals(andToken)) {
			fopr.name = " and ";
			s.skip(andToken);
		} else {
			System.out.println("Feil! Ugyldig tegn");
		}
		leaveParser("factor opr");
		return fopr;
	}

	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
	}

	/*
	 * Sjekker om navnet til factorOpr er and, hvis det er tilfelle, s� er typen en boolean.
	 * Hvis ikke er det en integer.
	 */
	@Override
	void check(Block curScope, Library lib) {
		if (name.equals(" and ")) {
			type = lib.boolType;
		} else {
			type = lib.intType;
		}
	}
}
