package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.io.Serializable;

public class StatisticsActivity extends AppCompatActivity implements Serializable{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        Intent intent = getIntent();

    }
    public void onUpdateStats(View view){
        Intent myIntentUpdateStats = new Intent(StatisticsActivity.this, UpdateStatsActivity.class);
        StatisticsActivity.this.startActivity(myIntentUpdateStats);
    }
    public void onShowStats(View view){
        Intent myIntentShowStats = new Intent(StatisticsActivity.this, ShowStatsActivity.class);
        StatisticsActivity.this.startActivity(myIntentShowStats);
    }
}
