package com.example.app.FUTmodes;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Created by Ola on 23.01.2017.
 */

public class Formation extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "futplayers.db";
    public static final String FORMATIONS_TABLE_NAME = "formations";
    public static final String FORMATIONS_COLUMN_PLAYERNR = "playerNr";
    public static final String FORMATIONS_COLUMN_NAME = "name";
    public static final String FORMATIONS_COLUMN_POSITION = "position";
    DataInputStream fileDB;
    Context context;


    public Formation(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context=context;
    }

    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE formations (playerNr NUM, name TEXT, position TEXT, PRIMARY KEY(playerNr, name))"
        );
        createFormation();
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }

    public void createFormation() {
        //Read info from formations.txt and add to table
        File file;
        DataInputStream fileDB;
        Scanner readSc;
        try {
            fileDB = new DataInputStream(context.getAssets().open(String.format("formations.txt")));
            readSc = new Scanner(fileDB);
            while (readSc.hasNextLine()) {
                String [] positions;
                String inline = readSc.nextLine();
                String formationName = inline.substring(inline.indexOf(' ') + 1);
                inline = readSc.nextLine();
                positions = inline.substring(inline.indexOf(' ') + 1).split(",");

                SQLiteDatabase db = this.getWritableDatabase();
                for(int i = 0; i<11; i++) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("playerNr", 1+i);
                    contentValues.put("name", formationName);
                    contentValues.put("position", positions[i]);
                    db.insert("formations", null, contentValues);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> getFormationNames() {
        ArrayList<String> allFormations = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        //db.execSQL("DROP TABLE IF EXISTS formations");
        Cursor res = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='formations'", null);
        if (res.getCount() == 0) {
            onCreate(db);
        }
        res = db.rawQuery("SELECT DISTINCT name FROM formations", null);
            res.moveToFirst();

            while (res.isAfterLast() == false) {
                allFormations.add(res.getString(res.getColumnIndex(FORMATIONS_COLUMN_NAME)));
                res.moveToNext();
            }
            res.close();
            return allFormations;

    }

    public String [] getPositions(String formationName){
        String [] positions = new String[11];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("SELECT position FROM formations WHERE name = ?",new String[]{formationName}, null);
        res.moveToFirst();
        int i = 0;
        while(res.isAfterLast() == false){
            positions[i] = res.getString(res.getColumnIndex(FORMATIONS_COLUMN_POSITION));
            res.moveToNext();
            i++;
        }
        res.close();
        return positions;
    }
}