package parser;
import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class InnerExpr extends Factor{
	Expression expr;
	types.Type type;
	int blokkNiv�;
	
	InnerExpr(int lnum) {
		super(lnum);
	}

	public String identify() {
		return "<InnerExpr> on line " + lineNum;
	}
	
	static InnerExpr parse(Scanner s){
		enterParser("InnerExpr");
		InnerExpr ie = new InnerExpr(s.curLineNum());
		s.skip(leftParToken);
		ie.expr = Expression.parse(s);
		s.skip(rightParToken);
		leaveParser("InnerExpr");
		return ie;
	}
	
	@Override
	void prettyPrint() {
		Main.log.prettyPrint("(");
		expr.prettyPrint();
		Main.log.prettyPrint(")");
	}
	
	@Override
	void check(Block curScope, Library lib) {
		expr.check(curScope, lib);
		type = expr.type;
	}
	
	@Override
	void genCode(CodeFile f){
		expr.blokkNiv� = blokkNiv�;
		expr.genCode(f);
	}
}
