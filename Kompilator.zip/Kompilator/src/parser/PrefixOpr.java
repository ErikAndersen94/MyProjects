package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class PrefixOpr extends Constant{
	String name;
	types.Type type;
	PrefixOpr(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<PrefixOpr> on line " + lineNum;
	}
	
	// Sjekker om curToken sin kind er lik addToken eller subtractToken. Lagrer + eller - i variabelen name utifra 
	// svaret p� testen.
	static PrefixOpr parse(Scanner s){
		enterParser("PrefixOpr");
		PrefixOpr popr = new PrefixOpr(s.curLineNum());
		if (s.curToken.kind.equals(addToken)){
			popr.name = " + ";
			s.skip(addToken);
		}
		else if (s.curToken.kind.equals(subtractToken)){
			popr.name = " - ";
			s.skip(subtractToken);
		}
		else{
			System.out.println("Feil! Ugyldig tegn");
		}
		
		leaveParser("PrefixOpr");
		
		return popr;
	}
	
	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
	}
	/*
	 * Har vi en prefix opr, s� vet vi at typen m� v�re integer.
	 */
	@Override
	void check(Block curScope, Library lib){
		type = lib.intType;
	}
	@Override void genCode(CodeFile f) {
	}
}