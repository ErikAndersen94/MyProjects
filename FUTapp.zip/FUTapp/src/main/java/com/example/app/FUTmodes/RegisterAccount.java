package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class RegisterAccount extends AppCompatActivity {
    private TextView usernameTV;
    private TextView emailTV;
    private TextView passwordTV;
    private TextView passwordCheckTV;
    private UserDatabase userDB = new UserDatabase(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_account);
        Intent intent = getIntent();
    }

    public void onAddAccountButton(View view){
        usernameTV = (TextView) findViewById(R.id.regUsername);
        emailTV = (TextView) findViewById(R.id.regMail);
        passwordTV = (TextView) findViewById(R.id.regPassword);
        passwordCheckTV = (TextView) findViewById(R.id.regPasswordDuplicate);
        String username = usernameTV.getText().toString();
        String email = emailTV.getText().toString();
        String password = passwordTV.getText().toString();
        String passwordDupl = passwordCheckTV.getText().toString();

        if(isPasswordValid(password, passwordDupl) && isMailValid(email) && isUserNameValid(username)){
            if(userDB.addUser(username, password, email)){
                Intent myIntentMainPage = new Intent(RegisterAccount.this, MainActivity.class);
                myIntentMainPage.putExtra("username", username);
                RegisterAccount.this.startActivity(myIntentMainPage);
            }
        }
    }

    private boolean isUserNameValid(String username) {
        //TODO: Replace this with your own logic
        return username.length() > 3;
    }

    private boolean isPasswordValid(String password, String passwordCheck) {
        //TODO: Replace this with your own logic
        if(password.equals(passwordCheck) && password.length()>6){
            return true;
        }
        System.out.println("Your password didnt match or was too short");
        return false;
    }

    private boolean isMailValid(String mail) {
        //TODO: Replace this with your own logic
        return mail.contains("@");
    }
}
