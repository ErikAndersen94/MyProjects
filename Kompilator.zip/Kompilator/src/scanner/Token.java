package scanner;

import static scanner.TokenKind.*;

public class Token {
	public TokenKind kind;
	public String id;
	public char charVal;
	public int intVal, lineNum;

	Token(TokenKind k, int lNum) {
		kind = k;
		lineNum = lNum;
	}
/* 
 * Tester som sjekker hva slags tekst stringen s tilsvarer, og som tilordner kind utifra den type token som matcher s.
 */
	Token(String s, int lNum) {
		s = s.toLowerCase();
		if (s.equals("and"))
			kind = andToken;
		else if (s.equals("array"))
			kind = arrayToken;
		else if (s.equals("begin"))
			kind = beginToken;
		else if (s.equals("const"))
			kind = constToken;
		else if (s.equals("div"))
			kind = divToken;
		else if (s.equals("do"))
			kind = doToken;
		else if (s.equals("else"))
			kind = elseToken;
		else if (s.equals("end"))
			kind = endToken;
		else if (s.equals("function"))
			kind = functionToken;
		else if (s.equals("if"))
			kind = ifToken;
		else if (s.equals("mod"))
			kind = modToken;
		else if (s.equals("not"))
			kind = notToken;
		else if (s.equals("of"))
			kind = ofToken;
		else if (s.equals("or"))
			kind = orToken;
		else if (s.equals("procedure"))
			kind = procedureToken;
		else if (s.equals("program"))
			kind = programToken;
		else if (s.equals("then"))
			kind = thenToken;
		else if (s.equals("var"))
			kind = varToken;
		else if (s.equals("while"))
			kind = whileToken;
		else if (s.equals("e-o-f"))
			kind = eofToken;
		else if (s.equals(";"))
			kind = semicolonToken;
		else if (s.equals(")"))
			kind = rightParToken;
		else if (s.equals("("))
			kind = leftParToken;
		else if (s.startsWith("\'"))
			kind = charValToken;
		else if (s.startsWith("="))
			kind = equalToken;
		else if (s.equals("if"))
			kind = ifToken;
		else if (s.equals(","))
			kind = commaToken;
		/*
		 * Tester om s slutter med "=" eller ikke. Dette gj�res for � skille mellom colonToken og assignToken, som begge starter med ":".
		 */
		else if (s.startsWith(":"))
			if(s.endsWith("=")){
				kind = assignToken;
			}
			else{
				kind = colonToken;
			}
		else if (s.equals("+"))
			kind = addToken;
		/*
		 * Fungerer p� samme m�te som med colon ovenfor.
		 */
		else if (s.startsWith(">"))
			if(s.endsWith("=")){
				kind = greaterEqualToken;
			}
			else{
				kind = greaterToken;
			}
		/*
		* Fungerer p� samme m�te som med colon ovenfor, bortsett fra at vi har enda en if-test. 
		* Dette ettersom det er to typer tegn som kan f�lge etter "<".
		*/ 
		else if (s.startsWith("<"))
			if(s.endsWith("=")){
				kind = lessEqualToken;
			}
			else if(s.endsWith(">"))
				kind = notEqualToken;
			else{
				kind = lessToken;
			}
		else if (s.equals("["))
			kind = leftBracketToken;
		else if (s.equals("]"))
			kind = rightBracketToken;
		else if (s.equals("*"))
			kind = multiplyToken;
		else if (s.equals("-"))
			kind = subtractToken;
		/*
		* Fungerer p� samme m�te som med colon ovenfor, bortsett fra at vi ogs� tester p� om lengden til stringen vi mottar er 2.
		* Dette gj�res for � skille mellom rangeToken og dotToken. 
		* Hvis man f.eks. har "." s� ville man sl�tt til p� den f�rste if-en dersom man ikke hadde testet p� lengden til s.
		* Dette fordi s b�de vil starte og avslutte med "." selv om det bare er et tegn.  
		*/ 
		else if (s.startsWith("."))
			if(s.length() == 2 && s.endsWith(".")){
				kind = rangeToken;
			}
			else{
				kind = dotToken;
			}
		else
			kind = nameToken;

		id = s;
		lineNum = lNum;
	}

	Token(int n, int lNum) {
		kind = intValToken;
		intVal = n;
		lineNum = lNum;
	}

	Token(char c, int lNum) {
		kind = charValToken;
		charVal = c;
		lineNum = lNum;
	}

	public String identify() {
		String t = kind.identify();
		if (lineNum > 0) {
			t += " on line " + lineNum;

			switch (kind) {
			case nameToken:
				t += ": " + id;
				break;
			case intValToken:
				t += ": " + intVal;
				break;
			case charValToken:
				t += ": '" + charVal + "'";
				break;
			}
		}
		return t;
	}
}