package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

import java.util.HashMap;
/*
 * Block-klassen tar egentlig for seg nesten all funksjonalitet som er "ny" p� denne hjemmeeksamenen.
 * Velger derfor � kommentere grundigere hva som er gjort her, slik at det ikke blir s� mye repetisjon.
 * Det kan derfor hende at en del klasser nesten ikke har kommentarer. Rett og slett fordi det som blir gjort i de klassene
 * allerede har blitt forklart her.
 * 
 * N�r vi parserer oss gjennom treet er det viktig � passe p� at ingen informasjon g�r tapt. 
 * Med tanke p� at vi jobber rekursivt, og ganske mange klasser oppretter objekter i en while(som skriver over tidligere objekter)
 * er det viktig � finne en effektiv m�te � spare p� disse objektene p�.
 * Vi har valgt � lagre disse verdiene i arrays, som f.eks fArray og pArray er eksempler p� i Block.
 * fArray er et array av FuncDecl og pArray er et array av ProcDecl. B�de FuncDecl og ProcDecl kan opprettes flere ganger.
 * Noe som gj�r at vi er n�dt til � ta vare p� objektene f�r vi overskriver dem.
 * 
 * S�nn ellers s� har vi laget en liten kodesnutt f	or � doble arrayst�rrelse, skulle det v�re n�dvendig.
 * 
 * N�r det gjelder oppsettet av klassene generelt, s� har vi bare fulgt jernbanediagrammene og satt inn skip, 
 * der vi skal hoppe over et symbol og heller skaffe en ny symbol-token.
 * 
 * De aller fleste steder i programmet hvor det samme klasse kalles flere ganger brukes en enkel while-l�kke,
 * som l�per og lagrer objekter i array, s� lenge kriteriene for � fortsette m�tes. Eksempelvis hvis neste token er et semikolon.
 * 
 * 
 * PrettyPrintinga er heller ikke spesielt avansert eller forskjellig fra klasse til klasse.
 * F�lger ogs� her jernbanediagrammene i kompendiumet. Steder hvor det er array med flere verdier lagret,
 * looper vi oss gjennom disse og skriver ut verdiene i riktig rekkef�lge. 
 */

public class Block extends PascalSyntax {
	HashMap<String, PascalDecl> hashDecl = new HashMap<String, PascalDecl>();
	Block outerScope = null;
	ConstDeclPart cdp = null;
	VarDeclPart vdp = null;
	FuncDecl fd = null;
	Library lib;
	ProcDecl pd;
	StatmList sl;
	FuncDecl[] fArray = new FuncDecl[10];
	ProcDecl[] pArray = new ProcDecl[10];
	int fIndex = 0;
	int pIndex = 0;
	int blokkNiv�;
	int procfuncteller;
	int niv�;
	int antallByte = 32;
	String programName;
	String name;
	String varName;

	Block(int lnum) {
		super(lnum);
	}

	Block() {

	}

	@Override
	public String identify() {
		return "<block> on line " + lineNum;
	}

	static Block parse(Scanner s) {
		boolean loop = true;
		enterParser("block");

		Block bl = new Block(s.curLineNum());
		if (s.curToken.kind.equals(constToken)) {
			bl.cdp = ConstDeclPart.parse(s);
		}
		if (s.curToken.kind.equals(varToken)) {
			bl.vdp = VarDeclPart.parse(s);
		}
		while (loop) {
			if (s.curToken.kind.equals(functionToken)) {
				bl.fd = FuncDecl.parse(s);
				bl.fArray[bl.fIndex++] = bl.fd;
			} else if (s.curToken.kind.equals(procedureToken)) {
				bl.pd = ProcDecl.parse(s);
				bl.pArray[bl.pIndex++] = bl.pd;
			}
			if (!s.curToken.kind.equals(functionToken) && !s.curToken.kind.equals(procedureToken)) {
				loop = false;
			}

			if (bl.fIndex == bl.fArray.length) {
				// Array er fullt, dobler str.
				FuncDecl[] tempF = bl.fArray;
				bl.fArray = new FuncDecl[bl.fIndex * 2];
				for (int i = 0; i < tempF.length; i++) {
					bl.fArray[i] = tempF[i];
				}
			}
			if (bl.pIndex == bl.pArray.length) {
				ProcDecl[] tempP = bl.pArray;
				bl.pArray = new ProcDecl[bl.pIndex * 2];
				for (int i = 0; i < tempP.length; i++) {
					bl.pArray[i] = tempP[i];
				}
			}
		}
		s.skip(beginToken);
		bl.sl = StatmList.parse(s);
		s.skip(endToken);
		leaveParser("block");
		return bl;
	}

	@Override
	void prettyPrint() {
		if (cdp != null) {
			cdp.prettyPrint();
		}
		if (vdp != null) {
			vdp.prettyPrint();
		}
		int index = 0;
		while (fArray.length > index || pArray.length > index) {
			if (fArray[index] != null) {
				fArray[index].prettyPrint();
			} else if (pArray[index] != null) {
				pArray[index].prettyPrint();
			}
			index++;
		}
		Main.log.prettyPrintLn();
		Main.log.prettyPrintLn("begin ");
		Main.log.prettyIndent();
		sl.prettyPrint();
		Main.log.prettyOutdent();
		Main.log.prettyPrint("end");
	}

	PascalDecl findDecl(String id, PascalSyntax where) {
		PascalDecl d = hashDecl.get(id);
		if (d != null) {
			Main.log.noteBinding(id, where, d);
			return d;
		}
		// N�dt til � "hoppe" et ledd lengre ut. F.eks fra en block -> ytre
		// block.
		if (outerScope != null) {
			return outerScope.findDecl(id, where);
		}
		// Hvis vi ikke har noe ytre scope, men har library, g�r vi dit.
		else if (outerScope == null && lib != null) {
			return lib.findDecl(id, where);
		}
		where.error("Name " + id + " is unknown!");
		return null; // Required by the java compiler.
	}

	// Sjekker om s�ken�kkelen finnes i hashmappet. Dersom det gj�r det, skrives
	// det ut en feilmelding.
	// Hvis ikke legges den til i hashmappet.
	void addHashDecl(String id, PascalDecl d) {
		if (hashDecl.containsKey(id)) {
			d.error(id + " declared twice in same block!");
		}
		hashDecl.put(id, d);
	}

	@Override
	void check(Block curScope, Library lib) {
		this.lib = lib;
		if (cdp != null) {
			cdp.check(this, lib);
		}
		if (vdp != null) {
			vdp.check(this, lib);
		}
		int pos = 0;
		while (pArray[pos] != null) {
			pArray[pos].check(this, lib);
			pos++;
		}
		pos = 0;
		while (fArray[pos] != null) {
			fArray[pos].check(this, lib);
			pos++;
		}
		if (sl != null) {
			sl.check(this, lib);
		}
	}

	/*
	 * L�per f�rst gjennom proc-declene som finnes. Teller antall kall, m� s� sende med denne verdien innover
	 * og kaller p� proc-declene, gj�r det samme for func decl.
	 * Sjekker s� om det er noen variabler deklarerert i vdp. Hvis det ikke er det trenger vi ikke � sette av plass til
	 * variablene. Hvis den har variable, teller vi opp antallet og ganger med 4, og plusser p� 32.
	 * Sjekker s� om blocken gjelder for func, proc eller program. Dette fordi de har forskjellige assemble-outputs.
	 * 
	 * PS! Vi rakk dessverre ikke � ordne opp i arrays for del 3, checkeren. Vi valgte heller � prioritere � gj�re del 4 helt ferdig.
	 * Hovedgrunnen bak denne prioriteringa var fordi vi ikke beh�vde � ta for oss arrays i del 4. 
	 * I tillegg fikk vi tilbakemelding p� del 3-besvarelsen v�r at scanneren ikke skrev ut errors lenger.
	 * Vi sjekket opp dette, men p� alle "feilfiler" p� inf2100-siden, skrev den ut korrekte feilmeldinger,
	 * s� ikke helt sikker p� hva som var galt her. Muligens er det et problem vi ikke har m�tt p� i v�re gjennomkj�ringer.
	 */
	void genCode(CodeFile f) {
		if (cdp != null) {
			cdp.blokkNiv� = blokkNiv�;
		}
		if (vdp != null) {
			cdp.blokkNiv� = blokkNiv�;
		}
		int pos = 0;
		niv� = procfuncteller;

		while (pArray[pos] != null) {
			pArray[pos].blokkNiv� = blokkNiv� + 1;
			procfuncteller++;
			pArray[pos].procfuncteller = procfuncteller;
			pArray[pos].genCode(f);
			procfuncteller = pArray[pos].procfuncteller;
			pos++;
		}
		pos = 0;
		while (fArray[pos] != null) {
			fArray[pos].blokkNiv� = blokkNiv� + 1;
			procfuncteller++;
			fArray[pos].procfuncteller = procfuncteller;
			fArray[pos].genCode(f);
			procfuncteller = fArray[pos].procfuncteller;
			pos++;
		}

		if (vdp != null) {
			antallByte = antallByte + (4 * vdp.pos);
		}
		if (name.equals("func")) {
			f.genInstr("func$" + varName + "_" + niv�, "", "", "");
			f.genInstr("", "enter $" + antallByte + ",$" + blokkNiv�, "", " start of " + varName);
		} else if (name.equals("proc")) {
			f.genInstr("proc$" + varName + "_" + niv�, "", "", "");
			f.genInstr("", "enter $" + antallByte + ",$" + blokkNiv�, "", " start of " + varName);

		} else {
			f.genInstr("prog$" + programName + "_1", "", "", "");
			f.genInstr("", "enter $" + antallByte + ",$" + blokkNiv�, "", " start of " + programName);
		}

		sl.blokkNiv� = blokkNiv�;
		sl.genCode(f);

		if (name.equals("func")) {
			f.genInstr("", "movl", "-32(%ebp),%eax", "");
		}
		f.genInstr("", "leave", "", "");
		f.genInstr("", "ret", "", "End of " + varName);
	}
}
