package com.example.app.FUTmodes;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ola on 23.01.2017.
 */

public class Squad implements Serializable {
    String squadName;
    Map <String, Player> playersInSquad;
    Formation formation;
    int matches;
    int wins;
    int winpct;

    Squad(Formation form, String name){
        playersInSquad = new HashMap<String, Player>();
        formation = form;
        squadName = name;
        wins = 0;
        matches = 0;
        winpct = 0;
    }
    public Boolean isInSquad(Player pInn){
       for(Player p : playersInSquad.values()){
           if(p == pInn){
               return true;
           }
       }
        return false;
    }

    public void addPlayerToSquad(String pos, Player p){
        System.out.println("POS: " + pos + " name: " + p.name);
        playersInSquad.put(pos, p);
    }
    public void addMatch(){
        // Må fikse for seier etc senere
        winpct = (wins/matches);
    }
}
