package parser;

import static scanner.TokenKind.equalToken;
import static scanner.TokenKind.greaterEqualToken;
import static scanner.TokenKind.greaterToken;
import static scanner.TokenKind.lessEqualToken;
import static scanner.TokenKind.lessToken;
import static scanner.TokenKind.notEqualToken;

import main.Main;
import scanner.Scanner;

public class RelOpr extends Expression{
	String name;
	
	RelOpr(int lnum) {
		super(lnum);
	}
	@Override
	public String identify() {
		return "<rel opr> on line " + lineNum;
	}
	
	static RelOpr parse(Scanner s){
		enterParser("rel opr");
		RelOpr ropr = new RelOpr(s.curLineNum());
		if (s.curToken.kind.equals(equalToken)){
			ropr.name = " = ";
			s.skip(equalToken);
		}
		else if (s.curToken.kind.equals(notEqualToken)){
			ropr.name = " <> ";
			s.skip(notEqualToken);
		}
		else if(s.curToken.kind.equals(lessToken)){
			ropr.name = " < ";
			s.skip(lessToken);
		}
		else if (s.curToken.kind.equals(lessEqualToken)){
			ropr.name = " <= ";
			s.skip(lessEqualToken);
		}
		else if(s.curToken.kind.equals(greaterToken)){
			ropr.name = " > ";
			s.skip(greaterToken);
		}
		else if (s.curToken.kind.equals(greaterEqualToken)){
			ropr.name = " >= ";
			s.skip(greaterEqualToken);
		}
		else{
			System.out.println("Feil. Ugyldig tegn!");
		}
		
		leaveParser("rel opr");
		return ropr;
	}
	@Override
	void prettyPrint() {
		Main.log.prettyPrint(name);
	}
	
	@Override
	void check(Block curScope, Library lib){
	}
}
