package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Timer;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity{
    private String username;
    DatabasePlayers dbPlayers = new DatabasePlayers(this);
    DatabaseSquads dbSquads = new DatabaseSquads(this);
    UserFormationDatabase userFormDB = new UserFormationDatabase(this);
    PlayerstatsDB playerstatsDB = new PlayerstatsDB(this);
    
    ArrayList<String> mostPlayerGoals;
    ArrayList<String> mostPlayerMatches;
    ArrayList<String> mostPlayerAssists;
    
    private int goalsPos;
    private int matchPos;
    private int assistsPos;

    ImageView imageViewPlayerGoals;
    ImageView imageViewPlayerMatches;
    ImageView imageViewPlayerAssists;

    Timer timer;
    TextView xmlPlayerGoals;
    TextView xmlPlayerMatches;
    TextView xmlPlayerAssists;
    TextView xmlSquadMatches;
    TextView xmlSquadWins;
    TextView xmlSquadGoals;
    TextView xmlPossession;
    TextView xmlFormationName;
    TextView xmlFormationMatches;
    TextView xmlFormationWinRate;
    TextView xmlBestSquadName;
    TextView xmlBestSquadFormationName;
    TextView xmlBestSquadWinRate;

    private String [] topSquad;

    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Reading player-database from file
        dbPlayers.addPlayersFromFile();

        Intent intent = getIntent();
        username = intent.getExtras().getString("username");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillClubStatsWithInfo();
    }

    public void fillClubStatsWithInfo(){
        // Get all matches and all wins for username

        mostPlayerMatches = playerstatsDB.getTopPlayers(username, "matches");
        mostPlayerGoals = playerstatsDB.getTopPlayers(username, "goals");
        mostPlayerAssists = playerstatsDB.getTopPlayers(username, "assists");

        int usersMatches = dbSquads.getStatForUser(username, "matches");
        int usersWins = dbSquads.getStatForUser(username, "wins");
        int usersGoals = dbSquads.getStatForUser(username, "goalsScored");
        double usersPossession = dbSquads.getStatForUser(username, "possession");

        ArrayList<String> bestFormationNames = userFormDB.getBestFormation(username);

        String formationName ="None";
        int formationMatches = 0;
        int formationWins = 0;
        if(bestFormationNames.size()>0){
            for(int i = 0; i<bestFormationNames.size(); i++){
                String [] formationInfo = userFormDB.getFormationInfo(username, bestFormationNames.get(i));
                if(Integer.parseInt(formationInfo[1])>formationMatches) {
                    formationName = formationInfo[0];
                    formationMatches = Integer.parseInt(formationInfo[1]);
                    formationWins = Integer.parseInt(formationInfo[2]);
                }
            }
        }
        goalsPos = 0;
        matchPos = 0;
        assistsPos = 0;
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (goalsPos < mostPlayerGoals.size()) {
                    // Updates the main ui that runs.
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            xmlPlayerGoals = (TextView) findViewById(R.id.goalsTextView);
                            xmlPlayerGoals.setText("Goals: " + playerstatsDB.getSpecificPlayerStat(username, mostPlayerGoals.get(goalsPos), "goals"));
                            imageViewPlayerGoals = (ImageView) findViewById(R.id.playerpicgoals);
                            String name = mostPlayerGoals.get(goalsPos);
                            name = name.replaceAll("\\s", "");
                            int resID = getResources().getIdentifier(name.toLowerCase(), "drawable", getPackageName());

                            if (resID != 0) {
                                imageViewPlayerGoals.setImageResource(resID);
                            } else {
                                imageViewPlayerGoals.setImageResource(R.mipmap.vitalogo);
                            }
                            goalsPos++;
                        }
                    });
                }
                else{
                    goalsPos = 0;
                }
                if (matchPos < mostPlayerMatches.size()) {
                    // Updates the main ui that runs.
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            xmlPlayerMatches = (TextView) findViewById(R.id.matchesTextView);
                            xmlPlayerMatches.setText("Matches: " + playerstatsDB.getSpecificPlayerStat(username, mostPlayerMatches.get(matchPos), "matches"));
                            imageViewPlayerMatches = (ImageView) findViewById(R.id.playerpicmatches);
                            String name = mostPlayerMatches.get(matchPos);
                            name = name.replaceAll("\\s", "");
                            int resID = getResources().getIdentifier(name.toLowerCase(), "drawable", getPackageName());
                            if (resID != 0) {
                                imageViewPlayerMatches.setImageResource(resID);
                            } else {
                                imageViewPlayerMatches.setImageResource(R.mipmap.vitalogo);
                            }
                            matchPos++;
                        }
                    });
                }
                else{
                    matchPos = 0;
                }
                if (assistsPos < mostPlayerAssists.size()) {
                    // Updates the main ui that runs.
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            xmlPlayerAssists = (TextView) findViewById(R.id.assistTextView);
                            xmlPlayerAssists.setText("Assists: " + playerstatsDB.getSpecificPlayerStat(username, mostPlayerAssists.get(assistsPos), "assists"));
                            imageViewPlayerAssists = (ImageView) findViewById(R.id.playerpicassists);
                            String name = mostPlayerAssists.get(assistsPos);
                            name = name.replaceAll("\\s", "");
                            int resID = getResources().getIdentifier(name.toLowerCase(), "drawable", MainActivity.this.getPackageName());

                            if (resID != 0) {
                                imageViewPlayerAssists.setImageResource(resID);
                            } else {
                                imageViewPlayerAssists.setImageResource(R.mipmap.vitalogo);
                            }
                            assistsPos++;
                        }
                    });
                }
                else{
                    assistsPos = 0;
                }
            }
        }, 0,5000);

        xmlSquadMatches = (TextView) findViewById(R.id.nrOfMatches);
        xmlSquadMatches.setText(Integer.toString(usersMatches));
        xmlSquadWins = (TextView) findViewById(R.id.nrOfWins);
        xmlSquadWins.setText(Integer.toString(usersWins));
        xmlSquadGoals = (TextView) findViewById(R.id.nrOfGoals);
        xmlSquadGoals.setText(Integer.toString(usersGoals));
        usersPossession = usersPossession/usersMatches;
        xmlPossession = (TextView) findViewById(R.id.amountOfPossession);
        //xmlPossession.setText(Double.toString(usersPossession));
        xmlPossession.setText(String.format( "%.1f", usersPossession));

        xmlFormationName = (TextView) findViewById(R.id.bestFormationName);
        xmlFormationName.setText(formationName);
        xmlFormationMatches = (TextView) findViewById(R.id.bestFormationMatches);
        xmlFormationMatches.setText(Integer.toString(formationMatches));
        xmlFormationWinRate = (TextView) findViewById(R.id.bestFormationWinRate);
        int formationWinRate = 0;

        if(formationMatches>0){
            if(formationWins>0){
                formationWins = formationWins*100;
                formationWinRate = formationWins / formationMatches;
            }
        }
        xmlFormationWinRate.setText(Integer.toString(formationWinRate) + "%");

        topSquad = dbSquads.getTopSquad(username);
        xmlBestSquadName = (TextView) findViewById(R.id.topSquadName);
        xmlBestSquadName.setText(topSquad[0]);
        xmlBestSquadFormationName = (TextView) findViewById(R.id.topSquadFormationName);
        xmlBestSquadFormationName.setText(topSquad[1]);

        Double squadWinRate = Double.parseDouble(topSquad[2]);
        xmlBestSquadWinRate = (TextView) findViewById(R.id.topSquadWinRate);
        xmlBestSquadWinRate.setText(String.format( "%.1f", squadWinRate));


    }
    public void cancelTimer() {
        if(timer!=null)
            timer.cancel();
    }

    public void onClubStats(View view) {
        cancelTimer();
        Intent myIntentStatsHUB = new Intent(MainActivity.this, StatsHub.class);
        myIntentStatsHUB.putExtra("username", username);
        MainActivity.this.startActivity(myIntentStatsHUB);
        Intent myIntentGM = new Intent(MainActivity.this, GameModeActivity.class);
        myIntentGM.putExtra("username", username);
        MainActivity.this.startActivity(myIntentGM);
    }

    public void onSilverCard(View view) {
        cancelTimer();
        Intent myIntentStatsHUB = new Intent(MainActivity.this, StatsHub.class);
        myIntentStatsHUB.putExtra("username", username);
        MainActivity.this.startActivity(myIntentStatsHUB);
    }

    public void onBronzeCard(View view) {
        cancelTimer();
        // Saving player database to file
        //databaseState.savePlayerDB();
        //databaseState.saveSquadDB();
        //databaseState.saveFormations();
        MainActivity.this.finish();
        System.exit(0);
    }
}