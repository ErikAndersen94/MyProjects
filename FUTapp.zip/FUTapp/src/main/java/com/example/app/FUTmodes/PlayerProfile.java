package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;

import java.util.ArrayList;
import android.graphics.Color;
import android.view.WindowManager;

import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

public class PlayerProfile extends AppCompatActivity {
    private static TextView rating_textview;
    private static RatingBar rating_b;
    PlayerstatsDB myPlayers = new PlayerstatsDB(this);
    ArrayList<String> players;
    ImageView imageViewFlag;
    String username;
    ImageView imageViewPlayer;
    private BarChart mChart;
    String playerName;
    DatabasePlayers allPlayers = new DatabasePlayers(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_player_profile);
        //listenerForRatingBar();
        Intent intent = getIntent();
        playerName = intent.getExtras().getString("playerName");
        username = intent.getExtras().getString("username");
        players = myPlayers.getPlayersStats(username,"DESC", "playerName");

        TextView txtPlayed = (TextView) findViewById(R.id.matches_played);
        int matches = Integer.parseInt(myPlayers.getSpecificPlayerStat(username, playerName, "matches"));
        if(matches > 0) {
            txtPlayed.setText(Integer.toString(matches));

            TextView txtGoals = (TextView) findViewById(R.id.goals_);
            txtGoals.setText(myPlayers.getSpecificPlayerStat(username, playerName, "goals"));

            TextView txtAssists = (TextView) findViewById(R.id.assists_);
            txtAssists.setText(myPlayers.getSpecificPlayerStat(username, playerName, "assists"));

            TextView txtAvgPoints = (TextView) findViewById(R.id.points_avg);
            String avgPoints = myPlayers.getSpecificPlayerStat(username, playerName, "avg");
            txtAvgPoints.setText((avgPoints));
        }
        else{
            TextView txtGoals = (TextView) findViewById(R.id.goals_);
            txtGoals.setText("0");
            TextView txtAssists = (TextView) findViewById(R.id.assists_);
            txtAssists.setText("0");
            TextView txtAvgPoints = (TextView) findViewById(R.id.points_avg);
            txtAvgPoints.setText("0");
        }
        String [] playerInfo = allPlayers.getPlayerInfo(playerName);

        TextView txtPos = (TextView) findViewById(R.id.position_);
        txtPos.setText(playerInfo[5]);

        TextView txtName = (TextView) findViewById(R.id.playerName_);
        txtName.setText(playerInfo[1]);

        RatingBar skillRating = (RatingBar) findViewById(R.id.ratingBar_skillMove);
        skillRating.setRating(Float.parseFloat(playerInfo[7]));

        RatingBar weakFootRating = (RatingBar) findViewById(R.id.ratingBar_weakFoot);
        weakFootRating.setRating(Float.parseFloat(playerInfo[8]));

        imageViewFlag = (ImageView) findViewById(R.id.nationPicture);
        int resID = 0;
        resID = getResources().getIdentifier(playerInfo[3].toLowerCase(), "drawable", this.getPackageName());

        if(resID != 0){
            imageViewFlag.setImageResource(resID);
        }
        else{
            imageViewFlag.setImageResource(R.drawable.pirate);
        }

        imageViewPlayer = (ImageView) findViewById(R.id.playerPicture);
        resID = 0;
        String name = playerInfo[1];
        name = name.replaceAll("\\s","");
        resID = getResources().getIdentifier(name.toLowerCase(), "drawable", this.getPackageName());

        if(resID != 0){
            imageViewPlayer.setImageResource(resID);
        }
        else{
            imageViewPlayer.setImageResource(R.mipmap.vitalogo);
        }

        /*
        * UNDER HER ER KODE FOR Å VISE DE FEM SISTE KAMPENE GRAFISK
         */

        mChart = (BarChart) findViewById(R.id.lastFiveChart);

        mChart.getDescription().setEnabled(false);
        mChart.setMaxVisibleValueCount(60);
        mChart.setPinchZoom(false);
        mChart.setDrawGridBackground(false);
        mChart.setDrawBarShadow(false);
        mChart.setDrawValueAboveBar(false);
        mChart.setHighlightFullBarEnabled(false);

        YAxis leftAxis = mChart.getAxisLeft();
        //leftAxis.setAxisMinimum(0f);
        leftAxis.setTextColor(Color.WHITE);

        mChart.getAxisRight().setEnabled(false);
        mChart.getXAxis().setEnabled(false);

        Legend l = mChart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
        l.setFormSize(8f);
        l.setFormToTextSpace(4f);
        l.setTextSize(14f);
        l.setXEntrySpace(6f);
        l.setTextColor(Color.WHITE);

        setData();
    }

    public void setData(){
    // Fill yVvals1 with last5 stats from database.


        ArrayList<BarEntry> yVals1 = new ArrayList<BarEntry>();
        int [][] last5 = myPlayers.last5Stats(username, playerName);

        for(int j = 0; j < 5; j++){
                yVals1.add(new BarEntry(j + 1, new float[]{last5[j][0], last5[j][1]}));
        }

    BarDataSet set1;

    if (mChart.getData() != null &&
            mChart.getData().getDataSetCount() > 0) {
        set1 = (BarDataSet) mChart.getData().getDataSetByIndex(0);
        set1.setValues(yVals1);
        mChart.getData().notifyDataChanged();
        mChart.notifyDataSetChanged();
    } else {
        set1 = new BarDataSet(yVals1, "");
        set1.setColors(getColors());
        set1.setStackLabels(new String[]{"Goals", "Assists"});

        ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
        dataSets.add(set1);

        BarData data = new BarData(dataSets);
        //data.setValueFormatter(new MyValueFormatter());
        data.setValueTextColor(Color.WHITE);
        data.setValueTextSize(7);


        mChart.setData(data);
    }

    mChart.setFitBars(true);
    mChart.invalidate();
}


    private int[] getColors() {

        int stacksize = 2;

        // have as many colors as stack-values per entry
        int[] colors = new int[stacksize];

        for (int i = 0; i < colors.length; i++) {
            colors[i] = ColorTemplate.COLORFUL_COLORS[i];
        }

        return colors;
    }

}
