package parser;

import scanner.*;
import static scanner.TokenKind.*;

import main.CodeFile;

public class Constant extends ConstDecl {
	PrefixOpr popr;
	UnsignedConstant unco;
	types.Type type;
	int constVal;
	int blokkNiv�;

	Constant(int lnum) {
		super("", lnum);
	}

	@Override
	public String identify() {
		return "<Constant> on line " + lineNum;
	}

	static Constant parse(Scanner s) {
		enterParser("Constant");
		Constant c = new Constant(s.curLineNum());

		if (s.curToken.kind.equals(addToken) || s.curToken.kind.equals(subtractToken)) {
			c.popr = PrefixOpr.parse(s);
		}
		c.unco = UnsignedConstant.parse(s);
		leaveParser("Constant");

		return c;
	}

	// Kaller kun p� PrefixOpr om popr har en verdi.
	@Override
	void prettyPrint() {
		if (popr != null) {
			popr.prettyPrint();
		}
		unco.prettyPrint();
	}

	/*
	 * Setter constant sin type til � v�re unco sin type. Hvis vi har en prefix opr m� vi sjekke om unco sin type
	 * er den samme som prefix sin type(integers). Hvis ikke f�r vi en feilmelding. I tillegg endrer vi fortegn
	 * p� konstanten constVal om vi har en negativ prefix.
	 */
	@Override
	void check(Block curScope, Library lib) {
		unco.check(curScope, lib);
		type = unco.type;
		constVal = unco.constVal;
		if (popr != null) {
			String oprName = popr.name;
			unco.type.checkType(lib.intType, "Prefix " + oprName, this,
					"Prefix + or - may only be applied to Integers.");
			if (popr.name == " - ")
				constVal = -constVal;
		}
	}
	@Override void genCode(CodeFile f) {
		unco.blokkNiv� = blokkNiv�;
		unco.genCode(f);
		if(popr!= null && popr.name == " - "){ // Sjekker om prefixen er et minustegn.
			f.genInstr("", "negl", "%eax", " - (prefix)");
		}
	}
}
