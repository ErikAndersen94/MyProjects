package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class FuncCall extends Factor {
	String name;
	Expression expr;
	Expression[] exprArray = new Expression[10];
	int index = 0;
	FuncDecl fdRef;
	types.Type type;
	int blokkNiv�;
	int antallParam = 0;
	
	FuncCall(int lnum) {
		super(lnum);
	}

	public String identify() {
		return "<func call> on line " + lineNum;
	}

	static FuncCall parse(Scanner s) {
		boolean loop = true;

		enterParser("func call");
		FuncCall fc = new FuncCall(s.curLineNum());
		// Tester som curToken er nameToken. Hvis det stemmer lagres tokens
		// navn.
		s.test(nameToken);
		fc.name = s.curToken.id;
		s.skip(nameToken);
		if (s.curToken.kind.equals(leftParToken)) {
			s.skip(leftParToken);
			while (loop) {
				fc.expr = Expression.parse(s);
				fc.exprArray[fc.index++] = fc.expr;
				if (s.curToken.kind.equals(commaToken)) {
					s.skip(commaToken);
				} else {
					loop = false;
				}
				if (fc.index == fc.exprArray.length) {
					// dobler arrayets str.
					Expression[] etemp = fc.exprArray;
					fc.exprArray = new Expression[fc.index * 2];
					for (int i = 0; i < etemp.length; i++) {
						fc.exprArray[i] = etemp[i];
					}
				}
			}
			s.skip(rightParToken);
		}

		leaveParser("func call");
		return fc;
	}

	@Override
	void prettyPrint() {
		int index = 0;
		Main.log.prettyPrint(name);
		if (exprArray[index] != null) {
			Main.log.prettyPrint("(");
			exprArray[index++].prettyPrint();
			while (exprArray[index] != null) {
				Main.log.prettyPrint(", ");
				exprArray[index++].prettyPrint();
			}
			Main.log.prettyPrint(")");
		}
	}

	@Override
	void check(Block curScope, Library lib) {
		PascalDecl d = curScope.findDecl(name, this);
		d.checkWhetherFunction(this);
		fdRef = (FuncDecl) d;
		type = fdRef.tn.type;

		int pos = 0;
		while (exprArray[pos] != null) {
			exprArray[pos].check(curScope, lib);
			antallParam ++;
			pos++;

		}
		if (fdRef.pdl != null && fdRef.pdl.index == index) {
			// itererer gjennom funksjonens parametere og typesjekker de mot funksjonskallets parametere.
			int counter = 0;
			while (counter < index) {
				fdRef.pdl.pdArray[counter].type.checkType(exprArray[counter].type, "param #" + (counter + 1), this,
						"The parameters are of different type");
				counter++;
			}
		}
		else if (fdRef.pdl == null && index == 0) {
			// tilfelle hvor funksjonen ikke forventer noen parametere og heller ikke f�r det.
		} 
		else{
			fdRef.error("Different number of parameters");
		}
	}
	
	@Override
	void genCode(CodeFile f){
		int pos = 0;
		//exprArray[pos].type.identify();
		while (pos < antallParam) {
			exprArray[antallParam-pos-1].blokkNiv� = blokkNiv�;
			exprArray[antallParam-pos-1].genCode(f);
			f.genInstr("", "pushl", "%eax", "push param #" + (antallParam-pos));
			pos++;
		}
		f.genInstr("", "call", "func$" + fdRef.name + "_" + fdRef.blokkNiv�, "");
		f.genInstr("", "addl", "$" + antallParam*4 + ",%esp", "");

	}
}
