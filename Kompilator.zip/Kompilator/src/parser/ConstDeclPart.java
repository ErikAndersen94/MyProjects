package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ConstDeclPart extends Block {
	ConstDecl cDecl;
	ConstDecl[] cDeclArray = new ConstDecl[10];
	int index = 0;
	int pos = 0;
	int blokkNiv�;

	ConstDeclPart(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<ConstDeclPart> on line " + lineNum;
	}

	static ConstDeclPart parse(Scanner s) {
		boolean loop = true;
		enterParser("ConstDeclPart");
		s.skip(constToken);
		
		ConstDeclPart cdp = new ConstDeclPart(s.curLineNum());
		
		// Det f�rste tegnet er uansett en simpleExpr, hvis vi ikke har
		// rel opr som neste token returnerer vi fra expression.
		while (loop) {
			cdp.cDecl = ConstDecl.parse(s);
			cdp.cDeclArray[cdp.index++] = cdp.cDecl;
			if (!s.curToken.kind.equals(nameToken)) {
				loop = false;
			}
			if (cdp.index == cdp.cDeclArray.length) {
				// Array er fullt, dobler str.
				ConstDecl[] tempDecl = cdp.cDeclArray;
				cdp.cDeclArray = new ConstDecl[cdp.index * 2];
				for(int i = 0; i<tempDecl.length; i++){
					cdp.cDeclArray[i] = tempDecl[i];
				}
			}
		}
		
		leaveParser("ConstDeclPart");

		return cdp;
	}

	@Override
	void prettyPrint() {
		int index = 0;
		Main.log.prettyPrintLn("const ");
		while (cDeclArray[index] != null) {
			cDeclArray[index++].prettyPrint();
		}
	}
	@Override
	void check(Block curScope, Library lib){
		while(cDeclArray[pos] != null){
			cDeclArray[pos].check(curScope, lib);
			pos++;
		}
	}
	
	@Override void genCode(CodeFile f) {
		int index = 0;
		while (cDeclArray[index] != null) {
			cDeclArray[index].blokkNiv� = blokkNiv�;
			cDeclArray[index].genCode(f);
			index++;
		}
	}
}