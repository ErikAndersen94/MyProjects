package com.example.app.FUTmodes;

import java.util.Random;

/**
 * Created by Ola on 31.08.2017.
 */

public class SquadBuildingChallenge {
    private int [] budgetValues = {5000, 15000, 40000, 70000, 100000, 150000, 200000, 300000, 400000, 500000, 1000000, 10000000};
    private String [] nations = {"Argentina", "Austria", "Belgium", "Brazil", "Bosnia", "Cameroon", "Chile", "Colombia", "Ivory Coast", "Croatia" , "Czech Republic", "Denmark", "England", "France"};



    public int getBudget(){
        int rnd = new Random().nextInt(budgetValues.length);
        return budgetValues[rnd];
    }

    public String getNation(){
        int rnd = new Random().nextInt(nations.length);
        return nations[rnd];
    }

    public int getNumberFromSpecificNation(){
        int rnd = new Random().nextInt(4 - 1) + 1;
        return rnd;
    }

    public int getNumberOfNations(){
        int rnd = new Random().nextInt(5 - 1) + 1;
        return rnd;
    }

    public int getNumberOfLeagues(){
        int rnd = new Random().nextInt(5 - 1) + 1;
        return rnd;
    }

    public int getNumberOfSpecialCards(){
        int rnd = new Random().nextInt(3 - 0);
        return rnd;
    }

    public int getNumberOfWorseThanGold(){
        int rnd = new Random().nextInt(3 - 0);
        return rnd;
    }



}
