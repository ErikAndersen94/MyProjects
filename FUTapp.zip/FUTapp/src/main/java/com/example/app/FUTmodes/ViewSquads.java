package com.example.app.FUTmodes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class ViewSquads extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    ArrayList<String> squads;
    ArrayList<String> correctSquads;
    ArrayList<String> allFormations;
    DatabaseSquads dbSquads = new DatabaseSquads(this);
    ArrayAdapter<String> squadAdapter;
    String item = "3412";
    String username;
    Formation f = new Formation(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_squads);
        Intent intent = getIntent();
        username = intent.getExtras().getString("username");
        squads = dbSquads.getAllSquadNames(username, item);

        Spinner dropdown = (Spinner) findViewById(R.id.spinnerViewSquad);
        dropdown.setOnItemSelectedListener(this);
        allFormations = f.getFormationNames();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, allFormations);
        dropdown.setAdapter(adapter);

    }

    private void populateListView() {
        if (correctSquads != null) {
            squads = dbSquads.getAllSquadNames(username, item);
            squadAdapter = new ViewSquads.MyListAdapter();
            ListView list = (ListView) findViewById(R.id.squad_list);
            list.setAdapter(squadAdapter);
        }
        else{
            System.out.println("There isn't any squads registered");
            ListView list = (ListView) findViewById(R.id.squad_list);
            list.setAdapter(null);
        }
    }

    public class MyListAdapter extends ArrayAdapter<String> {
        CustomButtonListener customButtonListener;


        public MyListAdapter() {
            super(ViewSquads.this, R.layout.squad_view, squads);
        }

        public void setCustomButtonListener(CustomButtonListener customButtonListenerIn) {
            this.customButtonListener = customButtonListenerIn;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            // Make sure we have a view to work with(may have been given null)
            View itemView = convertView;
            ViewSquads.ViewHolder viewHolder;
            if (itemView == null) {
                itemView = getLayoutInflater().inflate(R.layout.squad_view, parent, false);
                viewHolder = new ViewSquads.ViewHolder();
                viewHolder.chosenFormation = item;
                viewHolder.customizeButton = (Button) itemView.findViewById(R.id.customizeButton);
                itemView.setTag(viewHolder);
            } else {
                viewHolder = (ViewSquads.ViewHolder) itemView.getTag();
            }

            // Find the squad to work with
            if(correctSquads == null){
                System.out.println("No squads exist");
                TextView squadName = (TextView) itemView.findViewById(R.id.squad_view_name);
                squadName.setText("");
                TextView winpct = (TextView) itemView.findViewById(R.id.squad_view_winpct);
                winpct.setText("" + dbSquads.getWinPct(Integer.parseInt("0")));
            }
            else{

            final String currentSquad = correctSquads.get(position);
            final String [] squadInfo = dbSquads.getSquadInfo(username, currentSquad);
            if (squadInfo != null && squadInfo[3].equals(item)) {
                final String form = squadInfo[3];

                // Fill the view
                // Name
                TextView squadName = (TextView) itemView.findViewById(R.id.squad_view_name);
                squadName.setText(squadInfo[2]);


                // win-pct. må konverteres til string, gjøres ved ""
                TextView winpct = (TextView) itemView.findViewById(R.id.squad_view_winpct);
                winpct.setText("" + dbSquads.getWinPct(Integer.parseInt(squadInfo[0])));

                // Kan brukes om vi legger til bilder av spillerne
                //ImageView imageView = (ImageView) itemView.findViewById(R.id.xxx);
                //imageView.setImageDrawable(currentPlayer.pic);
                viewHolder.chosenFormation = form;
                viewHolder.customizeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (customButtonListener != null) {
                            customButtonListener.onButtonClickListener(position, form);
                        }
                        Intent myIntentSquadProfile = new Intent(ViewSquads.this, SquadProfile.class);
                        myIntentSquadProfile.putExtra("squadName", squadInfo[2]);
                        myIntentSquadProfile.putExtra("username", username);
                        ViewSquads.this.startActivity(myIntentSquadProfile);
                    }
                });
            }
            }
            return itemView;
        }
    }

    public class ViewHolder {
        String chosenFormation;
        Button customizeButton;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        item = parent.getItemAtPosition(pos).toString();
        correctSquads = new ArrayList<String>();
        correctSquads = dbSquads.getAllSquadNames(username, item);
        if (correctSquads == null) {
            System.out.println("Not any squads available");
            populateListView();

        } else {
            populateListView();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        item = "3412";
        correctSquads = new ArrayList<String>();
        correctSquads = dbSquads.getAllSquadNames(username, item);
        if (correctSquads == null) {
            populateListView();
            System.out.println("Not any squads available");
        } else {
            populateListView();
        }
    }
}
