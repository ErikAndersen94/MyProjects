package parser;

import java.util.HashMap;

import main.CodeFile;
import main.Main;
import types.*;

/*Er ikke helt sikker p� hvordan vi skal f� laget en array-deklarasjon med et korrekt s�kenavn
* som kan brukes til navnebinding senere. 
* Tar gjerne i mot tips p� tilbakemeldingen hvordan vi kan l�se dette p� en annen m�te.
* 
* I Library oppretter vi "kunstig" hashmap som vi fyller med predefinerte deklarasjoner av typene: integer, boolean,
* char som er subklasser av type decl. I tillegg fyller vi hashmappet med eol, true og false som er konstant deklarasjoner.
* Til slutt har vi ogs� med write som er en prosedyre deklarasjon. 
* 
*/
public class Library extends Block {
	Block bl;
	TypeDecl integerType;
	TypeDecl booleanType;
	TypeDecl TDarrayType;
	TypeDecl TDcharType;
	types.IntType intType;
	types.BoolType boolType;
	types.CharType charType;
	types.ArrayType arrayType;
	types.Type at1;
	TypeDecl intArray;
	TypeDecl boolArray;
	TypeDecl charArray;
	HashMap<String, PascalDecl> hashDecl = new HashMap<String, PascalDecl>();
	ProcDecl pd;
	ConstDecl cd;
	PascalDecl d;
	
	public Library() {
		addHashDecl();
	}
	
	public String identify() {
		return "<TypeName> on line " + lineNum;
	}
	
	PascalDecl findDecl(String id, PascalSyntax where) {
		PascalDecl d = hashDecl.get(id);
		if (d != null) {
			Main.log.noteBinding(id, where, d);
			return d;
		}
		where.error("Name " + id + " is unknown!");
		return null; // Required by the java compiler.
	}

	void addHashDecl() {
		pd = new ProcDecl("write", -1);
		d = (PascalDecl)pd;
		if (hashDecl.containsKey("write")) {
			d.error("write declared twice in same block!");
		}
		hashDecl.put("write", d);
		
		cd = new ConstDecl("eol", -1 );
		d = (PascalDecl) cd;
		if (hashDecl.containsKey("eol")) {
			d.error("eol declared twice in same block!");
		}
		hashDecl.put("eol", d);
		
		boolType = new BoolType();

		cd = new ConstDecl("false", -1 );
		cd.type = boolType;
		d = (PascalDecl) cd;
		if (hashDecl.containsKey("false")) {
			d.error("false declared twice in same block!");
		}
		hashDecl.put("false", d);
		
		cd = new ConstDecl("true", -1 );
		cd.type = boolType;
		d = (PascalDecl) cd;
		if (hashDecl.containsKey("true")) {
			d.error("true declared twice in same block!");
		}
		hashDecl.put("true", d);
		
		intType = new IntType();
		integerType = new TypeDecl("integer", -1);
		integerType.setType(intType);
		d = (PascalDecl) integerType;
		if (hashDecl.containsKey("integer")) {
			d.error("integer declared twice in same block!");
		}
		hashDecl.put("integer", d);
		
		booleanType = new TypeDecl("boolean", -1);
		booleanType.setType(boolType);
		d = (PascalDecl) booleanType;
		if (hashDecl.containsKey("boolean")) {
			d.error("boolean declared twice in same block!");
		}
		hashDecl.put("boolean", d);
		
		charType = new CharType();
		TDcharType = new TypeDecl("char", -1);
		TDcharType.setType(charType);
		d = (PascalDecl) TDcharType;
		if (hashDecl.containsKey("char")) {
			d.error("char declared twice in same block!");
		}
		hashDecl.put("char", d);
		
		
		
	/*	arrayType = new types.ArrayType(at1, at1, 0, 10);
		intArray = new TypeDecl("intArray", -1);
		intArray.setType(arrayType);
		d = (PascalDecl) intArray;
		if (hashDecl.containsKey("intArray")) {
			d.error("integer array declared twice in same block!");
		}
		hashDecl.put("intArray", d);
		
		arrayType = new types.ArrayType(at1, at1, 0, 10);
		boolArray = new TypeDecl("boolArray", -1);
		boolArray.setType(arrayType);
		d = (PascalDecl) boolArray;
		if (hashDecl.containsKey("boolArray")) {
			d.error("boolean array declared twice in same block!");
		}
		hashDecl.put("boolArray", d);
		
		arrayType = new types.ArrayType(at1, at1, 0, 10);
		charArray = new TypeDecl("charArray", -1);
		charArray.setType(arrayType);
		d = (PascalDecl) charArray;
		if (hashDecl.containsKey("charArray")) {
			d.error("char array declared twice in same block!");
		}
		hashDecl.put("charArray", d);
	*/	
	}
	
	public void genCode(CodeFile f) {
	}
	
}
