package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ConstDecl extends PascalDecl {
	Constant c;
	String constname;
	PascalDecl pd;
	String libId;
	int libNum;
	types.Type type;
	int constVal;
	int blokkNiv�;

	ConstDecl(String id, int lnum) {
		super(id, lnum);
		libId = id;
		libNum = lnum;
	}

	@Override
	public String identify() {
		if (libNum == -1) {
			return "<const decl> " + libId + " in the library";
		} else {
			return "<const decl> on line " + lineNum;
		}
	}

	static ConstDecl parse(Scanner s) {
		enterParser("ConstDecl");
		ConstDecl cd = new ConstDecl(s.curToken.id, s.curLineNum());

		s.test(nameToken);
		cd.constname = s.curToken.id;
		s.skip(nameToken);
		s.skip(equalToken);
		cd.c = Constant.parse(s);
		s.skip(semicolonToken);

		leaveParser("ConstDecl");

		return cd;
	}

	@Override
	void prettyPrint() {

		Main.log.prettyIndent();
		Main.log.prettyPrint(constname);
		Main.log.prettyPrint(" = ");
		c.prettyPrint();
		Main.log.prettyPrintLn(";");
		Main.log.prettyOutdent();
	}

	/*
	 * ConstDecl er en const deklarasjon. Vi adder konstant til hashmappet med navnet til konstanten som n�kkel.
	 * Setter i tillgg typen til � v�re constant sin type. 
	 */
	@Override
	void check(Block curScope, Library lib) {
		// pd = (PascalDecl) this;
		curScope.addHashDecl(constname, this);
		c.check(curScope, lib);
		type = c.type;
		constVal = c.constVal;
	}

	@Override
	void checkWhetherAssignable(PascalSyntax where) {
		where.error("You cannot assign to a constant.");
	}

	@Override
	void checkWhetherFunction(PascalSyntax where) {
		where.error("Constant cannot be a function.");

	}

	@Override
	void checkWhetherProcedure(PascalSyntax where) {
		where.error("Constant cannot be a Procedure.");
	}

	@Override
	void checkWhetherValue(PascalSyntax where) {
		// TODO Auto-generated method stub

	}
	
	void genCode(CodeFile f) {
		c.blokkNiv� = blokkNiv�;
		c.genCode(f);
		
	}
}
