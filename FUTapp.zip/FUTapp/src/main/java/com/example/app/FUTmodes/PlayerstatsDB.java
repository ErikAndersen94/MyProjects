package com.example.app.FUTmodes;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatatypeMismatchException;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


/**
 * Created by Ola on 26.08.2017.
 */

public class PlayerstatsDB extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "futplayers.db";
    public static final String PLAYERSTATS_TABLE_NAME = "playerstats";
    public static final String PLAYERSTATS_COLUMN_USERNAME = "username";
    public static final String PLAYERSTATS_COLUMN_PLAYERNAME = "playerName";
    public static final String PLAYERSTATS_COLUMN_MATCHES = "matches";
    public static final String PLAYERSTATS_COLUMN_GOALS = "goals";
    public static final String PLAYERSTATS_COLUMN_ASSISTS = "assists";
    public static final String PLAYERSTATS_COLUMN_TOTALPOINTS = "totalpoints";
    public static final String PLAYERSTATS_COLUMN_RATING = "rating";

    public static final String PLAYERLAST5_TABLE_NAME = "playerlast5";
    public static final String PLAYERLAST5_COLUMN_USERNAME = "username";
    public static final String PLAYERLAST5_COLUMN_PLAYERNAME = "playerName";
    public static final String PLAYERLAST5_COLUMN_MATCHES = "matches";
    public static final String PLAYERLAST5_COLUMN_GOALS = "goals";
    public static final String PLAYERLAST5_COLUMN_ASSISTS = "assists";
    public static final String PLAYERLAST5_COLUMN_TOTALPOINTS = "totalpoints";
    public static final String PLAYERLAST5_COLUMN_DATEADDED = "dateAdded";

    Context context;


    public PlayerstatsDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table playerstats " +
                        "(username text, playerName text, matches num, goals num, assists num, totalpoints num, rating num, primary key(username, playerName))"
        );

        db.execSQL(
                "create table playerlast5 " +
                        "(username text, playerName text, goals num, assists num, totalpoints num, dateAdded date, primary key(username, playerName, dateAdded))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void registerMatch(String username, String playername, int newGoals, int newAssists){
        createTableIfNotExists();
        if(hasPlayedForUser(username,playername)) {
            System.out.println("Player" + playername + " has played for " + username);
            if (getMyPLayer(username, playername) == null) {
                System.out.println("Couldn't get users player-info.");
            } else {
                if(!updatePlayerStats(username, playername, newGoals, newAssists)){
                    // Error message?
                }
            }
        }
        else{
            //Create new value.
            if(!addToPlayerstats(username, playername, newGoals, newAssists)){
                //error message?
            }
        }
    }

    private boolean addToPlayerstats(String username, String playername, int goals, int assists){
        SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("username", username);
            contentValues.put("playerName", playername);
            contentValues.put("matches", 1);
            contentValues.put("goals", goals);
            contentValues.put("assists", assists);
            contentValues.put("rating", 0);
            int tp = goals + assists;
            contentValues.put("totalpoints", tp);

            try {
                db.insert("playerstats", null, contentValues);
                System.out.println("Added player " + playername + " to database for " + username);
            }
            catch (SQLiteDatatypeMismatchException e){
                System.out.println("Unable to insert into table playerstats");
                return false;
            }

            ContentValues last5newValues = new ContentValues();
            last5newValues.put("USERNAME", username);
            last5newValues.put("PLAYERNAME", playername);
            last5newValues.put("GOALS", goals);
            last5newValues.put("ASSISTS", assists);
            last5newValues.put("TOTALPOINTS", (goals+assists));
            last5newValues.put("DATEADDED", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

        try {
            db.insert("playerlast5", null, last5newValues);
            System.out.println("Updated last5stats for " + playername + " for " + username);
        }
        catch(SQLiteDatatypeMismatchException e){
            System.out.println("Unable to update last5stats");
            return false;
        }
        return true;
    }

    private boolean updatePlayerStats(String username, String playername, int newGoals, int newAssists){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select matches, goals, assists from playerstats where username = ? and playerName = ?", new String[]{username, playername}, null);
        if (res.getCount() <= 0) {
            res.close();
            System.out.println("Could not find users player-stats");
            return false;
        }

        // Find goals and assists and update.
        res.moveToFirst();

        int tempGoals = res.getInt(res.getColumnIndex(PLAYERSTATS_COLUMN_GOALS));
        tempGoals += newGoals;
        int tempMatches = res.getInt(res.getColumnIndex(PLAYERSTATS_COLUMN_MATCHES));
        tempMatches++;
        int tempAssists = res.getInt(res.getColumnIndex(PLAYERSTATS_COLUMN_ASSISTS));
        tempAssists += newAssists;
        int totalpoints = tempAssists + tempGoals;
        res.close();
        ContentValues newValues = new ContentValues();
        newValues.put("MATCHES", tempMatches);
        newValues.put("GOALS", tempGoals);
        newValues.put("ASSISTS", tempAssists);
        newValues.put("TOTALPOINTS", totalpoints);

        String[] args = new String[]{username, playername};

        ContentValues last5newValues = new ContentValues();
        last5newValues.put("USERNAME", username);
        last5newValues.put("PLAYERNAME", playername);
        last5newValues.put("GOALS", newGoals);
        last5newValues.put("ASSISTS", newAssists);
        last5newValues.put("TOTALPOINTS", (newGoals+newAssists));
        last5newValues.put("DATEADDED", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

        try {
            db.update("playerstats", newValues, "username=? AND playername=?", args);
            System.out.println("Updated player stats on " + playername + " for " + username);
        }
        catch(SQLiteDatatypeMismatchException e){
            System.out.println("Unable to update player stats");
            return false;
        }
        try {
            db.insert("playerlast5", null, last5newValues);
            System.out.println("Updated last5stats for " + playername + " for " + username);
        }
        catch(SQLiteDatatypeMismatchException e){
            System.out.println("Unable to update last5stats");
            return false;
        }
        return true;
        }

    private boolean hasPlayedForUser(String username, String playername){
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from playerstats where username = ? and playerName = ?", new String[]{username, playername}, null);
        if (res.getCount() <= 0) {
            res.close();
            return false;
        }
        res.close();
        return true;
    }

    private Cursor getMyPLayer(String username, String playername){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from playerstats where username = ? and playerName = ?", new String[]{username, playername}, null);
        if (res.getCount() <= 0) {
            res.close();
            return null;
        }
        res.close();
        return res;
    }

    public ArrayList<String> getPlayersStats(String username, String DESCorASC, String infoStat) {
        ArrayList<String> players = new ArrayList<String>();
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res;
        if(DESCorASC.equals("DESC")){
            res =  db.rawQuery( "SELECT playerName FROM playerstats WHERE username = ? ORDER BY "+ infoStat +" DESC ", new String [] {username}, null );
        }
        else {
            res = db.rawQuery("SELECT playerName FROM playerstats WHERE username = ? ORDER BY  "+ infoStat +" ASC ", new String[]{username}, null);
        }
        if(res.getCount()>0) {
            String f = DatabaseUtils.dumpCursorToString(res);
            System.out.println("Cursor-res: " + f);
            res.moveToFirst();
            while (!res.isAfterLast()) {
                players.add(res.getString(res.getColumnIndex("playerName")));
                res.moveToNext();
            }
            res.close();
            return players;
        }
        else{
            System.out.println("You have not registered any matches with your players yet!");
            res.close();
            return null;
        }
    }

    public String getSpecificPlayerStat(String username, String playername, String statInfo) {
        createTableIfNotExists();
        SQLiteDatabase db = this.getReadableDatabase();
        if(!statInfo.equals("avg")) {
            Cursor res = db.rawQuery("SELECT " + statInfo + " FROM playerstats WHERE username = ? AND playerName = ?", new String[]{username, playername}, null);
            if (res.getCount() == 1) {
                res.moveToFirst();
                String stat = res.getString(res.getColumnIndex(statInfo));
                res.close();
                return stat;
            } else {
                System.out.println("Multiple results when it should only be one!");
                res.close();
                return null;
            }
        }
        else{
            // Must calculate avgpoints
            return null;
        }
    }

    public int [][] last5Stats(String username, String playername){
        int [][] last5 = new int[5][2];
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT goals, assists FROM playerlast5 WHERE username = ? AND playerName = ? ORDER BY dateAdded DESC LIMIT 5", new String[]{username, playername}, null);
        if(res.getCount()>0){
            int i = 0;
            res.moveToFirst();
            while(res.isAfterLast() == false){
                last5[i][0] = res.getInt(res.getColumnIndex(PLAYERLAST5_COLUMN_GOALS));
                last5[i][1] = res.getInt(res.getColumnIndex(PLAYERLAST5_COLUMN_ASSISTS));
                res.moveToNext();
                i++;
            }
            res.close();
            return last5;
        }
        res.close();
        return null;
    }

    public ArrayList<String> getTopPlayers(String username, String stat){
        createTableIfNotExists();
        ArrayList<String> topPlayers = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery("SELECT playerName FROM playerstats WHERE username = ? AND "+stat+ " = " +
                "(SELECT MAX("+stat+") FROM playerstats WHERE username = ?)",new String []{username, username}, null);
        res.moveToFirst();
        while(!res.isAfterLast()){
            topPlayers.add(res.getString(res.getColumnIndex(PLAYERSTATS_COLUMN_PLAYERNAME)));
            res.moveToNext();
        }
        res.close();
        return topPlayers;
    }
    private void createTableIfNotExists(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select name from sqlite_master where type = ? and name = ?", new String[]{"table", "playerstats"}, null);
        if(res.getCount()<=0){
            res.close();
            onCreate(db);
        }
    }


}
