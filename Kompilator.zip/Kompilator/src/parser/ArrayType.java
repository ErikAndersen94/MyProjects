package parser;

import main.*;
import scanner.*;
import static scanner.TokenKind.*;

public class ArrayType extends Type{
	Type t;
	Constant c;
	Constant c1;
	types.Type type;
	int constVal;
	String name;
	
	ArrayType(int lnum) {
		super(lnum);
	}

	@Override
	public String identify() {
		return "<ArrayType> on line " + lineNum;
	}
	
	//Jernbanediagrammet i kompendiumet forteller oss at ArrayType har to konstanter C. 
	// Valgte � kalle disse c og c1, slik at ingen av objektene ble skrevet over.
	// Kaller i tillegg parse metodene i disse objektene, i tillegg til parse-metoden i klassen Type
	
	static ArrayType parse(Scanner s){
		enterParser("ArrayType");
		
		ArrayType at = new ArrayType(s.curLineNum());
		s.skip(arrayToken);
		s.skip(leftBracketToken);
		
		at.c = Constant.parse(s);
		s.skip(rangeToken);
		at.c1 = Constant.parse(s);
		s.skip(rightBracketToken);
		s.skip(ofToken);
		at.t = Type.parse(s);
		
		leaveParser("ArrayType");
		
		return at;
	}
	
	@Override
	void prettyPrint() {
		Main.log.prettyPrint("array[");
		c.prettyPrint();
		Main.log.prettyPrint("..");
		c1.prettyPrint();
		Main.log.prettyPrint("] of ");
		t.prettyPrint();
	}
	
	//Setter arrayType sin type til � v�re type sin type.
	@Override
	void check(Block curScope, Library lib){
		c.check(curScope, lib);
		c1.check(curScope, lib);
		t.check(curScope, lib);
		type = t.type;
	
	}
}
